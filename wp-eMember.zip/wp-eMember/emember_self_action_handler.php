<?php

/* Hanldes do_action and filter hooks that eMember uses itself */

add_action('emember_membership_changed','emember_handle_membership_level_upgraded_action');
add_action('emember_membership_cancelled','emember_handle_level_cancelled_action');
add_action('emember_membership_expired','emember_handle_level_cancelled_action');

add_action('eMember_login_complete', 'emember_do_member_login_extra_tasks');

function emember_handle_membership_level_upgraded_action($args)
{
    $member_id = $args['member_id'];
    $old_level = $args['from_level'];
    $new_level = $args['to_level'];
    
    //Check to make sure the old and new levels are not the same.
    if(trim($old_level) == trim($new_level)){
        eMember_log_debug('emember_membership_changed action hook handler. To (Level ID: '.$new_level.') and From (Level ID: '.$old_level.') values are the same. Nothing to do here.', true);
        return;
    }
    
    //Find record for this user
    eMember_log_debug('emember_membership_changed action hook handler. Retrieving user record for member ID: '.$member_id, true);
    $resultset = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . $member_id);
    if($resultset){
        //Found a record. Lets do some level update specific changes.
        $firstname = $resultset->first_name;
        $lastname = $resultset->last_name;
        $emailaddress  = $resultset->email;
        $account_status = $resultset->account_state;
        if($account_status == 'active'){
            //Only do this if the member's account is active.
            eMember_log_debug('emember_membership_changed action hook handler. Member account is active. Invoking level specific autoresponder signup functionality.', true);
            eMember_level_specific_autoresponder_signup($new_level, $firstname, $lastname, $emailaddress);
        }
        
        //Retrieve the new memberhsip level's details
        $level_row = emember_get_membership_level_row_by_id($new_level);
        
        //Update the WP user role according to the new level's setup (if applicable).
        $user_role = $level_row->role;
        eMember_log_debug('emember_membership_changed action hook handler. Updating user role if applicable', true);
        emember_update_wp_role_for_member($resultset->user_name, $user_role);
    }
}

function emember_handle_level_cancelled_action($args)
{
    $member_id = $args['member_id'];
    $level = $args['level'];

    //Find record for this user
    eMember_log_debug('emember_membership_cancelled action hook handler. Retrieving membership level record for member ID: '.$member_id, true);
    if(empty($level)){
        eMember_log_debug('Notice! Membership level ID missing.', true);
        return;
    }
    $ml_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" . $level . "'");
    $list_name = trim($ml_resultset->campaign_name);
    eMember_log_debug('List name for this membership level: '.$list_name, true);
    if(!empty($list_name)){
        //This level has a list name associated so need to do autoresponder cancellation.
        //TODO
    } 
}

/*** This function does additional tasks after a user logs into the site ***/
function emember_do_member_login_extra_tasks($username){
    $config = Emember_Config::getInstance();
    $redirect_expired = $config->getValue('eMember_redirect_expired_user');
    if($redirect_expired){
        $emember_auth = Emember_Auth::getInstance();
        $status = $emember_auth->getUserInfo('account_state');
        if($status == 'expired'){
            $redirect_url = $config->getValue('eMember_redirect_expired_page_url');
            eMember_log_debug ('Redirect expired user feature is enabled. Redirecting this expired member to: '.$redirect_url, true);
            if(!wp_doing_ajax()){
                wp_emember_redirect_to_url($redirect_url);
            } else {
                eMember_log_debug ('This is an ajax request. The redirect will be handled from the js code', true);
            }
        }
    }    
}