<?php

function wp_eMember_scheduled_membership_upgrade() {
    wp_eMember_auto_upgrade();
    wp_eMember_auto_migrate();
    wp_eMember_cron_email();
}

function wp_eMember_auto_upgrade() {
    eMember_log_cronjob_debug("===*** wp_eMember_auto_upgrade() Start ***===", true);
    global $wpdb;
    $emember_config = Emember_Config::getInstance();
    $wpememmeta = new WPEmemberMeta();
    $members_tbl = $wpememmeta->get_table('member');
    $email_list = array();
    $query_start = 0;
    $query_limit = 500;
    $iterations = 0;
    $membership_levels = Emember_Level_Collection::get_instance();
    while (1) {
        $query = 'SELECT user_name, member_id,membership_level,email,subscription_starts,account_state, member_since,'
                . 'more_membership_levels,more_membership_levels_start_date, autoupgrade_starts, expiry_1st, expiry_2nd FROM '
                . $members_tbl . '  LIMIT ' . $query_start . ', ' . $query_limit;
        $members = $wpdb->get_results($query, OBJECT);
        if (count($members) < 1) {
            break;
        }
        foreach ($members as $member) {

            eMember_log_cronjob_debug("Checking member profile with member ID:" . $member->member_id . ", Username: " . $member->user_name, true);

            if (empty($member->subscription_starts)) {
                continue;
            }
            if (empty($member->user_name)) {
                continue;
            }
            if ($member->account_state != 'active' && $member->account_state != 'unsubscribed'){
                //We only want to to inspect the member profiles that have an account status of "active" or "unsubscribed".
                //eMember_log_cronjob_debug("eMember cronjob - This member record will not be looked at due to the account status. Account status: ".$member->account_state.", member ID:" . $member->member_id, true);
                continue;//This member's account status is "inactive" or "expired" or "pending" so don't do anything.
            }

            $level_info = array();
            $my_level = $membership_levels->get_levels($member->membership_level);
            if (empty($my_level)) {
                eMember_log_cronjob_debug("eMember cronjob - wp_eMember_auto_upgrade: invalid membership level for member ID:" . $member->member_id, false);
                continue;
            }
            $options = unserialize($my_level->get('options'));
            $current_level = $member->membership_level;
            $more_levels = $member->more_membership_levels;
            $more_levels = is_array($more_levels) ? array_filter($more_levels) : $more_levels;
            $sec_levels = explode(',', $more_levels);
            $sec_levels_starts = (array) json_decode($member->more_membership_levels_start_date, true);
            $level_info['membership_level'] = $current_level;
            $level_info['account_state'] = $member->account_state; //Initialize the account state with the current data

            $level_data_modified = false;
            if (isset($options['promoted_level_id']) && (!empty($options['promoted_level_id'])) && ($options['promoted_level_id'] != -1)) {
                //TODO - comment the following log out after troubleshooting.
                eMember_log_cronjob_debug("The primary level of this user (" . $member->user_name . ") is: " . $current_level . ". Promoted Level ID value: " . $options['promoted_level_id'], true);

                $current_subscription_starts = empty($member->subscription_starts) ? time(): strtotime($member->subscription_starts);
                $current_autoupgrade_starts = empty($member->autoupgrade_starts) ? time() : strtotime($member->autoupgrade_starts);
                $current_time = time();
                while (1) {
                    //Determine which level this user needs to be upgraded to (if any).
                    //All the changes are stored in the $level_info array. Then finally when the loop breaks, the data is updated in the database table.

                    if ($current_level === $options['promoted_level_id']) {
                        break;
                    }
                    $promoted_after = trim($options['days_after']);
                    if (empty($promoted_after)) {
                        break;
                    }

                    //Lets compare the next auto upgrade date and current date.
                    $d = ($promoted_after == 1) ? ' day' : ' days';
                    $next_auto_upgrade_date = strtotime(" + " . abs($promoted_after) . $d, $current_autoupgrade_starts);

                    $upgrade_date_of_user = date('Y-m-d', $next_auto_upgrade_date);
                    $current_time_date = date('Y-m-d', $current_time);
                    eMember_log_cronjob_debug("Before checking auto upgrade date comparison. next_auto_upgrade_date > current_time. Next Auto Upgrade Date: ".$upgrade_date_of_user.", Current Date: ".$current_time_date, true);
                    if ($next_auto_upgrade_date > $current_time) {
                        //We are in a while condition so this message gets printed all the time. However, when it goes to the else condition, it will do the auto upgrade regardless.
                        //TODO - refactor the while loop (it is not longer needed after this auto upgrade function has been refactored.
                        eMember_log_cronjob_debug("Breaking loop as this member account is not ready for next auto upgrade.", true);
                        break;
                    } else {
                        eMember_log_cronjob_debug("Auto upgrade condition met. This member's level will be auto upgraded.", true);
                    }

                    if (!isset($options['promoted_level_id']) || empty($options['promoted_level_id']) || ($options['promoted_level_id'] == -1)) {
                        eMember_log_cronjob_debug("Breaking loop promoted_level_id is not set for this user.", true);
                        break;
                    }
                    if (!array_key_exists(absint($current_level), $sec_levels_starts)) {
                        if (empty($current_subscription_starts) || !is_numeric($current_subscription_starts)) {
                            // Default to current time if not valid timestamp.
                            eMember_log_cronjob_debug("The current_subscription_starts value is not a valid timestamp. Setting current timestamp for it.", false);
                            $current_subscription_starts = time(); 
                        }
                        $sec_level_starts_date = date('Y-m-d', (int)$current_subscription_starts);
                        $sec_levels_starts[absint($current_level)] = $sec_level_starts_date;
                        eMember_log_cronjob_debug("Settings secondary level's start date value to: " . $sec_level_starts_date, true);
                    }
                    $sec_levels[] = $current_level;
                    $current_level = $options['promoted_level_id'];
                    $current_subscription_starts = $next_auto_upgrade_date; //Set the new subscription start date to the date the auto upgrade to this level happened.
                    $my_level = $membership_levels->get_levels($current_level); //
                    $options = unserialize($my_level->get('options'));
                }//End of while.

                if (($current_level != -1) && (!empty($current_level)) && ($member->membership_level != $current_level)) {
                    $level_info['membership_level'] = $current_level;
                    $level_info['subscription_starts'] = date('Y-m-d');
                    $member->subscription_starts = date('Y-m-d');
                    $level_data_modified = true;
                    if ($emember_config->getValue('eMember_enable_secondary_membership')) {
                        $level_info['more_membership_levels'] = implode(',', array_unique($sec_levels));
                        $level_info['more_membership_levels_start_date'] = json_encode($sec_levels_starts);
                    }
                }
            }

            //=== Use the same member row iteration to do the account expiry check.
            if (wp_emember_is_subscription_expired($member, $my_level)) {
                eMember_log_cronjob_debug("The primary level of this user (Member ID: " . $member->member_id . ", Username: " . $member->user_name . ") is expired. Setting account status to expired.", true);
                $level_info['account_state'] = 'expired';
                $level_data_modified = true;
                do_action('emember_membership_expired', array('member_id' => $member->member_id, 'level' => $current_level));
            }

            //=== Auto upgrade feature - Update the database table values for this current member ===/
            if ($level_data_modified) {
                eMember_log_cronjob_debug('Updating the member account with member ID: ' . $member->member_id . ' Level: ' . $level_info['membership_level'], true);
                eMember_log_cronjob_debug('Setting member account status to: ' . $level_info['account_state'], true);
                // send notification to active account.
                if ($level_info['account_state'] == 'active') {
                    $email_list[] = $member->email;
                }
                if (!empty($level_info)) {
                    $wpdb->update(WP_EMEMBER_MEMBERS_TABLE_NAME, $level_info, array('member_id' => $member->member_id));
                }
                do_action('emember_membership_changed', array('member_id' => $member->member_id,
                    'from_level' => $member->membership_level,
                    'to_level' => $level_info['membership_level']));
            }
            eMember_log_cronjob_debug("----- End of foreach (Member ID: ".$member->member_id.") -----", true);
        }//End of foreach loop for the iterating through members

        $query_start = $query_limit * ( ++$iterations) + 1;
    }//End of while loop

    //Handle auto upgrade email notification (if enabled)
    if ($emember_config->getValue('eMember_enable_autoupgrade_notification')) {
        eMember_log_cronjob_debug('Using auto upgrade notification email option.. need to check the email list.', true);
        if (!empty($email_list)) {
            $eMember_batch_email_to_address = $emember_config->getValue('eMember_batch_email_to_address');
            if(empty($eMember_batch_email_to_address)){
                $to_email = array_pop($email_list);//Take one from the list to use as the main "to address". Others will be used in the BCC field.
            } else {
                $to_email = $eMember_batch_email_to_address;
                eMember_log_cronjob_debug("Using the batch email to address value: " . $to_email);
            }

            $subject = $emember_config->getValue('eMember_autoupgrade_email_subject');
            $body = $emember_config->getValue('eMember_autoupgrade_email_body');
            if( strtolower($body) == "disabled" ){
                eMember_log_cronjob_debug("Attention!!! The Auto upgrade email body is set to disabled status. No email will be sent for this.", true);
            } else {
                eMember_log_cronjob_debug('Sending auto upgrade notification email with subject: ' . $subject, true);
                $headers = 'From: ' . $emember_config->getValue('eMember_autoupgrade_senders_email_address') . "\r\n";
                $headers .= 'bcc: ' . implode(',', $email_list) . "\r\n";
                eMember_log_cronjob_debug($headers, true);
                wp_mail($to_email, $subject, $body, $headers);
                eMember_log_cronjob_debug('Auto upgrade notification email sent.', true);
                eMember_log_cronjob_debug('Headers value: '.$headers, true);
            }
        }
    }
    eMember_log_cronjob_debug('---*** wp_eMember_auto_upgrade() End ***---', true, true);
}

function wp_eMember_auto_migrate() {
    eMember_log_cronjob_debug("eMember cronjob - wp_eMember_auto_migrate()", true);
    global $wpdb;
    $emember_config = Emember_Config::getInstance();
    $wpememmeta = new WPEmemberMeta();
    $members_tbl = $wpememmeta->get_table('member');
    $secondary_level_enabled = $emember_config->getValue('eMember_enable_secondary_membership');
    $auto_migrate_enabled = $emember_config->getValue('eMember_secondary_membership_migrate');
    if ((!$secondary_level_enabled || !$auto_migrate_enabled)) {
        return;
    }
    $query_start = 0;
    $query_limit = 500;
    $iterations = 0;
    $membership_levels = Emember_Level_Collection::get_instance();
    while (1) {
        $query = 'SELECT user_name, member_id,membership_level,email,subscription_starts,account_state, '
                . 'more_membership_levels,more_membership_levels_start_date, expiry_1st, expiry_2nd FROM '
                . $members_tbl . '  LIMIT ' . $query_start . ', ' . $query_limit;
        $members = $wpdb->get_results($query, OBJECT);
        if (count($members) < 1) {
            break;
        }
        foreach ($members as $member) {
            if (empty($member->subscription_starts)) {
                continue;
            }
            if (empty($member->user_name)) {
                continue;
            }
            if ($member->account_state == 'active') {
                continue;
            }
            $level_info = array();
            $my_level = $membership_levels->get_levels($member->membership_level);
            $more_levels = $member->more_membership_levels;
            $more_levels = is_array($more_levels) ? array_filter($more_levels) : $more_levels;
            $sec_levels = explode(',', $more_levels);
            $sec_levels_starts = (array) json_decode($member->more_membership_levels_start_date, true);
            $sec_levels_copy = $sec_levels;
            $level_data_modified = false;
            if (wp_emember_is_subscription_expired($member, $my_level)) {
                eMember_log_cronjob_debug("Auto migrate: The primary level of this user (" . $member->user_name . ") is expired. Setting account status to expired.", true);
                eMember_log_cronjob_debug("Auto migrate: Auto switch primary level with a non expired secondary level feature is enabled. Checking if the user has any secondary level in his profile.", true);
                $membership_level = absint($member->membership_level);
                $sec_levels[] = $membership_level;
                if (!array_key_exists($membership_level, $sec_levels)) {
                    $sec_levels_starts[$membership_level] = $member->subscription_starts;
                }
                foreach ($sec_levels_copy as $key => $level) {
                    eMember_log_cronjob_debug("Auto migrate: Checking secondary level ID: " . $level, true);
                    if (empty($level))
                        continue;
                    $start_date = isset($sec_levels_starts[$level]) ? $sec_levels_starts[$level] : date('Y-m-d');
                    $level = absint($level);

                    if (wp_emember_is_subscription_expired($member, $membership_levels->get_levels($level))) {
                        $sec_levels[] = $level;
                        if (!array_key_exists(absint($level), $sec_levels)) {
                            $sec_levels_starts[$level] = $start_date;
                        }
                        continue;
                    }
                    $level_data_modified = true;
                    $level_info['membership_level'] = $level;
                    $level_info['subscription_starts'] = $start_date;
                    $level_info['account_state'] = 'active';
                    $level_info['more_membership_levels'] = implode(',', array_unique($sec_levels));
                    $level_info['more_membership_levels_start_date'] = json_encode($sec_levels_starts);
                    eMember_log_cronjob_debug("Switching primary level with a non expired secondary level. New primarly level ID: " . $level_info['membership_level'] . ". Subscription starts: " . $level_info['subscription_starts'], true);
                    $wpdb->update(WP_EMEMBER_MEMBERS_TABLE_NAME, $level_info, array('member_id' => $member->member_id));
                    do_action('emember_membership_changed', array('member_id' => $member->member_id,
                        'from_level' => $membership_level,
                        'to_level' => $level_info['membership_level']));
                    break;
                }
            }
        }//End of foreach loop
        $query_start = $query_limit * ( ++$iterations) + 1;
    }//End of while loop
    eMember_log_cronjob_debug('End of wp_eMember_auto_migrate() function', true, true);
}

function wp_eMember_cron_email() {
    eMember_log_cronjob_debug("eMember cronjob - wp_eMember_cron_email()", true);
    global $wpdb;
    $emember_config = Emember_Config::getInstance();
    $wpememmeta = new WPEmemberMeta();
    $members_tbl = $wpememmeta->get_table('member');
    $emails_for_followup_notification = array();
    $query_start = 0;
    $query_limit = 500;
    $iterations = 0;
    $membership_levels = Emember_Level_Collection::get_instance();
    while (1) {
        $query = 'SELECT user_name, member_id,membership_level,email,subscription_starts,account_state, '
                . 'more_membership_levels,more_membership_levels_start_date, expiry_1st, expiry_2nd FROM '
                . $members_tbl . '  LIMIT ' . $query_start . ', ' . $query_limit;
        $members = $wpdb->get_results($query, OBJECT);
        if (count($members) < 1) {
            break;
        }
        foreach ($members as $member) {
            if (empty($member->subscription_starts)) {
                continue;
            }
            if (empty($member->user_name)) {
                continue;
            }

            $my_level = emember_get_membership_level_row_by_id($member->membership_level);

            //Notification after x days of account expiry
            if (($member->account_state != 'expired')) {
                continue;
            }
            $is_auto_email = $emember_config->getValue('eMember_email_notification');
            $notification_interval = $emember_config->getValue('eMember_after_expiry_num_days');
            //$is_recurring = $emember_config->getValue('eMember_after_expiry_num_days_recurring');
            if (!empty($is_auto_email) && !empty($notification_interval)) {
                $days_elapsed = wp_emember_num_days_since_expired($my_level->subscription_period, $my_level->subscription_unit, $member->subscription_starts);
                if (($days_elapsed == $notification_interval)){
                    eMember_log_cronjob_debug('Member ID: '.$member->member_id.'. Days elapsed after expiry value ('.$days_elapsed.') is equal to notification interval ('.$notification_interval.'). This member will receive an expiry notification email.', true);
                    $emails_for_followup_notification[] = $member->email;
                }
            }
        }//End of foreach loop
        $query_start = $query_limit * ( ++$iterations) + 1;
    }//End of while loop
    // Handle notification email after X days if needed
    if (!empty($emails_for_followup_notification)) {
        $eMember_batch_email_to_address = $emember_config->getValue('eMember_batch_email_to_address');
        if(empty($eMember_batch_email_to_address)){
            $to_email = array_pop($emails_for_followup_notification);//Take one from the list to use as the main "to address". Others will be used in the BCC field.
        } else {
            $to_email = $eMember_batch_email_to_address;
            eMember_log_cronjob_debug("Using the batch email to address value: " . $to_email);
        }
        $subject = $emember_config->getValue('eMember_after_expiry_email_subject_followup');
        eMember_log_cronjob_debug('Sending expiry notification email after X days with subject: ' . $subject, true);
        $body = $emember_config->getValue('eMember_after_expiry_email_body_followup');
        $headers = 'From: ' . $emember_config->getValue('eMember_after_expiry_senders_email_address_followup') . "\r\n";
        $headers .= 'bcc: ' . implode(',', $emails_for_followup_notification) . "\r\n";
        eMember_log_cronjob_debug($headers, true);
        wp_mail($to_email, $subject, $body, $headers);
        eMember_log_cronjob_debug('Expiry notification email sent.', true);
	eMember_log_cronjob_debug('Headers value: '.$headers, true);
    }

    eMember_log_cronjob_debug('End of wp_eMember_cron_email() function', true, true);
}
