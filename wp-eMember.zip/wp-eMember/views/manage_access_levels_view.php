<?php include_once('membership_level_list_view.php'); ?>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
	$.validationEngineLanguage = {
	    newLang: function () {
		$.validationEngineLanguage.allRules = {
		    "required": {
			"regex": "none",
			"alertText": "* " + 'This field is required ',
			"alertTextCheckboxe": "* " + 'This field is required '
		    },
		    "ajaxUserLevelCall": {
			"url": "ajaxurl",
			"regex": "none",
			"extraData": "&event=check_level_name&action=check_level_name",
			"alertText": "* Name Already Used",
			"alertTextOk": "* Name Available",
			"alertTextLoad": "* Please Wait"
		    },
		    "ajaxUserLevelCallEdit": {
			"url": "ajaxurl",
			"regex": "none",
			"extraData": "&event=check_level_name_edit&action=check_level_name",
			"extraDataDynamic": ['#hidden_id'],
			"alertText": "* Name Already Used",
			"alertTextOk": "* Name Available",
			"alertTextLoad": "* Please Wait"
		    }
		};
	    }
	};
	$.validationEngineLanguage.newLang();
	function toggle_form(show) {
	    if (show) {
		$('#emember_membership_list').slideUp('slow');
		$('#emember_membership_form').slideDown('slow').html("");
	    } else {
		$('#emember_membership_list').slideDown('slow');
		$('#emember_membership_form').slideUp('slow');
		$('#emember_form').validationEngine('hideAll');
	    }
	}
	function emember_get_form(id) {
	    toggle_form(true);
	    var id = (id == undefined) ? "" : id;
	    var params = {action: 'emember_load_membership_form', id: id};
	    $('#emember_membership_form').load(ajaxurl, params, function () {
		$('#cancel_button').click(function () {
		    toggle_form(false);
		});
		$('.emember_sub_duration').click(function () {
		    switch (this.value) {
			case 'interval':
			    $('#level_name_new_calendar').prop('disabled', false);
			    $('#level_name_new_expire').prop('disabled', false);
			    $('#expire_on_fixed_date_new_level').prop('disabled', true);
			    break;
			case 'fixed_date':
			    $('#level_name_new_calendar').prop('disabled', true);
			    $('#level_name_new_expire').prop('disabled', true);
			    $('#expire_on_fixed_date_new_level').prop('disabled', false);
			    break;
			case 'noexpire':
			    $('#level_name_new_calendar').prop('disabled', true);
			    $('#level_name_new_expire').prop('disabled', true);
			    $('#expire_on_fixed_date_new_level').prop('disabled', true);
			    break;
		    }
		});
		$.validationEngineLanguage.allRules['ajaxUserLevelCall']['url'] = '<?php echo admin_url( 'admin-ajax.php' ); ?>';
		$.validationEngineLanguage.allRules['ajaxUserLevelCallEdit']['url'] = '<?php echo admin_url( 'admin-ajax.php' ); ?>';
		$("#emember_form").validationEngine('attach', {
		    onValidationComplete: function (form, status) {
			console.log(status);
			if (status) {
			    return true;
			}
		    }
		});
		$('#emember_form').submit(function (e) {
		    var ok = true;
		    $(this).find('input').each(function (i) {
			if ((this.value == '') && (!this.disabled) && $(this).attr('emember_required')) {
			    $(this).css('background', 'red');
			    ok = false;
			}
		    });
		    return ok;
		});
	    });

	}
	$('#add_new').click(function () {
	    emember_get_form()
	});
	$('.emember_edit').click(function () {
	    emember_get_form($(this).attr('id'));
	});
	$('.emember_delete').click(function () {
	    top.document.location = 'admin.php?page=eMember_membership_level_menu&delete=' + $(this).attr('id');
	    return false;
	}).confirm({msg: "", timeout: 5000});
    });
</script>
