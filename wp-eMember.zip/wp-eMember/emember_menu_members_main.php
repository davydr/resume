<?php
include_once('lib/class.emember_member_list.php');

function build_menu($current) {
    ?>
    <h2 class="nav-tab-wrapper">
        <a class="nav-tab <?php echo ($current == 1) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=wp_eMember_manage">Manage Members</a>
        <a class="nav-tab <?php echo ($current == 2) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=wp_eMember_manage&members_action=add_edit">Add/Edit Member</a>
        <a class="nav-tab <?php echo ($current == 3) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=wp_eMember_manage&members_action=manage_list">Member Lists</a>
        <a class="nav-tab <?php echo ($current == 4) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=wp_eMember_manage&members_action=export_members_data">Export Data</a>
        <a class="nav-tab <?php echo ($current == 5) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=wp_eMember_manage&members_action=add_wp_members">Import WP Users</a>
        <a class="nav-tab <?php echo ($current == 6) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=wp_eMember_manage&members_action=manage_blacklist">Manage Blacklist</a>
        <a class="nav-tab <?php echo ($current == 7) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=wp_eMember_manage&members_action=manage_upgrade">Auto Upgrade</a>
    </h2>
    <?php
}

function wp_eMember_members() {
    echo '<div class="wrap">';
    echo '<h2>WP eMember - Members v' . WP_EMEMBER_VERSION . '</h2>';

    echo eMember_admin_submenu_css();
    $_GET['members_action'] = isset($_GET['members_action']) ? $_GET['members_action'] : "";
    switch ($_GET['members_action']) {
        case 'add_edit':
            build_menu(2);
            wp_eMember_add_memebers();
            break;
        case 'manage_list':
            build_menu(3);
            wp_eMember_manage_memebers_lists();
            break;
        case 'export_members_data':
            build_menu(4);
            wp_eMember_export_memebers_data();
            break;        
        case 'add_wp_members':
            build_menu(5);
            wp_eMember_add_wp_members();
            break;
        case 'manage_blacklist':
            build_menu(6);
            wp_eMember_manage_blackList();
            break;
        case 'manage_upgrade':
            build_menu(7);
            wp_eMember_manage_upgrade();
            break;
        case 'edit_ip_lock':
            build_menu(1);
            wp_eMember_edit_ip_lock();
            break;        
        case 'manage':
        default:
            build_menu(1);
            wp_eMember_manage_members();
            break;
    }
    echo '</div>';
}

function wp_eMember_export_memebers_data() {

    $wp_emember_export_from_level_id = isset($_REQUEST['wp_emember_export_from_level_id']) ? sanitize_text_field($_REQUEST['wp_emember_export_from_level_id']) : "";
    ?>
    <div id="poststuff">
        <div id="post-body">

            <div class="postbox">
                <h3 class="hndle"><label for="title">Export Members Data to CSV File</label></h3>
                <div class="inside">

                    <form method="post" action="" >
                        <table width="100%" border="0" cellspacing="0" cellpadding="6">
                            <tr valign="top">
                                <td width="25%" align="left">
                                    <strong>Export All Members Data to CSV</strong>
                                </td>
                                <td align="left">
                                    <input type="submit" class="button" name="wp_emember_export" value="Export All Members Data" />
                                    <p class="description">Use this to export all members data to a CSV file.</p>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <br />
                    <form method="post" action="" >
                        <table width="100%" border="0" cellspacing="0" cellpadding="6">
                            <tr valign="top">
                                <td width="25%" align="left">
                                    <strong>Export Data of Members from a Level</strong>
                                </td>
                                <td align="left">
                                    <input name="wp_emember_export_from_level_id" type="text" size="5" value="<?php echo isset($wp_emember_export_from_level_id) ? $wp_emember_export_from_level_id : ""; ?>" />
                                    <input type="submit" class="button" name="wp_emember_export_from_level" value="Export Members Data of Membership Level" />
                                    <p class="description">Enter the ID of the membership level then use this button to export data of members from the specified membership level.</p>
                                </td>
                            </tr>
                        </table>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <?php
}

function wp_eMember_manage_upgrade() {
    $emember_config = Emember_Config::getInstance();
    if (isset($_POST['submit'])) {
        $emember_config->setValue('eMember_enable_autoupgrade_notification', isset($_POST["eMember_enable_autoupgrade_notification"]) ? "checked='checked'" : '');
        $emember_config->saveConfig();

        foreach ($_POST['data'] as $key => $data) {
            if ($key == 1)
                continue;
            $fields = array();
            $fields['options'] = serialize($data);
            dbAccess::update(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, 'id = ' . $key, $fields);
        }
        echo wp_eMember_admin_updated_message('Updated!');
    }
    $levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
    ob_start();
    ?>
    <div class="eMember_yellow_box"><p><strong>Please read the <a href="https://www.tipsandtricks-hq.com/wordpress-membership/how-to-use-auto-upgrade-feature-to-drip-content-194" target="_blank">Auto Upgrade Setup Documentation</a> before attempting to setup auto upgrade for your members.</strong></p></div>
    <form method="post" id="emember_auto_upgrade">
        <div id="emember_Pagination" class="emember_pagination"></div>
        <table id="membership_level_list" class="widefat">
            <thead>
                <tr>
                    <th scope="col"><?php echo __('Membership Level', 'wp_eMember'); ?></th>
                    <th scope="col"><?php echo __('Promote to', 'wp_eMember'); ?></th>
                    <th scope="col"><?php echo __('After #of Days From the Auto Upgrade Starts Date', 'wp_eMember'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = 0;
                foreach ($levels as $level) {
                    $em_options = unserialize($level->options);
                    ?>
                    <tr <?php echo ($count % 2) ? 'class="emember-alternate"' : ''; ?>>
                        <td>
                            <?php echo stripslashes($level->alias); ?>
                        </td>
                        <td>
                            <select name="data[<?php echo $level->id; ?>][promoted_level_id]">
                                <option value="-1">No Auto Promote</option>
                                <?php
                                foreach ($levels as $l) {
                                    ?>
                                    <option <?php echo ($l->id === $em_options['promoted_level_id']) ? 'selected="selected"' : ''; ?> value="<?php echo $l->id; ?>">
                                        <?php echo stripslashes($l->alias); ?>
                                    </option>
                                    <?php
                                }
                                ?>
                            </select>
                        </td>
                        <td>
                            <input name="data[<?php echo $level->id; ?>][days_after]" type="text" size="6" value="<?php echo $em_options['days_after']; ?>" ></input> Day(s) After the Auto Upgrade Starts Date
                        </td>
                    </tr>
                    <?php
                    $count++;
                }
                ?>
            </tbody>
        </table>

        <div id="poststuff"><div id="post-body">
                <div class="postbox">
                    <h3 class="hndle"><label for="title">Auto Upgrade Related Settings</label></h3>
                    <div class="inside">
                        <table width="100%" border="0" cellspacing="0" cellpadding="6">
                            <tr valign="top">
                                <td width="25%" align="left">
                                    <strong>Enable Automatic Upgrade Email Notification</strong>
                                </td>
                                <td><input name="eMember_enable_autoupgrade_notification" type="checkbox"  <?php echo $emember_config->getValue('eMember_enable_autoupgrade_notification'); ?> value="1"/>
                                    When checked the plugin will send a notification email to the members when their account gets upgraded to a new membership level.
                                </td>
                            </tr>
                        </table>
                    </div></div>

                <p class="submit">
                    <input type="submit" class="button-primary" name="submit" value="Save Auto Upgrade Settings" />
                </p>
                </form>
            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $('#emember_auto_upgrade input[type=text]').focus(function () {
                    $(this).css('border', '');
                });
                $('#emember_auto_upgrade').submit(function () {
                    var ok = true;
                    $(this).find('input[type=text]').each(function () {
                        var $this = $(this);
                        if ($this.val() == "") {
                            var $selected = $this.parents('tr:first').find('select').val();
                            if ($selected != -1) {
                                ok = false;
                                $this.css("border", "1px solid red");
                            }

                        }
                    });
                    if (!ok)
                        alert('Fields cannot be empty.');
                    return ok;
                });
            });
        </script>
        <?php
        $content = ob_get_contents();
        ob_end_clean();
        echo $content;
    }

    function wp_eMember_edit_ip_lock() {
        echo '<h2>Manage Member IP Lock</h2>';

        if (isset($_GET['editrecord'])) {
            global $wpdb;
            $query = "SELECT meta_value FROM " . WP_EMEMBER_MEMBERS_META_TABLE .
                    " WHERE user_id = " . $_GET['editrecord'] . " AND meta_key = 'login_count'";
            $login_count = $wpdb->get_row($query);
            $login_count = isset($login_count->meta_value) ? unserialize($login_count->meta_value) : array();

            $used_ips = '';
            if (isset($login_count[date('y-m-d')]))
                $used_ips = implode(';', $login_count[date('y-m-d')]);

            if (isset($_POST['submit'])) {
                $used_ips = $_POST['locked_ips'];
                if (empty($used_ips))
                    $ips = array();
                else
                    $ips = explode(';', $_POST['locked_ips']);

                $ips = array(date('y-m-d') => array_unique($ips));
                if ($login_count === false){
                    $query = "INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . "(user_id,meta_key,meta_value)" .
                            "VALUES(" . $_GET['editrecord'] . ", 'login_count', '" . serialize($ips) . "')";
                }
                else {
                    $query = "UPDATE " . WP_EMEMBER_MEMBERS_META_TABLE . " SET meta_value = '" . serialize($ips) . "'" .
                            " WHERE user_id= " . $_GET['editrecord'] . " AND meta_key = 'login_count'";
                }
                $wpdb->query($query);
                echo wp_eMember_admin_updated_message('Updated!');
            }
            ?>
            <div id="poststuff"><div id="post-body">

            <form method="post">
            <div class="postbox">
                <h3 class="hndle"><label for="title">IP Addresses Used by the Member</label></h3>
                <div class="inside">
                    <p>Following list provides all the IP addresses used by this user to log into this site. You can modify it but make sure that IP addresses are semi-colon separated.</p>
                    <textarea name="locked_ips" rows="10" cols="70"><?php echo $used_ips; ?></textarea>
                    <p class="submit"><input type="submit" class="button-primary" name="submit" value="Update List" /></p>
                </div>
            </div>
            </form>

            </div></div><!-- end of .poststuff and .post-body -->
            <?php
        }
        else {
            wp_die('Error! You do not have permission to access the ip lock edit menu');
        }
    }

    function wp_eMember_manage_blackList() {
        $emember_config = Emember_Config::getInstance();

        if (isset($_POST['submit'])) {
            // Verify nonce
            if (!isset($_POST['emember_blacklist_nonce']) || !wp_verify_nonce($_POST['emember_blacklist_nonce'], 'emember_blacklist_action')) {
                die('Nonce security check failed for the blacklisting feature. Try again.');
            }

            // Save the blacklist entries
            $emember_config->setValue('blacklisted_ips', sanitize_text_field($_POST['blacklisted_ips']));
            $emember_config->setValue('blacklisted_emails', sanitize_text_field($_POST['blacklisted_emails']));
            $emember_config->setValue('blacklisted_email_patterns', sanitize_text_field($_POST['blacklisted_email_patterns']));

            $emember_config->saveConfig();
        }

        $blacklisted_ips = esc_textarea($emember_config->getValue('blacklisted_ips'));
        $blacklisted_emails = esc_textarea($emember_config->getValue('blacklisted_emails'));
        $blacklisted_email_patterns = esc_textarea($emember_config->getValue('blacklisted_email_patterns'));

        ?>
        <div id="poststuff"><div id="post-body">

        <form method="post">
            <?php wp_nonce_field('emember_blacklist_action', 'emember_blacklist_nonce'); ?>
            <div class="postbox">
                <h3 class="hndle"><label for="title">IP Blacklist</label></h3>
                <div class="inside">
                    <p>Following is a list (semi-colon separated) of blacklisted IP addresses.</p>
                    <textarea name="blacklisted_ips" rows="7" cols="70"><?php echo $blacklisted_ips; ?></textarea>
                </div>
            </div>

            <div class="postbox">
                <h3 class="hndle"><label for="title">Email Address Blacklist</label></h3>
                <div class="inside">
                    <p>Following is a list (semi-colon separated) of blacklisted email addresses.</p>
                    <textarea name="blacklisted_emails" rows="7" cols="70"><?php echo $blacklisted_emails; ?></textarea>
                </div>
            </div>

            <div class="postbox">
                <h3 class="hndle"><label for="title">Email Address Pattern Blacklist</label></h3>
                <div class="inside">
                    <p>Following is a list (semi-colon separated) of blacklisted email address patterns. Example: you can use a value of @hotmail.com to blacklist all hotmail email addresses.</p>
                    <textarea name="blacklisted_email_patterns" rows="7" cols="70"><?php echo $blacklisted_email_patterns; ?></textarea>
                </div>
            </div>

            <p class="submit"><input type="submit" class="button-primary" name="submit" value="Update Blacklist" /></p>

        </form>

        </div></div><!-- end of .poststuff and .post-body -->
        <?php
    }

    function wp_eMember_add_user_record($row) {
        global $wpdb;
        $user_info = get_userdata($row['ID']);
        $user_cap = is_array($user_info->wp_capabilities) ? array_keys($user_info->wp_capabilities) : array();
        $fields = array();
        $fields['user_name'] = $user_info->user_login;
        $fields['first_name'] = $user_info->user_firstname;
        $fields['last_name'] = $user_info->user_lastname;
        $fields['password'] = $user_info->user_pass;
        $fields['member_since'] = (date("Y-m-d"));
        $fields['membership_level'] = $row['membership_level'];
        //$fields['initial_membership_level'] = $row['membership_level'];
        $fields['account_state'] = $row['account_state'];
        $fields['email'] = $user_info->user_email;
        $fields['address_street'] = '';
        $fields['address_city'] = '';
        $fields['address_state'] = '';
        $fields['address_zipcode'] = '';
        $fields['country'] = '';
        $fields['gender'] = 'not specified';
        $fields['referrer'] = '';
        if (!is_admin()) {
            $fields['last_accessed_from_ip'] = get_real_ip_addr();
        }
        $fields['subscription_starts'] = $row['subscription_starts'];
        $fields['autoupgrade_starts'] = $row['autoupgrade_starts'];
        $fields['extra_info'] = '';

        if (isset($row['preserve_wp_role'])) {
            $fields['flags'] = 1;
        } else {
            $fields['flags'] = 0;
            if (($row['account_state'] === 'active') && !in_array('administrator', $user_cap))
                update_wp_user_Role($row['ID'], $row['membership_level']);
        }
        $user_exists = emember_username_exists($fields['user_name']);

        if ($user_exists) {
            //return dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME, 'member_id = ' . $user_exists, $fields);
            return $wpdb->update(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields, array('member_id' => $user_exists));
        } else {
            //Insert a new user in emember
            eMember_log_debug("Importing the WP User into eMember system", true);
            //return dbAccess::insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
            $wpdb->insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
            /*             * * Signup the member to Autoresponder List (Autoresponder integration) ** */
            $membership_level_id = $fields['membership_level'];
            $firstname = isset($fields['first_name']) ? $fields['first_name'] : "";
            $lastname = isset($fields['last_name']) ? $fields['last_name'] : "";
            $emailaddress = $fields['email'];
            eMember_level_specific_autoresponder_signup($membership_level_id, $firstname, $lastname, $emailaddress);
            eMember_global_autoresponder_signup($firstname, $lastname, $emailaddress);
            /*             * * end of autoresponder integration ** */
        }
    }

    function wp_eMember_add_wp_members() {
        global $wpdb;
        $wp_member_count = $wpdb->get_row("SELECT count(*) as count FROM $wpdb->users ORDER BY ID");
        $all_levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
        if (empty($all_levels)) {
            echo '<div id="message" style= "color:red;" class="updated fade"><p>Before Adding  Any  Wordpress Member, <br/>You Need To Create At Least One Membership Level.</p></div>';
            return;
        }
        $emember_config = Emember_Config::getInstance();
        if (isset($_POST['add_to_wp']) && isset($_POST['wp_add_wp_member_to_emember'])) {
            //$result = (array)get_users('blog_id='.$GLOBALS['blog_id']);
            $query = "SELECT ID,user_login FROM $wpdb->users";
            $result = $wpdb->get_results($query, ARRAY_A);
            $wp_user_data = array();
            $wp_user_data['membership_level'] = $_POST['wp_users_membership_level'];
            $wp_user_data['account_state'] = $_POST['wp_users_account_state'];
            $wp_user_data['subscription_starts'] = $_POST['wp_users_subscription_starts'];
            $wp_user_data['preserve_wp_role'] = $_POST['wp_users_preserve_wp_role'];
            foreach ($result as $row) {
                $wp_user_data['ID'] = $row['ID'];
                $updated = wp_eMember_add_user_record($wp_user_data);
                if ($updated === false) {
                    $_SESSION['flash_message'] = '<div id="message" style= "color:red;" class="updated fade"><p>' . __('Failed to update "' . $row['user_login'] . '"', 'wp_eMember') . __('Member Info.', 'wp_eMember') . '</p></div>';
                    break;
                }
            }
            $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>Member info updated.</p></div>';
            echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage";</script>';
            return;
        } else if (isset($_POST['submit'])) {
            $updated = false;
            foreach ($_POST['selected_wp_users'] as $row) {
                if (isset($row['ID'])) {
                    $updated = wp_eMember_add_user_record($row);
                }
            }
            if ($updated === false) {
                $_SESSION['flash_message'] = '<div id="message" style= "color:red;" class="updated fade"><p>Failed to update member info.</p></div>';
            } else {
                $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>Member info updated.</p></div>';
                echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage";</script>';
                return;
            }
        }
        ?>
        <div class="wrap">
            <p><strong>You can either import all of your WordPress users to eMember in one go or selectively import users from this interface.</strong></p>

            <h3>Import All WordPress Users</h3>
            <form method="post" action="">
                <table class="widefat" >
                    <thead>
                        <tr>
                            <th scope="col">Import All Users to eMember</th>
                            <th scope="col">Membership Level</th>
                            <th scope="col">Subscription Starts From</th>
                            <th scope="col">Account State</th>
                            <th scope="col">Preserve Role</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr valign="top">
                            <td>
                                <input type="checkbox" value="1" name="wp_add_wp_member_to_emember">
                            </td>
                            <td>
                                <select name="wp_users_membership_level">
                                    <?php
                                    foreach ($all_levels as $l):
                                        ?>
                                        <option value="<?php echo $l->id; ?>"><?php echo stripslashes($l->alias); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="date" class="emember_date_picker" value="<?php echo date('Y-m-d'); ?>" name="wp_users_subscription_starts" id="wp_users_subscription_starts" >
                            </td>
                            <td>
                                <select name="wp_users_account_state">
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                    <option value="blocked">Blocked</option>
                                </select>
                            </td>
                            <td>
                                <input type="checkbox" value="1" checked="checked" name="wp_users_preserve_wp_role">
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p class="submit">
                    <input name="add_to_wp" class="button-primary" type="submit" value="Submit" />
                </p>
            </form>

            <hr>
            <h3>Import WordPress Users Selectively</h3>
            <form action="javascript:void(0);" id="emember_user_search">
                <p class="search-box">
                    <label for="post-search-input" class="screen-reader-text">Search Users:</label>
                    <input type="text" value="" name="term" title="Search term " id="post-search-term" size="30" />
                    <input type="submit" class="button" value="Search Users"/>
                </p>
            </form>
            <div id="emember_Pagination" class="emember_pagination"></div>
            <form method="post">
                <table class="widefat" id="wp_member_list">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Membership Level</th>
                            <th scope="col">Subscription Starts From</th>
                            <th scope="col">Account State</th>
                            <th scope="col">Preserve Role</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <p class="submit">
                    <input name="submit" class="button-primary" type="submit" value="Submit" />
                </p>
            </form>
            <script type="text/javascript">
                /* <![CDATA[ */
                var $j = jQuery.noConflict();
                function drawContent(count, params) {
                    var counter = 0;
                    var itms_per_pg = parseInt(<?php
                                $items_per_page = $emember_config->getValue('eMember_rows_per_page');
                                $items_per_page = trim($items_per_page);
                                echo (!empty($items_per_page) && is_numeric($items_per_page)) ? $items_per_page : 30;
                                ?>);
                    var $tbody = $j('#wp_member_list tbody');
                    $j("#emember_Pagination").pagination(count, {
                        callback: function (i, container) {
                            var preloader = '<?php echo emember_preloader(7); ?>';
                            $tbody.html(preloader);
                            var paramss = {};
                            if (params)
                                paramss = {
                                    action: "wp_user_list_ajax",
                                    event: "wp_user_list_ajax",
                                    start: i * itms_per_pg,
                                    limit: itms_per_pg,
                                    t: params.t
                                };
                            else
                                paramss = {
                                    action: "wp_user_list_ajax",
                                    event: "wp_user_list_ajax",
                                    start: i * itms_per_pg,
                                    limit: itms_per_pg
                                };
                            var maxIndex = Math.min((i + 1) * itms_per_pg, count);
                            var target_url = '<?php echo admin_url("admin-ajax.php"); ?>';
                            $j.get(target_url,
                                    paramss,
                                    function (data) {
                                        data = $j(data);
                                        $tbody.html(data.filter('tbody').html());
                                        window.eval(data.filter('script').html());
                                    },
                                    'html'
                                    );
                        },
                        num_edge_entries: 2,
                        num_display_entries: 10,
                        items_per_page: itms_per_pg
                    });
                }
                $j(document).ready(function () {
                    var count = <?php echo $wp_member_count->count; ?>;
                    drawContent(count);
                    $j('#emember_user_search').submit(function (e) {
                        e.prevenDefault;
                        var term = $j('#post-search-term').val();
                        var q = "t=" + term;
                        var params = {action: "emember_wp_user_count_ajax",
                            event: "emember_wp_user_count_ajax",
                            t: term
                        };

                        if (term != "") {
                            var target_url = '<?php echo admin_url("admin-ajax.php"); ?>';
                            $j.get(target_url, params,
                                    function (data) {
                                        drawContent(data.count, {t: term});
                                    },
                                    'json'
                                    );
                        }
                        return false;
                    });
                    /*****************/
                });
                /*]]>*/
            </script>
        </div>
        <?php
    }

    function wp_eMember_manage_memebers_lists() {

        //Set default date to 30 if a value was not posted.
        $emember_soon_to_expire_days = isset($_REQUEST['emember_soon_to_expire_days'])? sanitize_text_field($_REQUEST['emember_soon_to_expire_days']): '30';
	$emember_recently_expired_days = isset($_REQUEST['emember_recently_expired_days'])? sanitize_text_field($_REQUEST['emember_recently_expired_days']): '30';

        ?>
        <div id="poststuff"><div id="post-body">
                <div class="postbox">
                    <h3 class="hndle"><label for="title">Member Email Options</label></h3>
                    <div class="inside">
                        <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
                            <input type="hidden" name="wp_eMember_display_email_list_for_id" id="wp_eMember_display_email_list_for_id" value="true" />
                            <table width="100%" border="0" cellspacing="0" cellpadding="6">
                                <tr valign="top">
                                    <td width="25%" align="left">
                                        <strong>1)</strong> Display Member Email List for a Particular Membership Level:
                                    </td>
                                    <td align="left">
                                        <input name="wp_eMember_mem_level_id" type="text" size="5" value="<?php echo isset($wp_eMember_mem_level_id) ? $wp_eMember_mem_level_id : ""; ?>" />
                                        <input type="submit" class="button" name="wp_eMember_display_email_list_for_id" value="Display List" />
                                        <p class="description">Enter the ID of the membership level that you want to display the member email list for (comma separated) and hit Display List.</p>
                                    </td>
                                </tr>
                            </table>
                        </form>

                        <br />
                        <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
                            <input type="hidden" name="wp_eMember_display_all_member_email" id="wp_eMember_display_all_member_email" value="true" />
                            <table width="100%" border="0" cellspacing="0" cellpadding="6">
                                <tr valign="top">
                                    <td width="25%" align="left">
                                        <strong>2)</strong> Display Email List of All Members:
                                    </td>
                                    <td align="left">
                                        <input type="radio" name="wp_eMember_display_member_email" value="active" /> Active Members Only
                                        <input type="radio" name="wp_eMember_display_member_email" value="expired" /> Expired Members Only
                                        <input type="submit" class="button" name="wp_eMember_display_all_member_email" value="Display All Members Email List" />
                                        <p class="description">Use this to display a list of emails (comma separated) of all the members for bulk emailing purpuse.</p>
                                    </td>
                                </tr>
                            </table>
                        </form>
                        <br/>
                        <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
                            <table width="100%" border="0" cellspacing="0" cellpadding="6">
                                <tr valign="top">
                                    <td width="25%" align="left">
                                        <strong>3)</strong> Export All Members Info:
                                    </td>
                                    <td align="left">
                                        <p class="description">This option has been moved to the <a href="admin.php?page=wp_eMember_manage&members_action=export_members_data" target="_blank">Export Data</a> tab.</p>
                                    </td>
                                </tr>
                            </table>
                        </form>

                        <br />
                        <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
                            <table width="100%" border="0" cellspacing="0" cellpadding="6">
                                <tr valign="top">
                                    <td width="25%" align="left">
                                        <strong>4)</strong> Display Soon to Expire Member List:
                                    </td>
                                    <td align="left">
                                        <input name="emember_soon_to_expire_days" type="text" size="5" value="<?php echo isset($emember_soon_to_expire_days) ? $emember_soon_to_expire_days : ""; ?>" />
                                        &nbsp;Days&nbsp;
                                        <input type="submit" class="button" name="emember_display_soon_to_expire_users_submit" value="Display Soon to Expire List" />
                                        <p class="description">Enter the number of days then hit the display button to see a soon to expire members list.</p>
                                    </td>
                                </tr>
                            </table>
                        </form>

                        <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
                            <table width="100%" border="0" cellspacing="0" cellpadding="6">
                                <tr valign="top">
                                    <td width="25%" align="left">
                                        <strong>4)</strong> Display Recently Expired Member List:
                                    </td>
                                    <td align="left">
                                        <input name="emember_recently_expired_days" type="text" size="5" value="<?php echo isset($emember_recently_expired_days) ? $emember_recently_expired_days : ""; ?>" />
                                        &nbsp;Days&nbsp;
                                        <input type="submit" class="button" name="emember_display_recently_expired_users_submit" value="Display Recently Expired List" />
                                        <p class="description">Enter the number of days then hit the display button to see a recently expired members list.</p>
                                    </td>
                                </tr>
                            </table>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <?php
        global $wpdb;
        $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
        $emember_config = Emember_Config::getInstance();

        if (isset($_POST['wp_eMember_display_email_list_for_id'])) {
            $selected_level_id = (string) $_POST["wp_eMember_mem_level_id"];

            if ($emember_config->getValue('eMember_enable_secondary_membership')) {//Multiple levels per user is enabled
                $ret_member_db = $wpdb->get_results("
                    SELECT * FROM $member_table WHERE
                    membership_level = '$selected_level_id' OR
                    more_membership_levels = '$selected_level_id' OR
                    more_membership_levels LIKE '%," . $selected_level_id . ",%' OR
                    more_membership_levels LIKE '" . $selected_level_id . ",%' OR
                    more_membership_levels LIKE '%," . $selected_level_id . "'
                    ", OBJECT);
            } else {
                $ret_member_db = $wpdb->get_results("SELECT * FROM $member_table WHERE membership_level = '$selected_level_id'", OBJECT);
            }

            echo wp_eMember_display_member_email_list($ret_member_db);
        }

        if (isset($_POST['wp_eMember_display_all_member_email'])) {
            $query = "SELECT * FROM $member_table ";
            if (isset($_POST['wp_eMember_display_member_email']))
                $query .= " WHERE account_state ='" . trim($_POST['wp_eMember_display_member_email']) . "' ";

            $query .= " ORDER BY member_id DESC";
            $ret_member_db = $wpdb->get_results($query, OBJECT);
            echo wp_eMember_display_member_email_list($ret_member_db);
        }

        if (isset($_POST['emember_display_soon_to_expire_users_submit'])) {
            //Display a list of soon to expire members
            $list_record_count = 0;
            $steml_output = '';
            $ret_member_db = $wpdb->get_results("SELECT * FROM $member_table ORDER BY member_id", OBJECT);

            $steml_output .= '<h2>Soon to Expire Members List</h2>';
            $steml_output .= '<p>The following table shows a list of members whose account will expire within the next '.$emember_soon_to_expire_days.' days.</p>';
            $steml_output .= '<table class="widefat">';
            $steml_output .= '<thead>';
            $steml_output .= '<tr>';
            $steml_output .= '<th>Member ID</th><th>Username</th><th>Email</th><th>First Name</th><th>Last Name</th><th>Membership Level</th><th>Expiry Date</th>';
            $steml_output .= '</tr>';
            $steml_output .= '</thead>';
            $steml_output .= '<tbody>';

            foreach ($ret_member_db as $result) {
                $member_id = $result->member_id;
                $account_state = $result->account_state;
                $level_name = emember_get_membership_level_name_by_id($result->membership_level);
                $expiry_date = emember_get_expiry_by_member_id($member_id);

                if ($expiry_date == 'noexpire'){
                    //This member is part of a no expiry or until cancelled level. So go to the next record.
                    continue;
                }

                if ($account_state == 'expired' || $account_state == 'inactive'){
                    //This member's account is expired. Exclude him from this list.
                    continue;
                }

                //Check if the expiry date is within the specified cutoff date.
                $days_string = '+'.$emember_soon_to_expire_days.' days';
                $cutoff_date_string = strtotime($days_string);
                $expiry_date_string = strtotime($expiry_date);
                if ($expiry_date_string > $cutoff_date_string){
                    //The expiry date is outside of the given cutoff date. So go to the next record.
                    continue;
                }

                $steml_output .= '<tr>';
                $steml_output .= '<td>'.$member_id.'</td><td>'.$result->user_name.'</td><td>'.$result->email.'</td><td>'.$result->first_name.'</td><td>'.$result->last_name.'</td><td>'.$level_name.'</td><td>'.$expiry_date.'</td>';
                $steml_output .= '</tr>';
                $list_record_count++;
            }

            //Show a message if the result output was nil.
            if($list_record_count < 1){
                $steml_output .= '<tr><td colscope="6">No members found for the given criteria.</td></tr>';
            }

            $steml_output .= '</tbody>';
            $steml_output .= '</table>';
            $steml_output .= '<p>Total number of records: '.$list_record_count.'</p>';
            echo $steml_output;
        }

        if (isset($_POST['emember_display_recently_expired_users_submit'])) {
            //Display a list of soon to expire members
            $list_record_count = 0;
            $steml_output = '';
            $ret_member_db = $wpdb->get_results("SELECT * FROM $member_table ORDER BY member_id", OBJECT);

            $steml_output .= '<h2>Recently Expired Members List</h2>';
            $steml_output .= '<p>The following table shows a list of members whose account expired within the last '.$emember_recently_expired_days.' days.</p>';
            $steml_output .= '<table class="widefat">';
            $steml_output .= '<thead>';
            $steml_output .= '<tr>';
            $steml_output .= '<th>Member ID</th><th>Username</th><th>Email</th><th>First Name</th><th>Last Name</th><th>Membership Level</th><th>Expiry Date</th>';
            $steml_output .= '</tr>';
            $steml_output .= '</thead>';
            $steml_output .= '<tbody>';

            foreach ($ret_member_db as $result) {
                $member_id = $result->member_id;
                $account_state = $result->account_state;
                $level_name = emember_get_membership_level_name_by_id($result->membership_level);
                $expiry_date = emember_get_expiry_by_member_id($member_id);

                if ($account_state != 'expired' && $account_state != 'inactive'){
                    //This member's account is NOT expired. Exclude from this list. This list is only interested in looking at expired profiles.
                    continue;
                }

                //Check if the expiry date is within the specified cutoff date.
                $days_string = '-'.$emember_recently_expired_days.' days';
                $cutoff_date_string = strtotime($days_string);
                $expiry_date_string = strtotime($expiry_date);

                if ( $cutoff_date_string > $expiry_date_string ){
                    //Exclude this profile. The expiry date is outside of the given cutoff date. So go to the next record.
                    continue;
                }

                $steml_output .= '<tr>';
                $steml_output .= '<td>'.$member_id.'</td><td>'.$result->user_name.'</td><td>'.$result->email.'</td><td>'.$result->first_name.'</td><td>'.$result->last_name.'</td><td>'.$level_name.'</td><td>'.$expiry_date.'</td>';
                $steml_output .= '</tr>';
                $list_record_count++;
            }

            //Show a message if the result output was nil.
            if($list_record_count < 1){
                $steml_output .= '<tr><td colscope="6">No members found for the given criteria.</td></tr>';
            }

            $steml_output .= '</tbody>';
            $steml_output .= '</table>';
            $steml_output .= '<p>Total number of records: '.$list_record_count.'</p>';
            echo $steml_output;
        }

    }

    function wp_eMember_display_member_email_list($ret_member_db) {
        $output = '';
        $output .= '<h2>Member Email List</h2>';
        if ($ret_member_db) {
            foreach ($ret_member_db as $ret_member_db) {
                $output .= $ret_member_db->email;
                $output .= ', ';
            }
        } else {
            $output .= '<strong>No members found.</strong>';
        }
        return $output;
    }

    function wp_eMember_delete_member() {
        global $wpdb;
        $timestamp = isset($_GET['confirm']) ? trim($_GET['confirm']) : "0";
        if (isset($_SESSION['emember_deleterecord'][$timestamp])) {
            $privileged_profiles = $_SESSION['emember_deleterecord'][$timestamp];
            foreach ($privileged_profiles as $profile) {
                if ($profile['wp_user_id'])
                    wp_delete_user($profile['wp_user_id'], 1); //assigns all related to this user to admin.
                $query = 'DELETE FROM ' . WP_EMEMBER_MEMBERS_TABLE_NAME . ' WHERE member_id = ' . $profile['member_id'];
                $wpdb->query($query);
                $query = 'DELETE FROM ' . WP_EMEMBER_MEMBERS_META_TABLE . ' WHERE user_id = ' . $profile['member_id']
                        . ' AND meta_key=\'custom_field\'';
                $wpdb->query($query);
            }
            unset($_SESSION['emember_deleterecord'][$timestamp]);
        }
        else {
            if (isset($_REQUEST['members']))
                $records = implode(',', array_map('absint', $_REQUEST['members']));
            else if (isset($_REQUEST['deleterecord']))
                $records = absint($_REQUEST['deleterecord']);
            if (isset($records) && !empty($records)) {
                $query = "SELECT user_name, member_id FROM " . WP_EMEMBER_MEMBERS_TABLE_NAME .
                        " WHERE member_id IN (" . $records . ')';
                $profiles = $wpdb->get_results($query, ARRAY_A);
                $privileged_profiles = array();
                foreach ($profiles as $profile) {
                    $wp_user_id = username_exists($profile['user_name']);
                    $ud = get_userdata($wp_user_id);
                    if (!empty($ud) && (isset($ud->wp_capabilities['administrator']) || ($ud->wp_user_level == 10))) {
                        $profile['wp_user_id'] = $wp_user_id;
                        $privileged_profiles[] = $profile;
                    } else {
                        if ($wp_user_id)
                            wp_delete_user($wp_user_id, 1); //assigns all related to this user to admin.
                        $query = "DELETE FROM " . WP_EMEMBER_MEMBERS_TABLE_NAME . " WHERE member_id = " . $profile['member_id'];
                        $wpdb->query($query);
                        $query = 'DELETE FROM ' . WP_EMEMBER_MEMBERS_META_TABLE . ' WHERE user_id = ' . $profile['member_id']
                                . ' AND meta_key=\'custom_field\'';
                        $wpdb->query($query);
                    }
                }
                if (count($privileged_profiles) > 0) {
                    $curtimestamp = time();
                    unset($_SESSION['emember_deleterecord']);
                    $_SESSION['emember_deleterecord'][$curtimestamp] = $privileged_profiles;
                    $u = "admin.php";
                    $_GET['confirm'] = $curtimestamp;
                    $u .= '?' . http_build_query($_GET);
                    $warning = "<div id='message' style=\"color:red;\" ><p>You are about to delete an account that has admin privilege.<br/>
                If you are using WordPress user integration then this will delete the corresponding user <br/>
                account from WordPress and you may not be able to log in as admin with this account.<br/>";
                    $warning .= "Continue? <a href='" . $u . "'>yes</a>/<a href='javascript:void(0);' onclick='jQuery(\"#message\").remove();top.document.location=\"admin.php?page=wp_eMember_manage\";' >no</a></p></div>";
                    $warning .='Following User(s) have administrative privileges:<br/>';
                    $warning .= '<table class="wp-list-table widefat fixed users" style="width:400px;"><tr><th>User</th><th>WP profile</th><th>eMember profile</th></tr>';
                    foreach ($privileged_profiles as $profile) {
                        $warning .= "<tr><td>" . $profile['user_name'] . "</td>";
                        $warning .= "<td><a target='_blank' href='user-edit.php?user_id=" . $profile['wp_user_id'] . "'>View</a></td>";
                        $warning .= "<td><a target='_blank' href='admin.php?page=wp_eMember_manage&members_action=add_edit&editrecord=" . $profile['wp_user_id'] . "'>View</a></td>";
                        $warning .="</tr>";
                    }
                    $warning .="</table>";
                    return $warning;
                }
            }
        }
        return 0;
    }

    function wp_eMember_sub_header($sub_header) {
        echo $sub_header;
    }

    function wp_eMember_admin_updated_message($msg) {
        echo '<div id="message" class="updated fade"><p>' . __($msg, 'wp_eMember') . '</p></div>';
    }

    function wp_eMember_manage_members() {
        $emember_config = Emember_Config::getInstance();
        if (isset($_POST['emember_member_limit_update'])) {
            $emember_config->setValue('emember_members_menu_pagination_value', trim($_POST["emember_members_menu_pagination_value"]));

            echo '<div id="message" class="updated fade"><p>';
            echo 'Per Page Member Records Display Value Updated!';
            echo '</p></div>';
            $emember_config->saveConfig();
        }

        //Render the member list using the WP List Table.
        $memberlist = new EmemberMemberList();
        $all_levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
        include_once('views/member_list_view.php');

        //Notes
        echo '<div class="eMember_grey_box"><p>';
        echo '<strong>Notes:</strong>';
        echo '<br />1. The above list only shows a summary details of each member. You can click on the edit link for a member to see the full details of the user.';
        echo '<br />2. A member account with no username value means the account registration is not complete yet (the user has not chosen a username and password for the account yet).';
        echo '<p></div>';
        ?>
        <form method="post" action="">
            Display <input name="emember_members_menu_pagination_value" type="text" size="4" value="<?php echo $emember_config->getValue('emember_members_menu_pagination_value'); ?>"/>
            Member Records Per Page
            <input type="submit" name="emember_member_limit_update" class="button" value="Update" />
        </form>
        <?php
    }

    function wp_eMember_add_memebers() {
        $emember_config = Emember_Config::getInstance();
        global $wpdb;
        $d = WP_EMEMBER_URL . '/images/default_image.gif';
        //If being edited, grab current info
        if (isset($_GET['editrecord']) && ($_GET['editrecord'] != '')) {
            $theid = intval($_GET['editrecord']);
            if( !is_numeric($theid)){
                //Fatal error.
                wp_die('<p>Error! The edit record ID value is not numeric. This is not a valid request.</p>');
                return;
            }
            
            //Query the record
            $editingrecord = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . $theid);
            if( !$editingrecord ){
                //Fatal error.
                wp_die('<p>Error! Could not find any member record for the given ID value. This is not a valid request.</p>');
                return;
            }
            
            //Get custom fields
            $edit_custom_fields = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . $theid . ' AND meta_key="custom_field"');
            $edit_custom_fields = isset($edit_custom_fields->meta_value) ? unserialize($edit_custom_fields->meta_value) : array();
            //$editingrecord->more_membership_levels = explode(',', $editingrecord->more_membership_levels);
            $editingrecord = (array) $editingrecord;
            $image_url = null;
            $image_path = null;
            $upload_dir = wp_upload_dir();
            $upload_url = $upload_dir['baseurl'] . '/emember/';
            $upload_path = $upload_dir['basedir'] . '/emember/';
            $use_gravatar = $emember_config->getValue('eMember_use_gravatar');
            if ($use_gravatar) {
                $image_url = WP_EMEMBER_GRAVATAR_URL . "/" .
                        md5(strtolower($editingrecord['email'])) .
                        "?d=" . urlencode($d) . "&s=" . 96;
            } else if (!empty($editingrecord['profile_image'])) {
                $image_url = $upload_url . $editingrecord['profile_image'];
                $image_path = $theid;
            } else {
                $image_path = "";
                $image_url = WP_EMEMBER_URL . '/images/default_image.gif';
            }
        }
        if (isset($_POST['Submit'])) {
            global $wpdb;
            include_once(ABSPATH . WPINC . '/class-phpass.php');
            $wp_hasher = new PasswordHash(8, TRUE);
            $post_editedrecord = filter_input(INPUT_POST, 'editedrecord');
            $fields = array();
            $fields['flags'] = 0;
            $fields['more_membership_levels_start_date'] = '';
            if ($emember_config->getValue('eMember_enable_secondary_membership')) {
                $fields['more_membership_levels'] = implode(',', empty($_POST['more_membership_levels']) ? array() :
                                $_POST['more_membership_levels']);
            }
            $fields["user_name"] = filter_input(INPUT_POST, 'user_name');
            $fields["first_name"] = filter_input(INPUT_POST, 'first_name');
            $fields["last_name"] = filter_input(INPUT_POST, 'last_name');
            $fields["company_name"] = filter_input(INPUT_POST, 'company_name');
            $member_since = filter_input(INPUT_POST, 'member_since');
            if(empty($member_since)){
                $member_since = (date("Y-m-d"));
            }
            $fields["member_since"] = $member_since;
            $fields["membership_level"] = filter_input(INPUT_POST, 'membership_level');
            $fields["account_state"] = filter_input(INPUT_POST, 'account_state');
            $fields["email"] = filter_input(INPUT_POST, 'email');
            $fields["phone"] = filter_input(INPUT_POST, 'phone');
            $fields["address_street"] = filter_input(INPUT_POST, 'address_street');
            $fields["address_city"] = filter_input(INPUT_POST, 'address_city');
            $fields["address_state"] = filter_input(INPUT_POST, 'address_state');
            $fields["address_zipcode"] = filter_input(INPUT_POST, 'address_zipcode');
            $fields["home_page"] = filter_input(INPUT_POST, 'home_page');
            $fields["country"] = filter_input(INPUT_POST, 'country');
            $fields["gender"] = filter_input(INPUT_POST, 'gender');
            $fields["referrer"] = filter_input(INPUT_POST, 'referrer');
            $fields["subscription_starts"] = filter_input(INPUT_POST, 'subscription_starts');
            $fields["autoupgrade_starts"] = filter_input(INPUT_POST, 'autoupgrade_starts');
            $fields["subscr_id"] = filter_input(INPUT_POST, 'subscr_id');
            if (!is_admin()) {
                $fields['last_accessed_from_ip'] = get_real_ip_addr();
            }
            $fields["notes"] = filter_input(INPUT_POST, 'notes');
            $wp_user_info = array();
            //$wp_user_info['user_nicename'] = implode('-', explode(' ', filter_input(INPUT_POST, 'user_name')));
            //$wp_user_info['nickname'] = filter_input(INPUT_POST, 'user_name');
            //$wp_user_info['display_name'] = filter_input(INPUT_POST, 'user_name');
            $wp_user_info['user_email'] = filter_input(INPUT_POST, 'email');
            $wp_user_info['first_name'] = filter_input(INPUT_POST, 'first_name');
            $wp_user_info['last_name'] = filter_input(INPUT_POST, 'last_name');
            if ($emember_config->getValue('eMember_enable_secondary_membership')) {
                $start_dates = array();
                $start_dates_in = $_POST['more_membership_levels_start_date'];
                if (isset($_POST['more_membership_levels'])) { //todo:
                    foreach ((array) $_POST['more_membership_levels'] as $id) {
                        $id = absint($id);
                        if ($id == $fields["membership_level"]) {
                            $start_dates[$id] = $fields["subscription_starts"];
                            continue;
                        }
                        if (array_key_exists($id, $start_dates_in)) {
                            $start_dates[$id] = $start_dates_in[$id];
                        }
                        if (array_key_exists($id, $start_dates))
                            continue;
                        $start_dates[$id] = date('Y-m-d');
                    }
                }
                $fields['more_membership_levels_start_date'] = json_encode($start_dates);
            }
            if ($post_editedrecord == '') {
                //A new member record is being added (admin side)
                $fields['user_name'] = filter_input(INPUT_POST, 'user_name');
                $wp_user_info['user_login'] = filter_input(INPUT_POST, 'user_name');
                // Add the record to the DB
                include_once ('emember_validator.php');
                $validator = new Emember_Validator();
                $validator->add(array('value' => $fields['user_name'], 'label' => 'User Name', 'rules' => array('user_required', 'user_name', 'user_unavail', 'user_minlength')));
                $validator->add(array('value' => filter_input(INPUT_POST, 'password'), 'repeat' => filter_input(INPUT_POST, 'retype_password'), 'label' => 'Password', 'rules' => array('pass_required', 'pass_mismatch')));
                $validator->add(array('value' => $fields['email'], 'label' => 'Email', 'rules' => array('email_required', 'email_unavail')));
                $messages = $validator->validate();
                if (count($messages) > 0) {
                    echo '<span class="emember_error">' . implode('<br/>', $messages) . '</span>';
                    $editingrecord = $_POST;
                } else {
                    $password = $wp_hasher->HashPassword(filter_input(INPUT_POST, 'password'));
                    $fields['password'] = esc_sql($password);
                    //$ret = dbAccess::insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
                    $ret = $wpdb->insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
                    $lastid = $wpdb->insert_id;
                    $should_create_wp_user = $emember_config->getValue('eMember_create_wp_user');
                    if ($should_create_wp_user) {
                        $role_names = array(1 => 'Administrator', 2 => 'Editor', 3 => 'Author', 4 => 'Contributor', 5 => 'Subscriber');
                        $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" . $fields['membership_level'] . "'");
                        $wp_user_info['role'] = $membership_level_resultset->role;
                        $wp_user_info['user_registered'] = date('Y-m-d H:i:s');
                        //$wp_user_id = wp_create_user($_POST['user_name'], $_POST['password'], $_POST['email']);
                        $wp_user_id = eMember_wp_create_user(filter_input(INPUT_POST, 'user_name'), filter_input(INPUT_POST, 'password'), filter_input(INPUT_POST, 'email'), $wp_user_info);
                        //do_action( 'set_user_role', $wp_user_id, $membership_level_resultset->role );
                    }

                    ///custom field insert
                    if (isset($_POST['emember_custom']))
                        $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE .
                                '( user_id, meta_key, meta_value ) VALUES(' . $lastid . ',"custom_field",' . '\'' . addslashes(serialize($_POST['emember_custom'])) . '\')');
                    if ($ret === false)
                        $_SESSION['flash_message'] = '<div id="message" style = "color:red;" class="updated fade"><p>Couldn\'t create new member.</p></div>';
                    else {
                        if (isset($_POST['uploaded_profile_img'])) {
                            $upload_dir = wp_upload_dir();
                            $upload_path = $upload_dir['basedir'];
                            $upload_path .= '/emember/';

                            $ext = explode('.', $_POST['uploaded_profile_img']);
                            rename($upload_path . $_POST['uploaded_profile_img'], $upload_path . $lastid . '.' . $ext[1]);
                        }
                        $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>Member &quot;' .
                                $fields['user_name'] . '&quot; created.</p></div>';

                        //Notify the newly created member if specified in the settings
                        if ($emember_config->getValue('eMember_email_notification_for_manual_member_add')) {
                            $login_link = $emember_config->getValue('login_page_url');
                            $member_email_address = $_POST['email'];

                            $subject_rego_complete = $emember_config->getValue('eMember_email_subject_rego_complete');
                            $body_rego_complete = $emember_config->getValue('eMember_email_body_rego_complete');
                            $from_address = $emember_config->getValue('senders_email_address');
                            $headers = 'From: ' . $from_address . "\r\n";

                            $curr_member_id = $lastid;
                            $additional_params = array('password' => $_POST['password'], 'login_link' => $login_link);
                            $email_body1 = emember_dynamically_replace_member_details_in_message($curr_member_id, $body_rego_complete, $additional_params);
                            wp_mail($member_email_address, $subject_rego_complete, $email_body1, $headers);
                        }

                        //Create the corresponding affliate account if specified in the settings
                        if ($emember_config->getValue('eMember_auto_affiliate_account')) {
                            eMember_handle_affiliate_signup($_POST['user_name'], $_POST['password'], $_POST['first_name'], $_POST['last_name'], $_POST['email'], '');
                        }

                        /* Signup the member to Autoresponder List (Autoresponder integration) */
                        eMember_log_debug("===> Performing autoresponder signup if needed (member was added via admin dashboard) <===", true);
                        $membership_level_id = filter_input(INPUT_POST, 'membership_level');
                        $firstname = filter_input(INPUT_POST, 'first_name');
                        $lastname = filter_input(INPUT_POST, 'last_name');
                        $emailaddress = filter_input(INPUT_POST, 'email');
                        eMember_level_specific_autoresponder_signup($membership_level_id, $firstname, $lastname, $emailaddress);
                        eMember_global_autoresponder_signup($firstname, $lastname, $emailaddress);
                        /* End of autoresponder integration */

                        $custom_fields = isset($_POST['emember_custom'])? $_POST['emember_custom'] : array();
                        do_action('eMember_registration_complete_admin_side', $fields, $custom_fields);

                        echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage";</script>';
                    }
                }
            } else {
                //Member profile edited (admin side)
                if (isset($_POST['emember_custom'])) {
                    $custom_fields = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . $post_editedrecord . ' AND meta_key=\'custom_field\'');
                    if ($custom_fields)
                        $wpdb->query('UPDATE ' . WP_EMEMBER_MEMBERS_META_TABLE .
                                ' SET meta_value =' . '\'' . addslashes(serialize($_POST['emember_custom'])) . '\' WHERE meta_key = \'custom_field\' AND  user_id=' . $post_editedrecord);
                    else
                        $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE .
                                '( user_id, meta_key, meta_value ) VALUES(' . $post_editedrecord . ',"custom_field",' . '\'' . addslashes(serialize($_POST['emember_custom'])) . '\')');
                }else {
                    $wpdb->query('DELETE FROM ' . WP_EMEMBER_MEMBERS_META_TABLE .
                            '  WHERE meta_key = \'custom_field\' AND  user_id=' . $post_editedrecord);
                }

                $editingrecord = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . $post_editedrecord);
                // Update the member info
                $member_id = $post_editedrecord;
                $wp_user_id = username_exists($fields['user_name']);
                $wp_email_owner = email_exists($fields['email']);
                $emember_email_owner = emember_email_exists($fields['email']);
                if (empty($fields['user_name']) || ($fields['user_name'] != $editingrecord->user_name)) {
                    echo '<div id="message" class="updated fade"><p>User Name Cannot Be Changed!</p></div>';
                } else if (empty($fields['email'])) {
                    echo '<div id="message" class="updated fade"><p>Email Field is Empty!</p></div>';
                } else if (($wp_email_owner && ($wp_user_id != $wp_email_owner)) || ($emember_email_owner && ($member_id != $emember_email_owner))) {
                    echo '<div id="message" class="updated fade"><p>Email ID &quot;' .
                    $fields['email'] . '&quot; is already registered to a user!</p></div>';
                } else {
                    $update_possible = true;
                    if (!empty($_POST['password'])) {
                        if ($_POST['password'] === $_POST['retype_password']) {
                            $password = $wp_hasher->HashPassword($_POST['password']);
                            $fields['password'] = esc_sql($password);
                            $wp_user_info['user_pass'] = $_POST['password'];
                        } else {
                            $update_possible = false;
                            echo '<div id="message" class="updated fade"><p>Password does\'t match!</p></div>';
                        }
                    }
                    if ($update_possible) {
                        $ret = $wpdb->update(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields, array('member_id' => $member_id));
                        if ($fields["membership_level"] != $editingrecord->membership_level)
                            do_action('emember_membership_changed', array('member_id' => $editingrecord->member_id,
                                'from_level' => $editingrecord->membership_level,
                                'to_level' => $fields["membership_level"]));

                        if ($wp_user_id && !is_wp_error($wp_user_id)) {
                            $wp_user_info['ID'] = $wp_user_id;
                            wp_update_user($wp_user_info);
                            if (($editingrecord->flags & 1) != 1) {
                                $cond = " id='" . $fields['membership_level'] . "'";
                                $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, $cond);
                                update_wp_user_Role($wp_user_id, $membership_level_resultset->role);
                                //do_action( 'set_user_role', $wp_user_id, $membership_level_resultset->role );
                            }
                        }
                        if ($ret === false) {
                            $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>' . __('Member', 'wp_eMember') . ' &quot;' .
                                    $fields['user_name'] . '&quot; ' . __('Update Failed.', 'wp_eMember') . '</p></div>';
                        } else {
                            $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>' . __('Member', 'wp_eMember') . ' &quot;' .
                                    $fields['user_name'] . '&quot; ' . __('updated.', 'wp_eMember') . '</p></div>';
                            if (isset($_POST['account_status_change'])) {
                                $from_address = $emember_config->getValue('senders_email_address');
                                $headers = 'From: ' . $from_address . "\r\n";
                                $member_email_address = $_POST['email'];
                                $login_link = $emember_config->getValue('login_page_url');
                                $additional_params = array('password' => $_POST['password'], 'login_link' => $login_link);
                                $curr_member_id = $post_editedrecord;
                                $subject_post = stripslashes($_POST['notificationmailhead']);
                                $email_body_post = stripslashes($_POST['notificationmailbody']);
                                $email_body = emember_dynamically_replace_member_details_in_message($curr_member_id, $email_body_post, $additional_params);
                                wp_mail($member_email_address, $subject_post, $email_body, $headers);
                                $emember_config->setValue('eMember_status_change_email_body', $email_body_post);
                                $emember_config->setValue('eMember_status_change_email_subject', $subject_post);
                                $emember_config->saveConfig();
                            }
                            $fields['member_id'] = $post_editedrecord;
                            $fields['account_state_before_edit'] = $editingrecord->account_state;
                            $fields['email_before_edit'] = $editingrecord->email;
                            $fields['membership_level_before_edit'] = $editingrecord->membership_level;
                            $fields['more_membership_levels_before_edit'] = $editingrecord->more_membership_levels;

                            $custom_fields = isset($_POST['emember_custom'])? $_POST['emember_custom'] : array();

                            do_action('eMember_registration_updated_admin_side', $fields, $custom_fields);
                            do_action('eMember_profile_updated_admin_side', $fields, $custom_fields);

                            echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage";</script>';
                        }
                    }
                }
                $editingrecord = (array) $editingrecord;
            }
        }

        $all_levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
        include_once ('views/add_member_view.php');
    }
