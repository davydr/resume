<?php

function emember_is_ajax() {
    return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && (strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'));
}

function emember_ajax_login() {
    check_ajax_referer('emember-login-nonce');
    $emember_auth = Emember_Auth::getInstance();//This will do the authentication.
    $emember_config = Emember_Config::getInstance();

    $msg = $emember_auth->getMsg();
    $level_spec_login_url = $emember_auth->getLevelInfo('loginredirect_page');
    $own_url = $emember_auth->getUserInfo('home_page');

    $redirect_expired = $emember_config->getValue('eMember_redirect_expired_user');
    if($redirect_expired){
        $status = $emember_auth->getUserInfo('account_state');
        if($status == 'expired'){
            $expired_redirect_url = $emember_config->getValue('eMember_redirect_expired_page_url');
            $own_url = $expired_redirect_url;//Set the own redirect variable with this value so it gets priority and the expired user gets redirected.
        }
    }

    echo json_encode(array(
        'status' => $emember_auth->isLoggedIn(),
        'msg' => $msg,
        'redirect' => array('own' => $own_url, 'level' => $level_spec_login_url)
        ));
    exit(0);
}

function wp_emem_delete_image() {
    $emember_auth = Emember_Auth::getInstance();
    if (current_user_can(EMEMBER_MANAGEMENT_PERMISSION)) {
        wp_emem_process_delete_image(strip_tags($_GET['path']));
    } else {
        if (!$emember_auth->isLoggedIn()){
            die("You are not logged in.");
        }
        wp_emem_process_delete_image($emember_auth->getUserInfo('member_id'));
    }
}

function wp_emem_process_delete_image($id) {
    global $wpdb;
    $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
    $query = "SELECT profile_image from " . $member_table . " WHERE member_id = " . $id;
    $old_file = $wpdb->get_col($query);
    $wpdb->update($member_table, array('profile_image' => ''), array('member_id' => $id));
    $upload_dir = wp_upload_dir();
    $upload_path = $upload_dir['basedir'] . '/emember/';
    if (!empty($old_file[0]))
        @unlink($upload_path . $old_file[0]);
    echo json_encode(array('status' => "done", 'payload' => 'deleted.'));
    ob_start();
    do_action('eMember_profile_image_removed', $id);
    ob_end_clean();
    exit(0);
}

function wp_emem_get_post_preview() {
    $post_content = get_post($_POST['id'], OBJECT);
    echo '<h2>' . $post_content->post_title . '</h2>';
    echo $post_content->post_content;
    exit(0);
}

function wp_emem_upload_file() {
    $emember_auth = Emember_Auth::getInstance();
    if (current_user_can(EMEMBER_MANAGEMENT_PERMISSION))
        wp_emem_process_fileupload(strip_tags($_GET['image_id']));
    else {
        if (!$emember_auth->isLoggedIn()){
            die("You are not logged in");
        }
        wp_emem_process_fileupload($emember_auth->getUserInfo('member_id'));
    }
}

function wp_emem_process_fileupload($id) {
    //check_ajax_referer('emember-upload-profile-image-nonce');
    global $wpdb;
    $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
    $upload_dir = wp_upload_dir();
    $upload_path = $upload_dir['basedir'] . '/emember/';
    $upload_url = $upload_dir['baseurl'] . '/emember/';
    $query = "SELECT profile_image from " . $member_table . " WHERE member_id = " . $id;
    $old_file = $wpdb->get_col($query);
    if (!file_exists($upload_path) || !is_dir($upload_path)) {
        mkdir($upload_path, 0755, true);
        file_put_contents($upload_path . 'index.html', " ");
    }
    if (!empty($old_file[0]))
        @unlink($upload_path . $old_file[0]);
    // list of valid extensions, ex. array("jpeg", "xml", "bmp")
    $allowedExtensions = array('jpg', 'png', 'gif', 'bmp', 'jpeg');//Profile image upload so only allow image extensions
    // max file size in bytes
    $sizeLimit = 10 * 1024 * 1024;
    $uploader = new EmemberFileUploader($allowedExtensions, $sizeLimit);
    $result = $uploader->handleUpload($upload_path, true, $id);
    if (isset($result['success'])) {
        $wpdb->update($member_table, array('profile_image' => $result['filename']), array('member_id' => $id));
        $result['id'] = $id;
    }
    // to pass data through iframe you will need to encode all html tags
    echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
    ob_start();
    do_action('eMember_profile_image_uploaded', $result);
    ob_end_clean();
    exit(0);
}

function wp_emem_user_count_ajax() {
    global $wpdb;
    if (!current_user_can(EMEMBER_MANAGEMENT_PERMISSION)){
        die("Access Forbidden");
    }

    $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
    $condition = "";
    if (!empty($_GET['t'])) {
        $_GET['t'] = strip_tags($_GET['t']);
        $_GET['t'] = sanitize_text_field( $_GET['t'] );

        $condition = 'user_name LIKE \'%' . $_GET['t'] . '%\' OR email LIKE \'%' . $_GET['t'] . '%\'' .
                ' OR first_name LIKE \'%' . $_GET['t'] . '%\' OR last_name LIKE \'%' . $_GET['t'] . '%\'' .
                ' OR address_street LIKE \'%' . $_GET['t'] . '%\' OR address_city LIKE \'%' . $_GET['t'] . '%\'' .
                ' OR address_state LIKE \'%' . $_GET['t'] . '%\' OR country LIKE \'%' . $_GET['t'] . '%\'';
    }
    if (isset($_GET['ac']) && ($_GET['ac'] != -1)) {
        if (!empty($condition))
            $condition .= ' AND ';
        $condition .= ' account_state=\'' . emember_sanitize_text( $_GET['ac'] ) . '\'';
    }
    if (isset($_GET['mem']) && ($_GET['mem'] != -1)) {
        if (!empty($condition))
            $condition .= ' AND ';
        $condition .= ' membership_level=' . emember_sanitize_text( $_GET['mem'] );
    }
    if (empty($condition))
        $q = "SELECT COUNT(*) as count FROM " . $member_table . ' ORDER BY member_id';
    else
        $q = "SELECT COUNT(*) as count FROM " . $member_table . " WHERE $condition ORDER BY member_id";
    $emember_user_count = $wpdb->get_row($q);
    echo json_encode($emember_user_count);
    exit(0);
}

function wp_emem_wp_user_count_ajax() {
    if (!current_user_can(EMEMBER_MANAGEMENT_PERMISSION)){
        die("Access Forbidden");
    }

    global $wpdb;
    if (!empty($_GET['t'])) {
        $params = array('blog_id' => $GLOBALS['blog_id'], 'offset' => $_GET['start'], 'number' => $_GET['limit'], 'search' => $_GET['t']);
    } else {
        $params = array('blog_id' => $GLOBALS['blog_id'], 'offset' => $_GET['start'], 'number' => $_GET['limit']);
    }
    $wp_users = get_users($params);
    echo json_encode(array('count' => count($wp_users)));
    exit(0);
}

function wp_emem_wp_user_list_ajax() {
    global $wpdb;
    if (!current_user_can(EMEMBER_MANAGEMENT_PERMISSION)){
        wp_die("Access Forbidden");
    }

    if (!empty($_GET['t'])) {
        $params = array('blog_id' => $GLOBALS['blog_id'], 'offset' => $_GET['start'], 'number' => $_GET['limit'], 'search' => $_GET['t']);
    } else {
        $params = array('blog_id' => $GLOBALS['blog_id'], 'offset' => $_GET['start'], 'number' => $_GET['limit']);
    }
    $wp_users = get_users($params);
    //echo json_encode($wp_users);
    $all_levels = Emember_Level_Collection::get_instance()->get_levels();
    if (count($wp_users) > 0):
        ?>
        <tbody>
            <?php
            $count = 0;
            foreach ($wp_users as $wp_user):
                ?>
                <tr valign="top" <?php echo ($count % 2) ? "class='emember-alternate'" : ""; ?>>
                    <td scope="row"><input type="checkbox" value="<?php echo $wp_user->ID; ?>" name="selected_wp_users[<?php echo $count ?>][ID]"></td>
                    <td><?php echo $wp_user->user_login; ?></td>
                    <td><?php echo $wp_user->user_email; ?></td>
                    <td><select name="selected_wp_users[<?php echo $count ?>][membership_level]">
                            <?php
                            foreach ($all_levels as $l):
                                ?>
                                <option value="<?php echo $l->get('id'); ?>"><?php echo $l->get('alias'); ?></option>
            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <input type="date" class="emember_date_picker" value="<?php echo date('Y-m-d'); ?>" name="selected_wp_users[<?php echo $count ?>][subscription_starts]" />
                    </td>
                    <td><select name="selected_wp_users[<?php echo $count ?>][account_state]">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="blocked">Blocked</option>
                        </select>
                    </td>
                    <td><input type="checkbox" value="1" name="selected_wp_users[<?php echo $count ?>][preserve_wp_role]" checked="checked"></td>
                </tr>
                <?php
                $count++;
            endforeach;
        else:
            ?>
            <tr valign="top">
                <td colspan="7"><?php echo EMEMBER_DATA_NOT_FOUND; ?></td>
            </tr>
        <?php
        endif;
        ?>
    </tbody>
    <?php
    exit(0);
}

function wp_emem_add_bookmark() {
    check_ajax_referer('emember-add-bookmark-nonce');
    if (wp_doing_ajax()) {
        global $wpdb;
        $emember_auth = Emember_Auth::getInstance();
        $emember_config = Emember_Config::getInstance();
        $emember_auth->add_bookmark(array($_GET['id']));
        $a1 = '<span title="Bookmarked" class="count">
              <span class="c">&radic;</span><br/>
              <span class="t">' . EMEMBER_FAVORITE . '</span></span>
              <span title="Bookmarked" class="emember">' . EMEMBER_ADDED . '</span>';
        echo json_encode(array('status' => 1, 'msg' => $a1));
        exit(0);
    }
}

function item_list_ajax() {
    if (!current_user_can(EMEMBER_MANAGEMENT_PERMISSION)){
        die("Access Forbidden");
    }

    global $wpdb;
    $levelId = $_REQUEST['level'];
    $tab = $_REQUEST['tab'];
    if (wp_doing_ajax()) {
        $level = ($levelId == 1 ) ? Emember_Protection::get_instance() :
                Emember_Permission::get_instance($levelId);
        switch ($tab) {
            case 'pages':
                $args = array(
                    'child_of' => 0,
                    'sort_order' => 'ASC',
                    'sort_column' => 'post_title',
                    'hierarchical' => 0,
                    'parent' => -1,
                    'number' => $_GET['limit'],
                    'offset' => $_GET['start']);
                $all_pages = get_pages($args);
                $filtered_pages = array();
                foreach ($all_pages as $page) {
                    $page_summary = array();
                    $user_info = get_userdata($page->post_author);
                    $page_summary['protected'] = $level->in_pages($page->ID) ? "checked='checked'" : "";
                    $page_summary['bookmark'] = $level->is_bookmark_disabled($page->ID) ? "checked='checked'" : "";
                    $page_summary['ID'] = $page->ID;
                    $page_summary['date'] = $page->post_date;
                    $page_summary['title'] = $page->post_title;
                    $page_summary['author'] = $user_info->user_login;
                    $page_summary['status'] = $page->post_status;
                    $filtered_pages[] = $page_summary;
                }
                ob_start();
                include ('views/emember_page_protection_view.php');
                $output = ob_get_contents();
                ob_end_clean();
                echo $output;
                break;
            case 'posts':
                $sql = "SELECT ID,post_date,post_title,post_author, post_type, post_status FROM $wpdb->posts ";
                $sql .= " WHERE post_type = 'post' AND post_status = 'publish' LIMIT " . $_REQUEST['start'] . " , " . $_REQUEST['limit'];
                $all_posts = $wpdb->get_results($sql);
                $filtered_posts = array();
                foreach ($all_posts as $post) {
                    //if($post->post_type=='page')continue;
                    $post_summary = array();
                    $user_info = get_userdata($post->post_author);
                    $categories = get_the_category($post->ID);
                    $cat = array();
                    foreach ($categories as $category)
                        $cat[] = $category->category_nicename;
                    $post_summary['protected'] = $level->in_posts($post->ID) ? "checked='checked'" : "";
                    $post_summary['bookmark'] = $level->is_bookmark_disabled($post->ID) ? "checked='checked'" : "";
                    $post_summary['ID'] = $post->ID;
                    $post_summary['date'] = $post->post_date;
                    $post_summary['title'] = isset($post->post_title) ? $post->post_title : "";
                    $post_summary['author'] = $user_info->user_login;
                    $post_summary['categories'] = rawurldecode(implode(' ', $cat));
                    $post_summary['type'] = $post->post_type;
                    $post_summary['status'] = $post->post_status;
                    $filtered_posts[] = $post_summary;
                }
                ob_start();
                include ('views/emember_post_protection_view.php');
                $output = ob_get_contents();
                ob_end_clean();
                echo $output;
                break;
            case 'comments':
                $all_comments = get_comments(array('number' => $_GET['limit'], 'offset' => $_GET['start'], 'status' => 'approve'));
                $filtered_comments = array();
                foreach ($all_comments as $comment) {
                    $comment_summary = array();
                    $comment_summary['protected'] = $level->in_comments($comment->comment_ID) ? "checked='checked'" : "";
                    $comment_summary['ID'] = $comment->comment_ID;
                    $comment_summary['date'] = $comment->comment_date;
                    $comment_summary['author'] = $comment->comment_author;
                    $comment_summary['content'] = $comment->comment_content;
                    $filtered_comments[] = $comment_summary;
                }
                ob_start();
                include ('views/emember_comment_protection_view.php');
                $output = ob_get_contents();
                ob_end_clean();
                echo $output;
                break;
            case 'categories':
                $all_categories = array();
                $taxonomies = get_taxonomies($args = array('public' => true,'_builtin'=>false));
                $taxonomies['category'] = 'category';
                $all_terms = get_terms( $taxonomies, 'orderby=count&hide_empty=0&order=DESC');
                for ($i = $_GET['start']; $i < ($_GET['start'] + $_GET['limit']) && !empty($all_terms[$i]); $i++){
                    $all_categories[] = $all_terms[$i];
                }

                foreach ($all_categories as $category) {
                    $category_summary = array();
                    $category_summary['protected'] = $level->in_categories($category->term_id) ? "checked='checked'" : "";
                    $category_summary['ID'] = $category->term_id;
                    $category_summary['name'] = $category->name;
                    $category_summary['description'] = $category->description;
                    $category_summary['taxonomy'] = $category->taxonomy;
                    $category_summary['count'] = $category->count;
                    $filtered_categories[] = $category_summary;
                }
                ob_start();
                include ('views/emember_category_protection_view.php');
                $output = ob_get_contents();
                ob_end_clean();
                echo $output;
                break;
            case 'attachments':
                $sql = "SELECT ID,post_date,post_title,post_author, post_type, post_status FROM $wpdb->posts ";
                $sql .= " WHERE post_type = 'attachment' AND post_status = 'inherit' LIMIT " . $_REQUEST['start'] . " , " . $_REQUEST['limit'];
                $all_posts = $wpdb->get_results($sql);
                $filtered_posts = array();
                foreach ($all_posts as $post) {
                    $post_summary = array();
                    $user_info = get_userdata($post->post_author);
                    $post_summary['protected'] = $level->in_attachments($post->ID) ? "checked='checked'" : "";
                    $post_summary['ID'] = $post->ID;
                    $post_summary['date'] = $post->post_date;
                    $post_summary['title'] = isset($post->post_title) ? $post->post_title : "";
                    $post_summary['author'] = $user_info->user_login;
                    $post_summary['type'] = $post->post_type;
                    $post_summary['status'] = $post->post_status;
                    $filtered_posts[] = $post_summary;
                }

                ob_start();
                include ('views/emember_attachment_protection_view.php');
                $output = ob_get_contents();
                ob_end_clean();
                echo $output;
                break;
            case 'custom-posts':
                $filtered_posts = array();
                $args = array('public' => true, '_builtin' => false);
                $post_types = get_post_types($args);
                $arg = "'" . implode('\',\'', $post_types) . "'";
                if (!empty($arg)) {
                    $sql = "SELECT ID,post_date,post_title,post_author, post_type, post_status FROM $wpdb->posts ";
                    $sql .= " WHERE post_type IN (" . $arg . ") AND (post_status='inherit' OR post_status='publish') LIMIT " . $_REQUEST['start'] . " , " . $_REQUEST['limit'];
                    $all_posts = $wpdb->get_results($sql);
                    $filtered_posts = array();
                    foreach ($all_posts as $post) {
                        $post_summary = array();
                        $user_info = get_userdata($post->post_author);
                        $post_summary['protected'] = $level->in_custom_posts($post->ID) ? "checked='checked'" : "";
                        $post_summary['ID'] = $post->ID;
                        $post_summary['date'] = $post->post_date;
                        $post_summary['title'] = isset($post->post_title) ? $post->post_title : "";
                        $post_summary['author'] = $user_info->user_login;
                        $post_summary['type'] = $post->post_type;
                        $post_summary['status'] = $post->post_status;
                        $filtered_posts[] = $post_summary;
                    }
                }
                ob_start();
                include ('views/emember_custom_protection_view.php');
                $output = ob_get_contents();
                ob_end_clean();
                echo $output;
                break;
        }
    }
    exit(0);
}

function wp_emem_send_mail() {
    check_ajax_referer('emember-login-nonce');
    if (wp_doing_ajax()){
        echo json_encode(wp_emember_generate_and_mail_password($_GET['email']));
    }
    exit(0);
}

function wp_emem_check_level_name() {
    if ( wp_doing_ajax() ) {
	global $wpdb;
        $field_id = emember_sanitize_text( $_GET[ 'fieldId' ] );
	$alias = emember_sanitize_text ( $_GET[ 'fieldValue' ] );
	$user = dbAccess::find( WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' alias=\'' . $alias . '\'' );
	if ( $user && $_GET[ 'event' ] === 'check_level_name_edit' ) {
	    //membership edit event
	    if ( isset( $_GET[ 'hidden_id' ] ) && ! empty( $_GET[ 'hidden_id' ] ) ) {
		if ( $_GET[ 'hidden_id' ] == $user->id ) {
		    echo '[ "' . $field_id . '",true, "&radic;&nbsp;' . EMEMBER_STILL_AVAIL . '"]';
		    exit( 0 );
		} else {
		    echo '[ "' . $field_id . '",false, "&chi;&nbsp;' . EMEMBER_ALREADY_TAKEN . '"]';
		    exit( 0 );
		}
	    }
	}
	if ( $user )
	    echo '[ "' . $field_id . '",false, "&chi;&nbsp;' . EMEMBER_ALREADY_TAKEN . '"]';
	else
	    echo '[ "' . $field_id . '",true, "&radic;&nbsp;' . EMEMBER_STILL_AVAIL . '"]';
    }
    exit( 0 );
}

function wp_emem_check_user_name() {
    if (wp_doing_ajax()) {
        $field_id = emember_sanitize_text( $_GET[ 'fieldId' ] );

        include_once ('emember_validator.php');
        if (!Emember_Validator::is_valid_user_name($_GET['fieldValue'])){
            echo '[ "' . $field_id . '",false, "&chi;&nbsp;' . EMEMBER_USER_NAME_VALIDATION_MESSAGE . '"]';
        }
        else if (emember_wp_username_exists($_GET['fieldValue'])) {
            echo '[ "' . $field_id . '",false, "&chi;&nbsp;' . EMEMBER_ALREADY_TAKEN . '"]';
        } else {
            global $wpdb;
            $user_name = filter_input(INPUT_GET, 'fieldValue');
            if (emember_username_exists($user_name)) {
                echo '[ "' . $field_id . '",false, "&chi;&nbsp;' . EMEMBER_ALREADY_TAKEN . '"]';
            } else {
                echo '[ "' . $field_id . '",true, "&radic;&nbsp;' . EMEMBER_STILL_AVAIL . '"]';
            }
        }
    }
    exit(0);
}

function access_list_ajax() {
    if (!current_user_can(EMEMBER_MANAGEMENT_PERMISSION)){
        die("Access Forbidden");
    }

    $emember_config = Emember_Config::getInstance();
    $items_per_page = $emember_config->getValue('eMember_rows_per_page');
    $items_per_page = trim($items_per_page);
    $items_per_page = (!empty($items_per_page) && is_numeric($items_per_page)) ? $items_per_page : 30;
    $count = 0;
    $tab = $_REQUEST['tab'];
    $levelId = $_REQUEST['level'];
    if (wp_doing_ajax()) {
        global $wpdb;
        switch ($_REQUEST['tab']) {
            case 'comments':
                $num_comm = get_comment_count();
                $count = $num_comm['approved'];
                break;
            case 'posts':
                $query = "SELECT count(*) from $wpdb->posts WHERE post_status='publish' AND post_type='post'";
                $count = $wpdb->get_var($query);
                break;
            case 'pages':
                $count = wp_count_posts('page');
                $count = $count->publish;
                break;
            case 'categories':
                $count = wp_count_terms('category');
                break;
            case 'attachments':
                $query = "SELECT count(*) from $wpdb->posts WHERE post_status='inherit' AND post_type='attachment'";
                $count = $wpdb->get_var($query);
                break;
            case 'custom-posts':
                $args = array('public' => true, '_builtin' => false);
                $post_types = get_post_types($args);
                $arg = "'" . implode('\',\'', $post_types) . "'";
                if (empty($arg)) {
                    $count = 0;
                } else {
                    $query = "SELECT count(*) from $wpdb->posts WHERE (post_status='inherit' OR post_status='publish') AND post_type IN (" . $arg . ")";
                    $count = $wpdb->get_var($query);
                }
                break;
        }
        ob_start();
        include ('js/membership_level.php');
        $output = ob_get_contents();
        ob_end_clean();
        echo $output;
    }
    exit(0);
}

function emember_fileuploader() {
    if (!current_user_can(EMEMBER_MANAGEMENT_PERMISSION)){
        die("Access Forbidden");
    }

    $upload_dir = wp_upload_dir();
    $dir = $upload_dir['basedir'] . '/emember/downloads/';

    // List of valid extensions for the folder protection feature. Example: array("jpeg", "jpg", "zip")
    // For admin side allow more file type uploads
    $allowedExtensions = array(
        'avi',
        'csv',
        'doc',
        'docx',
        'gif',
        'htm',
        'html',
        'jpeg',
        'jpg',
        'mov',
        'mp3',
        'mp4',
        'pdf',
        'png',
        'ppt',
        'pptx',
        'rar',
        'svg',
        'txt',
        'wav',
        'xls',
        'xlsx',
        'zip'
    );

    $uploader = new EmemberFileUploader($allowedExtensions);
    $result = $uploader->handleUpload($dir);
    if (isset($result['success'])) {
        global $wpdb;
        $guid = $upload_dir['baseurl'] . '/emember/downloads/' . $result['filename'];
        $date = date('Y-m-d H:i:s');
        $filename = $uploader->getFilename();
        emember_add_uploaded_file_to_inventory($filename, $guid, $date);
    }
    // to pass data through iframe you will need to encode all html tags
    echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
    exit(0);
}

function emember_load_membership_form() {
    if (!current_user_can(EMEMBER_MANAGEMENT_PERMISSION)){
        die("Access Forbidden");
    }

    global $wpdb;
    $id = strip_tags($_POST['id']);
    $subscription_period = "";
    $subscription_unit = "";
    $fixed_date = "";
    if (empty($id)) {
        $role = "subscriber";
        $name = "";
        $loginredirect = "";
        $campaign_name = "";
        $expire = 'noexpire';
        $allpages = 'checked="checked"';
        $allcategories = 'checked="checked"';
        $allposts = 'checked="checked"';
        $allcomments = 'checked="checked"';
        $allattachments = 'checked="checked"';
        $allcustomposts = 'checked="checked"';
        $protect_older_posts = "";
    } else {
        $level = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id = '" . esc_sql($id) . " ' ");
        $role = $level->role;
        $name = htmlspecialchars($level->alias);
        $loginredirect = $level->loginredirect_page;
        $campaign_name = $level->campaign_name;
        if (empty($level->subscription_period) && empty($level->subscription_unit))
            $expire = 'noexpire';
        else if (empty($level->subscription_period)) {
            $expire = 'fixed_date';
            $fixed_date = $level->subscription_unit;
        } else {
            $expire = 'interval';
            $subscription_period = $level->subscription_period;
            $subscription_unit = $level->subscription_unit;
        }
        $allpages = (($level->permissions & 8) === 8) ? 'checked="checked"' : "";
        $allcategories = (($level->permissions & 1) === 1) ? 'checked="checked"' : "";
        $allposts = (($level->permissions & 4) === 4) ? 'checked="checked"' : "";
        $allcomments = (($level->permissions & 2) === 2) ? 'checked="checked"' : "";
        $allattachments = (($level->permissions & 16) === 16) ? 'checked="checked"' : "";
        $allcustomposts = (($level->permissions & 32) === 32) ? 'checked="checked"' : "";
        $protect_older_posts = empty($level->protect_older_posts)? "": 'checked="checked"';
    }

    require_once('views/add_membership_level_view.php');
    exit(0);
}
