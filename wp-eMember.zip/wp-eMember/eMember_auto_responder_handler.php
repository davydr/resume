<?php

use \eMember\MailChimp\MailChimp;

function eMember_aweber_new_signup_user($full_target_list_name, $fname, $lname, $email_to_subscribe) {
    eMember_log_debug("Attempting to signup the user via AWeber API", true);
    if (empty($full_target_list_name)) {
        eMember_log_debug("Listname value is empty for this request. So no AWeber signup will be performed for it.", false);
        return;
    }

    $emember_config = Emember_Config::getInstance();
    $eMember_aweber_access_keys = $emember_config->getValue('eMember_aweber_access_keys');
    if (empty($eMember_aweber_access_keys['consumer_key'])) {
        eMember_log_debug("Missing AWeber access keys! You need to first make a conntect before you can use this API", false);
        return;
    }
    if (!class_exists('AWeberAPI')) {//TODO - change the class name to "eMember_AWeberAPI" to avoid conflict with others
        include_once('lib/auto-responder/aweber_api/aweber_api.php');
        eMember_log_debug("AWeber API library inclusion succeeded.", true);
    } else {
        eMember_log_debug("AWeber API library is already included from another plugin.", true);
    }
    try {
        $aweber = new AWeberAPI($eMember_aweber_access_keys['consumer_key'], $eMember_aweber_access_keys['consumer_secret']);
        $account = $aweber->getAccount($eMember_aweber_access_keys['access_key'], $eMember_aweber_access_keys['access_secret']); //Get Aweber account
        $account_id = $account->id;
        $mylists = $account->lists;
    } catch (Exception $e) {
        eMember_log_debug($e->getMessage(), false);
        return;
    }
    eMember_log_debug("AWeber account retrieved. Account ID: " . $account_id, true);

    $target_list_name = str_replace("@aweber.com", "", $full_target_list_name);
    eMember_log_debug("Attempting to signup the user to the AWeber list: " . $target_list_name, true);
    $list_name_found = false;
    foreach ($mylists as $list) {
        if ($list->name == $target_list_name || $list->unique_list_id == $target_list_name) {
            $list_name_found = true;
            try {//Create a subscriber
                $params = array(
                    'email' => $email_to_subscribe,
                    'name' => $fname . ' ' . $lname,
                );
                $subscribers = $list->subscribers;
                $new_subscriber = $subscribers->create($params);
                eMember_log_debug("User with email address " . $email_to_subscribe . " was added to the AWeber list: " . $target_list_name, true);
            } catch (Exception $exc) {
                eMember_log_debug("Failed to complete the AWeber signup! Error Details Below.", false);
                eMember_log_debug_array($exc, true);
            }
        }
    }
    if (!$list_name_found) {
        eMember_log_debug("Error! Could not find the AWeber list (" . $full_target_list_name . ") in your AWeber Account! Please double check your list name value for typo.", false);
    }
}

function eMember_mailchimp_subscribe($target_list_name, $fname, $lname, $email_to_subscribe) {
    eMember_log_debug("MailChimp target list name: " . $target_list_name, true);

    // let's check if we have interest groups delimiter (|) present. my-list-1 | groupname1, groupname2
    $res_array = explode('|', $target_list_name);
    if (count($res_array) > 1) {
        // we have interest group(s) specified
        // first, let's set list name
        $target_list_name = trim($res_array[0]);
        // now let's get interest group(s). We'll deal with those later.
        $interest_group_names = explode(',', $res_array[1]);
    }

    include_once(WP_EMEMBER_PATH . 'lib/auto-responder/MailChimp.php');
    $emember_config = Emember_Config::getInstance();
    $api_key = $emember_config->getValue('eMember_chimp_api_key');
    if (empty($api_key)) {
        eMember_log_debug("Error! You did not specify your MailChimp API key in the autoresponder settings. MailChimp signup will fail.", false);
        return false;
    }

    try {
        $api = new MailChimp($api_key);
    } catch (Exception $e) {
        eMember_log_debug("MailChimp API error occudred: " . $e->getMessage(), false);
        return false;
    }

    //Get the list id for the target list.
    $list_filter = array();
    $list_filter['list_name'] = $target_list_name;
    $args = array('count' => 100, 'offset' => 0); //By default MC APIv3.0 returns 10 lits only. Use it to retrieve more than 10.
    $all_lists = $api->get('lists', $args);
    $lists_data = $all_lists['lists'];
    $found_match = false;
    foreach ($lists_data as $list) {
        eMember_log_debug("Checking list name : " . $list['name'], true);
        if (strtolower($list['name']) == strtolower($target_list_name)) {
            $found_match = true;
            $list_id = $list['id'];
            eMember_log_debug("Found a match for the list name on MailChimp. List ID :" . $list_id, true);
            break;
        }
    }
    if (!$found_match) {
        eMember_log_debug("Could not find a list name in your MailChimp account that matches with the target list name: " . $target_list_name, false);
        return;
    }
    eMember_log_debug("List ID to subscribe to:" . $list_id, true);

    //send_welcome is no longer used. When member subscribe, it will send welcome email if set in your list settings.
    //Disable double opt-in is now controlled by status field. Set it to "pending" for double opt-in.
    $status = 'pending';
    if ($emember_config->getValue('eMember_mailchimp_disable_double_optin') != '') {
        $status = 'subscribed'; //Don't use double opt-in
    }

    //Let's deal with intrest groups if any
    if (isset($interest_group_names)) {
        //get categories first
        eMember_log_debug("Getting interest categories...", true);
        $retval = $api->get("lists/" . $list_id . "/interest-categories/");
        if (!$api->success()) {
            eMember_log_debug("Unable to get interest categories.", false);
            eMember_log_debug("\tError=" . $api->getLastError(), false);
            return false;
        }
        $categories = $retval['categories'];
        //get groups for each category
        $groups = array();
        eMember_log_debug("Getting interest groups...", true);
        foreach ($categories as $category) {
            $retval = $api->get("lists/" . $list_id . "/interest-categories/" . $category['id'] . "/interests/");
            if (!$api->success()) {
                eMember_log_debug("Unable to get interest groups.", false);
                eMember_log_debug("\tError=" . $api->getLastError(), false);
                return false;
            }
            foreach ($retval['interests'] as $group) {
                unset($group['_links']); // we don't need that
                // might be a good idea to store this data in the settings, in order to lower number of requests to API upon signup?
                $groups[] = $group;
            }
        }
        $interests = array();
        //let's compare interest groups provided by user and get their IDs on match
        foreach ($interest_group_names as $interest_group_name) {
            $interest_group_name = trim($interest_group_name);
            foreach ($groups as $group) {
                if ($group['name'] == $interest_group_name) {
                    //name matches, let's add it to interests array
                    $interests[$group['id']] = true;
                }
            }
        }
    }

    //Create the merge_vars data
    $merge_vars = array('FNAME' => $fname, 'LNAME' => $lname);

    $api_arr = array('email_address' => $email_to_subscribe, 'status_if_new' => $status, 'status' => $status, 'merge_fields' => $merge_vars);
    if (isset($interests)) {
        $api_arr['interests'] = $interests;
    }

    $member_hash = md5(strtolower($email_to_subscribe)); //The MD5 hash of the lowercase version of the list member's email address.
    $retval = $api->put("lists/" . $list_id . "/members/".$member_hash, $api_arr);

    if (!$api->success()) {
        eMember_log_debug("Unable to subscribe.", false);
        eMember_log_debug("Error=" . $api->getLastError(), false);
        return false;
    } else {
        eMember_log_debug("MailChimp Signup was successful.", true);
    }

    return $retval['status'];
}

function eMember_getResponse_subscribe($campaign_name, $fname, $lname, $email_to_subscribe) {
    eMember_log_debug('Attempting to call GetResponse API for list signup...', true);
    $emember_config = Emember_Config::getInstance();
    $api_key = $emember_config->getValue('eMember_getResponse_api_key');

    // API 3.x URL
    $api_url = 'https://api.getresponse.com/v3';
    $customer_name = $fname . " " . $lname;
    eMember_log_debug('API Key:' . $api_key . ', Customer name:' . $customer_name, true);

    //In v3 API, we use the Campaign ID. Admin will enter the campaign ID in the list name field
    $campaign_id = $campaign_name;

    $addcontacturl = 'https://api.getresponse.com/v3/contacts/';
    $getcontacturl = 'https://api.getresponse.com/v3/contacts?query[email]='.$email_to_subscribe;
    $data = array (
    'name' => $customer_name,
    'email' => $email_to_subscribe,
    'dayOfCycle' => 0,
    'campaign' => array('campaignId' => $campaign_id),  //Example - ThwHa
    'ipAddress'=> $_SERVER['REMOTE_ADDR'],
    );

    $data_string = json_encode($data);
    eMember_log_debug('Calling the Getresponse v3 API. Data string: ' . $data_string, true);

    $ch = curl_init($addcontacturl);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'X-Auth-Token: api-key '.$api_key,
    )
    );

    $result = curl_exec($ch);
    //TODO - add extra check to see what the response code or message was.
    //That can be used to determine success or failure. However, the debug output below will have all the useful info
    $result_string = $result;//CURL response is a string.
    eMember_log_debug("GetResponse contact added... result:" . $result_string, true);
    return true;
}

function eMember_generic_autoresponder_signup($firstname, $lastname, $emailaddress, $list_email_address) {
    eMember_log_debug('Preparing to send signup request email for generic autoresponder integration.', true);
    $from_address = $emailaddress; //Use customer email address as the from address for this email

    $subject = "Autoresponder Automatic Sign up email";
    $body = "\n\nThis is an automatic email that is sent to the autoresponder for user signup purpose\n" .
            "\nEmail: " . $emailaddress .
            "\nName: " . $firstname . " " . $lastname;


    $pos = strpos($from_address, "<");
    if ($pos !== false) {
        $from_address = eMember_get_string_between($from_address, "<", ">");
    }
    eMember_log_debug('Sending signup request email via WordPress mailing system. From email address value:' . $from_address, true);
    $headers = 'From: ' . $from_address . "\r\n";
    wp_mail($list_email_address, $subject, $body, $headers);
    eMember_log_debug('Signup email request successfully sent to:' . $list_email_address, true);
    return 1;
}

function eMember_level_specific_autoresponder_signup($membership_level_id, $firstname, $lastname, $emailaddress) {
    eMember_log_debug('Performing membership level specific autoresponder signup if specified.', true);
    $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" . $membership_level_id . "'");
    $list_name = trim($membership_level_resultset->campaign_name);
    // Autoresponder Sign up
    if (!empty($membership_level_resultset->campaign_name)) {
        $emember_config = Emember_Config::getInstance();
        eMember_log_debug('List name specified for this membership level is: ' . $list_name, true);
        if ($emember_config->getValue('eMember_enable_aweber_int') == 1) {
            $from_address = $emember_config->getValue('senders_email_address');
            $senders_email = eMember_get_string_between($from_address, "<", ">");
            if (empty($senders_email)) {
                $senders_email = $from_address;
            }
            $cust_name = $firstname . ' ' . $lastname;
            if ($emember_config->getValue('eMember_use_new_aweber_integration') == '1') {
                eMember_aweber_new_signup_user($list_name, $firstname, $lastname, $emailaddress);
            } else {
                eMember_log_debug('AWeber list to signup to:' . $list_name, true);
                eMember_send_aweber_mail($list_name, $senders_email, $cust_name, $emailaddress);
                eMember_log_debug('AWeber signup from email address used:' . $senders_email, true);
                eMember_log_debug('AWeber signup operation performed for:' . $emailaddress, true);
            }
        }
        if ($emember_config->getValue('eMember_use_mailchimp') == 1) {
            eMember_log_debug('Mailchimp email address to signup:' . $emailaddress, true);
            eMember_log_debug('Mailchimp list to signup to:' . $list_name, true);
            $retval = eMember_mailchimp_subscribe($list_name, $firstname, $lastname, $emailaddress);
            eMember_log_debug('Mailchimp signup operation performed. returned value:' . $retval, true);
        }
        if ($emember_config->getValue('eMember_use_getresponse') == 1) {
            eMember_log_debug('GetResponse email address to signup:' . $emailaddress, true);
            eMember_log_debug('GetResponse campaign to signup to:' . $list_name, true);
            $retval = eMember_getResponse_subscribe($list_name, $firstname, $lastname, $emailaddress);
            eMember_log_debug('GetResponse signup operation performed. returned value:' . $retval, true);
        }
        if ($emember_config->getValue('eMember_use_generic_autoresponder_integration') == '1') {
            eMember_log_debug('Generic autoresponder integration is being used.', true);
            $list_email_address = $list_name;
            $result = eMember_generic_autoresponder_signup($firstname, $lastname, $emailaddress, $list_email_address);
            eMember_log_debug('Generic autoresponder signup result: ' . $result, true);
        }
    }
    // API call for plugins extending the level specific autoresponder signup
    $signup_data = Array('firstname' => $firstname, 'lastname' => $lastname, 'email' => $emailaddress, 'list_name' => $list_name, 'level_id' => $membership_level_id);
    do_action('emember_level_specific_autoresponder_signup', $signup_data);
    eMember_log_debug('End of membership level specific autoresponder signup.', true);
}

function eMember_global_autoresponder_signup($firstname, $lastname, $emailaddress) {
    eMember_log_debug('Performing global autoresponder signup if specified.', true);
    $emember_config = Emember_Config::getInstance();
    if ($emember_config->getValue('eMember_enable_aweber_int') == 1) {
        $global_list_name = trim($emember_config->getValue('eMember_aweber_list_name'));
        if (empty($global_list_name)) {
            //Global list signup is disabled.
            eMember_log_debug('Global AWeber List Name field is empty. No global list signup will be performed.', true);
        } else {
            //Do global AWeber list signup
            $from_address = $emember_config->getValue('senders_email_address');
            $senders_email = eMember_get_string_between($from_address, "<", ">");
            if (empty($senders_email)) {
                $senders_email = $from_address;
            }
            $cust_name = $firstname . ' ' . $lastname;
            if ($emember_config->getValue('eMember_use_new_aweber_integration') == '1') {
                eMember_aweber_new_signup_user($global_list_name, $firstname, $lastname, $emailaddress);
            } else {
                eMember_log_debug('AWeber list to signup to: ' . $global_list_name, true);
                eMember_send_aweber_mail($global_list_name, $senders_email, $cust_name, $emailaddress);
                eMember_log_debug('AWeber signup from email address: ' . $senders_email, true);
            }
            eMember_log_debug('AWeber signup operation performed for: ' . $emailaddress, true);
        }
    }
    if ($emember_config->getValue('eMember_use_mailchimp') == 1) {
        $target_list_name = trim($emember_config->getValue('eMember_chimp_list_name'));
        eMember_log_debug('Mailchimp email address to signup:' . $emailaddress, true);
        eMember_log_debug('Mailchimp list to signup to:' . $target_list_name, true);
        $retval = eMember_mailchimp_subscribe($target_list_name, $firstname, $lastname, $emailaddress);
        eMember_log_debug('Mailchimp signup operation performed. returned value: ' . $retval, true);
    }
    if ($emember_config->getValue('eMember_use_getresponse') == 1) {
        $campaign_name = trim($emember_config->getValue('eMember_getResponse_campaign_name'));
        eMember_log_debug('GetResponse email address to signup:' . $emailaddress, true);
        eMember_log_debug('GetResponse campaign to signup to:' . $campaign_name, true);
        $retval = eMember_getResponse_subscribe($campaign_name, $firstname, $lastname, $emailaddress);
        eMember_log_debug('GetResponse signup operation performed. returned value: ' . $retval, true);
    }
    if ($emember_config->getValue('eMember_use_global_generic_autoresponder_integration') == '1') {
        eMember_log_debug('Generic autoresponder integration is being used.', true);
        $list_email_address = trim($emember_config->getValue('eMember_generic_autoresponder_target_list_email'));
        $result = eMember_generic_autoresponder_signup($firstname, $lastname, $emailaddress, $list_email_address);
        eMember_log_debug('Generic autoresponder signup result: ' . $result, true);
    }

    // API call for plugins extending the global specific autoresponder signup
    $signup_data = Array('firstname' => $firstname, 'lastname' => $lastname, 'email' => $emailaddress);
    do_action('emember_global_autoresponder_signup', $signup_data);

    eMember_log_debug('End of global autoresponder signup.', true);
}
