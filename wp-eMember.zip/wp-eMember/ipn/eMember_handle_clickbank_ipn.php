<?php

if (!defined('ABSPATH')) {
    include_once('../../../../wp-load.php');
}
include_once('eMember_handle_subsc_ipn_stand_alone.php');

$debug_enabled = false;
global $emember_config;
$emember_config = Emember_Config::getInstance();
if ($emember_config->getValue('eMember_enable_debug') == 1) {
    $debug_enabled = true;
}

if ($debug_enabled) {
    echo 'Debug is enabled.';
    if (empty($_REQUEST)) {
        eMember_log_debug('This debug line was generated because you entered the URL of the ipn handling script in the browser.', true, true);
        exit;
    }
}
eMember_log_debug("Clickbank IPN received! Processing IPN ...", true);
eMember_log_debug_array($_REQUEST, true);

//Decode the IPN message and verify the payment
$clickbank_secretKey = $emember_config->getValue('eMember_cb_secret_key'); //YOURSECRETKEY //Get this secret key from your clickbank account info (Account Settings -> My Sites)

// NOTE: the mcrypt libraries need to be installed and listed as an
// available extension in your phpinfo() to be able to use this
// method of decryption.

// get JSON from raw body...
$message = json_decode(file_get_contents('php://input'));
 
// Pull out the encrypted notification and the initialization vector for
// AES/CBC/PKCS5Padding decryption
$encrypted = $message->{'notification'};
$cb_iv = $message->{'iv'};
//eMember_log_debug("Clickbank IPN initialization vector: ".$cb_iv, true);
 
// decrypt the body...
$decrypted = trim(
 openssl_decrypt(base64_decode($encrypted),
 'AES-256-CBC',
 substr(sha1($clickbank_secretKey), 0, 32),
 OPENSSL_RAW_DATA,
 base64_decode($cb_iv)), "\0..\32");
eMember_log_debug($decrypted, true);

////UTF8 Encoding, remove escape back slashes, and convert the decrypted string to a JSON object...
$sanitizedData = utf8_encode(stripslashes($decrypted));
$order = json_decode($decrypted);
//eMember_log_debug_array($order, true);

// Ready to rock and roll - If the decoding of the JSON string wasn't
// successful, then you can assume the notification wasn't encrypted
// with your secret key.
$cb_ipn_verson = $order->version;
if($cb_ipn_verson < 6){
    eMember_log_debug("Clickbank IPN version is not v6. Can't process this IPN", false);
    exit;
}

$cb_email = isset($order->customer->shipping->email)? $order->customer->shipping->email : $order->customer->billing->email;
$cb_fname = isset($order->customer->shipping->firstName)? $order->customer->shipping->firstName : $order->customer->billing->firstName;
$cb_lname = isset($order->customer->shipping->lastName)? $order->customer->shipping->lastName : $order->customer->billing->lastName;
$cb_address1 = $order->customer->shipping->address1;
$cb_address2 = $order->customer->shipping->address2;
$cb_city = $order->customer->shipping->city;
$cb_state = $order->customer->shipping->state;
$cb_zip = $order->customer->shipping->postalCode;
$cb_country = $order->customer->shipping->country;
$txn_id = $order->receipt;
$vendor_variables = $order->vendorVariables;

$cb_ipn_data = array();
$cb_ipn_data['txn_type'] = $order->transactionType;
$cb_ipn_data['payer_email'] = $cb_email;
$cb_ipn_data['first_name'] = $cb_fname;
$cb_ipn_data['last_name'] = $cb_lname;
$cb_ipn_data['address_street'] = $cb_address1 . " " . $cb_address2;
$cb_ipn_data['address_city'] = $cb_city;
$cb_ipn_data['address_state'] = $cb_state;
$cb_ipn_data['address_zip'] = $cb_zip;
$cb_ipn_data['address_country'] = $cb_country;
$cb_ipn_data['txn_id'] = $txn_id;
$cb_ipn_data['custom'] = $vendor_variables;
eMember_log_debug_array($cb_ipn_data, true);

//Custom data
eMember_log_debug_array($vendor_variables, true);
/* 
Sample custom/vendor variables data
stdClass Object
(
    [membership_level_id] => 4
    [x] => 159
    [y] => 44
)
*/
$customvariables = array();
$customvariables['membership_level_id'] = $order->vendorVariables->membership_level_id;

$cb_ipn_data['membership_level_id'] = $customvariables['membership_level_id'];
eMember_log_debug("Payment received for membership level ID:" . $cb_ipn_data['membership_level_id'], true);

//Verify that the notification contains a valid membership level ID
if(empty($cb_ipn_data['membership_level_id']) || !emember_membership_level_id_exists($cb_ipn_data['membership_level_id'])){
    //This membersip level ID is invalid.
    eMember_log_debug("Error! The membership level ID doesn't exist on this site. Can't process this payment.", false);
    exit;
}

//handle the membership payment data
eMember_handle_subsc_signup_stand_alone($cb_ipn_data, $cb_ipn_data['membership_level_id'], $cb_ipn_data['txn_id']);

eMember_log_debug("End of clickbank membership payment processing!", true, true);
