<?php

if (!defined('ABSPATH')) {
    include_once('../../../../wp-load.php');
}

function eMember_handle_subsc_signup_stand_alone($ipn_data, $subsc_ref, $unique_ref, $eMember_id = '') {
    global $wpdb;
    $emember_config = Emember_Config::getInstance();
    $members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
    $login_link = $emember_config->getValue('login_page_url');
    eMember_debug_log_subsc("eMember_handle_subsc_signup_stand_alone(). Membership Level: " . $subsc_ref, true);

    //Check if the old subscriber ID with the character S exists. PayPal used to use it for the premium subscriptions.
    $old_subscr_id = isset($ipn_data['old_subscr_id'])? $ipn_data['old_subscr_id'] : '';
    if(!empty($old_subscr_id)){
        eMember_debug_log_subsc("Old subscriber ID exists. Lets use that as the main subscriber ID. Old Subscriber ID Value: " . $old_subscr_id, true);
        $unique_ref = $old_subscr_id;
    }
    
    if (empty($eMember_id)) {
        $email = $ipn_data['payer_email'];
        $query_db = $wpdb->get_row("SELECT * FROM $members_table_name WHERE email = '$email'", OBJECT);
        if (!$query_db) {//try to retrieve the member details based on the unique_ref
            eMember_debug_log_subsc("Could not find any record using the given email address (" . $email . "). Attempting to query database using the unique reference: " . $unique_ref, true);
            if (!empty($unique_ref)) {
                $query_db = $wpdb->get_row("SELECT * FROM $members_table_name WHERE subscr_id = '$unique_ref'", OBJECT);
                $eMember_id = isset($query_db->member_id) ? $query_db->member_id : '';
            } else {
                eMember_debug_log_subsc("Unique reference is missing in the notification so we have to assume that this is not a payment for an existing member.", true);
            }
        } else {
            $eMember_id = isset($query_db->member_id) ? $query_db->member_id : '';
            eMember_debug_log_subsc("Found a match in the member database. Member ID: " . $eMember_id, true);
        }
    }

    if (!empty($eMember_id)) {//Update the existing member account
        eMember_debug_log_subsc("Modifying the existing membership profile... Member ID: " . $eMember_id, true);
        // upgrade the member account
        $account_state = 'active';
        $membership_level = $subsc_ref;
        $subscription_starts = (date("Y-m-d"));
        $subscr_id = $unique_ref;

        $resultset = "";
        $resultset = $wpdb->get_row("SELECT * FROM $members_table_name where member_id='$eMember_id'", OBJECT);
        if (!$resultset) {
            eMember_debug_log_subsc("ERROR! Could not find a member account record for the given eMember ID: " . $eMember_id, false);
            return;
        }
        $old_membership_level = $resultset->membership_level;
        $old_subscription_start = $resultset->subscription_starts;
        if(empty($old_subscription_start)){
            $old_subscription_start = $subscription_starts;
        }

        if ($emember_config->getValue('eMember_enable_secondary_membership')) {
            //Using secondary level feature.
            eMember_debug_log_subsc("Using secondary membership level feature... adding additional levels to the existing member profile", true);
            $additional_levels = $resultset->more_membership_levels;
            if (is_null($additional_levels)) {
                $additional_levels = $resultset->membership_level;
                eMember_debug_log_subsc("Current additional levels for this profile is null. Adding level: " . $additional_levels, true);
            } else if (empty($additional_levels)) {
                $additional_levels = $resultset->membership_level;
                eMember_debug_log_subsc("Current additional levels for this profile is empty. Adding level: " . $additional_levels, true);
            } else {
                $additional_levels = $additional_levels . "," . $resultset->membership_level;
                $sec_levels = explode(',', $additional_levels);
                $additional_levels = implode(',', array_unique($sec_levels)); //make sure there is no duplicate entry

                eMember_debug_log_subsc("New additional level set: " . $additional_levels, true);
            }
            
            /*******************************************/
            /*** Start of more level start date calc ***/
            $additional_levels_startdate = (array) json_decode($resultset->more_membership_levels_start_date, true);

            //Retrieve level info data for the newly paid level
            $query = $wpdb->prepare("SELECT * FROM " . $wpdb->prefix . "wp_eMember_membership_tbl WHERE id =%d", $membership_level);
            $level_info = $wpdb->get_row($query);
            
            if ($resultset->membership_level == $membership_level) {
                //Payment for the existing primary level. Refresh start date value of this level
                
                //Algorithm - ONLY set the start_date to current expiry date if the current expiry date is in the future. Otherwise set start_date to TODAY.
                $subscription_starts = emember_get_subscription_start_date_by_level($membership_level, $resultset->subscription_starts);
                $additional_levels_startdate[$membership_level] = $subscription_starts;
                eMember_debug_log_subsc("Payment for the existing primary level (".$membership_level."). Refresh the start date: ".$subscription_starts,true);
                
            } else if (isset($additional_levels_startdate[$membership_level])) {
                //Payment for an existing secondary level. Refresh start date value of this level. Also move the current primary level date to the secondary.
                $astart_date = $additional_levels_startdate[$membership_level];
                if (!empty($astart_date)) {//Use existing date data to re-calculate
                    //Algorithm - ONLY set the start_date to current expiry date if the current expiry date is in the future. Otherwise set start_date to TODAY.
                    $subscription_starts = emember_get_subscription_start_date_by_level($membership_level, $astart_date);
                }
                $additional_levels_startdate[$membership_level] = $subscription_starts;
                $additional_levels_startdate[$old_membership_level] = $old_subscription_start;//Moving the current primary date to secondary
                eMember_debug_log_subsc("Payment for the existing secondary level (".$membership_level."). Refresh the start date: ".$subscription_starts,true);
                
            } else {
                //Payment for a new level that doesn't belong in this profile. Move the primary level's date to secondary level.                
                $additional_levels_startdate[$old_membership_level] = $old_subscription_start;
                //$additional_levels_startdate[$membership_level] = $subscription_starts;//This can be used to save the primary level's date in the more level start date also (no harm in doing that).
                eMember_debug_log_subsc("Payment for a brand new level. Moving primary levels start date to secondary level. Start date of the new level: ".$subscription_starts,true);
            }

            $additional_levels_startdate = json_encode($additional_levels_startdate);
            /*** End of more level start date calc ***/
            /*****************************************/

            $membership_level = apply_filters('emember_secondary_before_updating_primary_level', $membership_level, $subsc_ref, $eMember_id);
            $additional_levels = apply_filters('emember_secondary_before_updating_additional_level', $additional_levels, $subsc_ref, $eMember_id); 
            $subscription_starts = apply_filters('emember_secondary_before_updating_primary_start_date', $subscription_starts, $subsc_ref, $eMember_id);
            $additional_levels_startdate = apply_filters('emember_secondary_before_updating_additional_start_date', $additional_levels_startdate, $subsc_ref, $eMember_id);
            
            eMember_debug_log_subsc("Updating primary level column for username: " . $resultset->user_name . " with value: " . $membership_level . ". Primary level start date: " . $subscription_starts, true);
            eMember_debug_log_subsc("Updating additional levels column for username: " . $resultset->user_name . " with value: " . $additional_levels . ". More levels start date: " . $additional_levels_startdate, true);

            $updatedb = "UPDATE $members_table_name SET more_membership_levels='$additional_levels',more_membership_levels_start_date='$additional_levels_startdate' WHERE member_id='$eMember_id'";
            $results = $wpdb->query($updatedb);

            $updatedb = "UPDATE $members_table_name SET account_state='$account_state',membership_level='$membership_level',autoupgrade_starts='$subscription_starts',subscription_starts='$subscription_starts',subscr_id='$subscr_id' WHERE member_id='$eMember_id'";
            $results = $wpdb->query($updatedb);
            eMember_debug_log_subsc("Primary membership level has been updated to the recently paid level. New primary membership level ID for this member is: " . $membership_level, true);

            do_action('emember_membership_changed', array('member_id' => $eMember_id, 'from_level' => $old_membership_level, 'to_level' => $membership_level));
        } else {
            //Not using secondary level feature. Only single membership level per user.
            eMember_debug_log_subsc("Not using secondary membership level feature... upgrading the current membership level of the member.", true);
            $current_expiry_date = emember_get_expiry_by_member_id($eMember_id);
            if ($current_expiry_date != "noexpire") {
                if (strtotime($current_expiry_date) > strtotime($subscription_starts)) {//Expiry time is in the future
                    $subscription_starts = $current_expiry_date; //Start at the end of the previous expiry date
                    eMember_debug_log_subsc("Updating the subscription start date to the current expiry date value: " . $subscription_starts, true);
                }
            }
            eMember_debug_log_subsc("Executing DB update. Debug data: " . $account_state . "|" . $membership_level . "|" . $subscription_starts, true);
            if ($account_state == 'active'){
                //Already active account. Do not update the auto upgrade start date.
                eMember_debug_log_subsc("Account status is already active. The Autoupgrade Start Date will not be updated", true);
                $updatedb = "UPDATE $members_table_name SET account_state='$account_state',membership_level='$membership_level',subscription_starts='$subscription_starts',subscr_id='$subscr_id' WHERE member_id='$eMember_id'";
            } else {
                //Not an active account. Update the auto upgrade start date.
                eMember_debug_log_subsc("Account status is not active. The Autoupgrade Start Date will be updated", true);
                $updatedb = "UPDATE $members_table_name SET account_state='$account_state',membership_level='$membership_level',autoupgrade_starts='$subscription_starts',subscription_starts='$subscription_starts',subscr_id='$subscr_id' WHERE member_id='$eMember_id'";
            }
            $results = $wpdb->query($updatedb);
            do_action('emember_membership_changed', array('member_id' => $eMember_id, 'from_level' => $old_membership_level, 'to_level' => $membership_level));
        }

        //If using the WP user integration then update the role on WordPress too
        $membership_level_table = $wpdb->prefix . "wp_eMember_membership_tbl";
        if ($emember_config->getValue('eMember_create_wp_user')) {
            eMember_debug_log_subsc("Updating WordPress user role...", true);
            $resultset = $wpdb->get_row("SELECT * FROM $members_table_name where member_id='$eMember_id'", OBJECT);
            $membership_level = $resultset->membership_level;
            $username = $resultset->user_name;
            $membership_level_resultset = $wpdb->get_row("SELECT * FROM $membership_level_table where id='$membership_level'", OBJECT);
            eMember_debug_log_subsc("Calling WP role update function. Current users membership level is: " . $membership_level, true);
            emember_update_wp_role_for_member($username, $membership_level_resultset->role);
            //do_action( 'set_user_role', $wp_user_id, $membership_level_resultset->role );
            eMember_debug_log_subsc("Current WP users role updated to: " . $membership_level_resultset->role, true);
        }

        //Set Email details	for the account upgrade notification
        $email = $resultset->email;//Use the existing email address of the member profile for the upgrade email.
        if(empty($email)){
            $email = $ipn_data['payer_email'];//Profile email is empty so use the PayPal payment one.
        }
        $subject = $emember_config->getValue('eMember_account_upgrade_email_subject');
        if (empty($subject)) {
            $subject = "Member Account Upgraded";
        }
        $body = $emember_config->getValue('eMember_account_upgrade_email_body');
        if (empty($body)) {
            $body = "Your account has been upgraded successfully";
        }
        $from_address = get_option('senders_email_address');
        $additional_params = array('login_link' => $login_link);
        $subject = emember_dynamically_replace_member_details_in_message($resultset->member_id, $subject, $additional_params);//Replace merge tags in subject
        $email_body = emember_dynamically_replace_member_details_in_message($resultset->member_id, $body, $additional_params);//Replace merge tags in body
        $headers = 'From: ' . $from_address . "\r\n";
    }// End of existing account upgrade
    else {
        //Create a brand new member account
        
        $email = $ipn_data['payer_email'];
        $membership_level = $subsc_ref;
        $subscr_id = $unique_ref;
        $date = (date("Y-m-d"));
        $reg_code = uniqid();
        $md5_code = md5($reg_code);
        eMember_debug_log_subsc("Membership level ID: " . $membership_level . ", Email: " . $email, true);

        //--------------------------
        $fields = array();
        $fields['user_name'] = '';
        $fields['first_name'] = $ipn_data['first_name'];
        $fields['last_name'] = $ipn_data['last_name'];
        $fields['password'] = '';
        $fields['member_since'] = $date;
        $fields['membership_level'] = $membership_level;
        $fields['account_state'] = 'active';
        $fields['last_accessed'] = $date;
        $fields['last_accessed_from_ip'] = '';
        $fields['email'] = $ipn_data['payer_email'];
        $fields['address_street'] = $ipn_data['address_street'];
        $fields['address_city'] = $ipn_data['address_city'];
        $fields['address_state'] = $ipn_data['address_state'];
        $fields['address_zipcode'] = $ipn_data['address_zip'];
        $fields['country'] = $ipn_data['address_country'];
        $fields['gender'] = 'not specified';
        $fields['referrer'] = '';
        $fields['extra_info'] = '';
        $fields['reg_code'] = $reg_code;
        $fields['subscription_starts'] = $date;
        $fields['txn_id'] = $ipn_data['txn_id'];
        $fields['subscr_id'] = $subscr_id;
        $fields['autoupgrade_starts'] = $date;
        
        $fields = array_filter($fields);//Remove any null values.
        $result = $wpdb->insert($members_table_name, $fields);
        if(!$result){
            eMember_debug_log_subsc("Notice! initial database insert failed on members table. You should set IPN message encdoing to UTF-8 in your PayPal account.", true);
            eMember_debug_log_subsc("Trying the insert query again after converting charset.", true);
            //Convert the default PayPal IPN charset to UTF-8 format            
            $fields['first_name'] = mb_convert_encoding($ipn_data['first_name'], "UTF-8", "windows-1252");
            $fields['last_name'] = mb_convert_encoding($ipn_data['last_name'], "UTF-8", "windows-1252");
            $fields['email'] = mb_convert_encoding($ipn_data['payer_email'], "UTF-8", "windows-1252");
            $fields['address_street'] = mb_convert_encoding($ipn_data['address_street'], "UTF-8", "windows-1252");
            $fields['address_city'] = mb_convert_encoding($ipn_data['address_city'], "UTF-8", "windows-1252");
            $fields['address_state'] = mb_convert_encoding($ipn_data['address_state'], "UTF-8", "windows-1252");
            $fields['address_zipcode'] = mb_convert_encoding($ipn_data['address_zip'], "UTF-8", "windows-1252");
            $fields['country'] = mb_convert_encoding($ipn_data['address_country'], "UTF-8", "windows-1252");
            $result = $wpdb->insert($members_table_name, $fields);
            if(!$result){
                eMember_debug_log_subsc('Error! Failed to add members data into the members database table. DB insert query failed.', false);
            }
        }
        //-------------------------------

        //Retrieve the last inserted member row
        $results = $wpdb->get_row("SELECT * FROM $members_table_name where subscr_id='$subscr_id' and reg_code='$reg_code'", OBJECT);
        $id = $results->member_id; //Alternatively use $wpdb->insert_id;

        $separator = '?';
        $url = $emember_config->getValue('eMember_registration_page');
        if (empty($url)) {
            $url = get_option('eMember_registration_page');
        }
        if (strpos($url, '?') !== false) {
            $separator = '&';
        }
        $reg_url = $url . $separator . 'member_id=' . $id . '&code=' . $md5_code;
        eMember_debug_log_subsc("Member signup URL: " . $reg_url, true);

        $subject = get_option('eMember_email_subject');
        $body = get_option('eMember_email_body');
        $from_address = get_option('senders_email_address');

        //Do the full dynamic member details replacement
        $additional_params = array('login_link' => $login_link, 'reg_link' => $reg_url);
        $subject = emember_dynamically_replace_member_details_in_message($id, $subject, $additional_params);//Replace merge tags in subject
        $email_body = emember_dynamically_replace_member_details_in_message($id, $body, $additional_params);//Replace merge tags in body
        $headers = 'From: ' . $from_address . "\r\n";
        $headers .= 'Reply-To: ' . $from_address . "\r\n";        
    }

    if(strtolower($email_body) == "disabled"){
        eMember_debug_log_subsc("Attention!!! Email body is set to disabled status. No email will be sent for this.", true);
    }
    else{
        wp_mail($email, $subject, $email_body, $headers);
        eMember_debug_log_subsc("Member signup/upgrade completion email successfully sent to: " . $email, true);
    }
}

function eMember_handle_subsc_cancel_stand_alone($ipn_data, $refund = false) {
    $subscr_id = isset($ipn_data['subscr_id']) ? $ipn_data['subscr_id'] : '';
    
    //Check if the old subscriber ID with the character S exists. PayPal used to use it for the premium subscriptions.
    $old_subscr_id = isset($ipn_data['old_subscr_id'])? $ipn_data['old_subscr_id'] : '';
    if(!empty($old_subscr_id)){
        eMember_debug_log_subsc("Old subscriber ID exists. Lets use that as the main subscriber ID. Old Subscriber ID Value: " . $old_subscr_id, true);
        $subscr_id = $old_subscr_id;
    }

    if ($refund) {//This is a refund notification
        if(empty($subscr_id)){//Get the parent txn id
            $subscr_id = $ipn_data['parent_txn_id'];
        }
        eMember_debug_log_subsc("Refund notification check for eMember - check if a member account needs to be deactivated... subscr ID: " . $subscr_id, true);
    }

    global $wpdb;
    $members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
    $membership_level_table = $wpdb->prefix . "wp_eMember_membership_tbl";

    eMember_debug_log_subsc("Retrieving member account from the database...", true);
    $resultset = $wpdb->get_row("SELECT * FROM $members_table_name where subscr_id='$subscr_id'", OBJECT);
    if ($resultset) {//Found a user record
        $member_id = $resultset->member_id;//The eMember ID of the user.
                
        if ($refund) {//This is a refund (not just a subscription cancellation). So deactivate the account regardless.
            emember_update_account_state($member_id, 'inactive');//Set the account status to inactive.
            eMember_debug_log_subsc("Subscription refund notification received! Member account deactivated.", true);
            
            //Handle any affiliate commission refund (if applicable)
            if (function_exists('wp_aff_platform_install')) {
                if (function_exists('wp_aff_handle_refund')) {
                    $parent_txn_id = $ipn_data['parent_txn_id'];
                    eMember_debug_log_subsc('Reverse the commmission for this payment. Parent Txn ID: ' . $parent_txn_id, true);
                    wp_aff_handle_refund($parent_txn_id);
                }
            }
    
            //Trigger the payment refunded hook
            do_action('emember_membership_payment_refunded', $ipn_data);
            return;
        }
    
        //Just a cancellation (no refund). Proceed with the cancellation sequence.
        $membership_level = $resultset->membership_level;
        $level_query = $wpdb->get_row("SELECT * FROM $membership_level_table where id='$membership_level'", OBJECT);
        if (empty($level_query->subscription_period) && empty($level_query->subscription_unit)) {
            //subscription duration is set to no expiry or until canceled so deactivate the account now
            //TODO - if using multiple membership feature and there is more than 1 level, then simply remove this "$membership_level" from the user's profile.
            emember_update_account_state($member_id, 'inactive');//Set the account status to inactive.
            eMember_debug_log_subsc("Subscription cancellation received! Member account deactivated.", true);
        } else if (empty($level_query->subscription_period) && !empty($level_query->subscription_unit)) {//Fixed expiry
            //Subscription duration is set to fixed expiry. Don't do anything.
            eMember_debug_log_subsc("Subscription cancellation received! Level is using fixed expiry date so account will not be deactivated now.", true);
        } else {
            //Set the account to unsubscribed and it will be set to inactive when the "Subscription duration" is over
            emember_update_account_state($member_id, 'unsubscribed');//Set the account status to unsubscribed.
            eMember_debug_log_subsc("Subscription cancellation received! Member account set to unsubscribed.", true);
        }

        $new_rego_code = ''; //Invalidate the user's special rego code
        $updatedb = "UPDATE $members_table_name SET reg_code='$new_rego_code' WHERE subscr_id='$subscr_id'";
        $results = $wpdb->query($updatedb);
        eMember_debug_log_subsc("Subscription cancellation - Member account rego code has been invalidated.", true);

        do_action('emember_membership_cancelled', array('member_id' => $resultset->member_id, 'level' => $membership_level));
    } else {
        eMember_debug_log_subsc("No member found for the given subscriber ID:" . $subscr_id, false);
        return;
    }
}

/*
 * Update the access start date of the member profile (if applicable given his membership level).
 * It also updates the account status to "active" so the user can access the content.
 */
function eMember_update_member_subscription_start_date_if_applicable($ipn_data) {
    global $wpdb;
    $members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
    $membership_level_table = $wpdb->prefix . "wp_eMember_membership_tbl";
    $email = $ipn_data['payer_email'];
    $subscr_id = $ipn_data['subscr_id'];
    eMember_debug_log_subsc("Updating subscription start date if applicable for this subscription payment. Subscriber ID: " . $subscr_id . " Email: " . $email, true);

    do_action('emember_subscription_payment_received', $ipn_data);//Hook for subscription payment received
    
    //We can also query using the email address
    $query_db = $wpdb->get_row("SELECT * FROM $members_table_name WHERE subscr_id = '$subscr_id'", OBJECT);
    if ($query_db) {
        $eMember_id = $query_db->member_id;
        $current_primary_level = $query_db->membership_level;
        eMember_debug_log_subsc("Found a record in the member table. The eMember ID of the account to check is: " . $eMember_id . " Membership Level: " . $current_primary_level, true);

        $ipn_data['member_id'] = $eMember_id;
        do_action('emember_recurring_payment_received', $ipn_data);//Hook for recurring payment received (a sub-sequent payment of an existing subscription).
        
        $level_query = $wpdb->get_row("SELECT * FROM $membership_level_table where id='$current_primary_level'", OBJECT);
        if (!empty($level_query->subscription_period) && !empty($level_query->subscription_unit)) {//Duration value is used
            $account_state = "active";
            $subscription_starts = (date("Y-m-d"));

            $updatedb = "UPDATE $members_table_name SET account_state='$account_state',subscription_starts='$subscription_starts' WHERE member_id='$eMember_id'";
            $results = $wpdb->query($updatedb);
            eMember_debug_log_subsc("Updated the member profile with current date as the subscription start date.", true);
        } else {
            eMember_debug_log_subsc("This membership level is not using a duration/interval value. No need to change the start date. Only update the account status to active.", true);
            $account_state = "active";
            $updatedb = "UPDATE $members_table_name SET account_state='$account_state' WHERE member_id='$eMember_id'";
            $results = $wpdb->query($updatedb);
        }
    } else {
        eMember_debug_log_subsc("Did not find a record in the members table for subscriber ID: " . $subscr_id, true);
    }
}

function eMember_debug_log_subsc($message, $success, $end = false) {
    // Timestamp
    $text = '[' . date('m/d/Y g:i A') . '] - ' . (($success) ? 'SUCCESS :' : 'FAILURE :') . $message . "\n";
    if ($end) {
        $text .= "\n------------------------------------------------------------------\n\n";
    }
    // Write to log file
    $subsc_log_file = WP_EMEMBER_PATH . 'ipn/ipn_handle_debug_eMember.txt';//Use this file for logging
    $fp = fopen($subsc_log_file, 'a');
    fwrite($fp, $text);
    fclose($fp);  // close file
}
