<?php

include_once('eMember_handle_subsc_ipn_stand_alone.php');

class eMember_buttons_braintree_ipn_handler {

    var $last_error;                 // holds the last error encountered
    var $ipn_log;                    // bool: log IPN results to text file?
    var $ipn_log_file;               // filename of the IPN log
    var $ipn_response;               // holds the IPN response from paypal
    var $ipn_data = array();         // array contains the POST values for IPN
    var $fields = array();           // array holds the fields to submit to paypal
    var $sandbox_mode = false;

    function __construct() {
        $this->last_error = '';
        $this->ipn_log_file = WP_EMEMBER_PATH . 'ipn/ipn_handle_debug_eMember.txt';
        $this->ipn_response = '';
    }

    function eMember_validate_and_create_membership() {
        // Read the IPN and validate
        $error_msg = "";

        $payment_status = $this->ipn_data['payment_status'];
        if (!empty($payment_status)) {
            if ($payment_status != "Completed" && $payment_status != "Processed" && $payment_status != "Refunded") {
                $error_msg .= 'Funds have not been cleared yet. Product(s) will be delivered when the funds clear!';
                $this->debug_log($error_msg, false);
                return false;
            }
        }

        $do_not_process_ipn = '';
        $do_not_process_ipn = apply_filters('emember_braintree_ipn_processing_override', $do_not_process_ipn, $this->ipn_data);
        if (!empty($do_not_process_ipn)) {
            $this->debug_log('An addon has overriden this IPN processing. This IPN will not be processed!', true);
            return true;
        }

        $custom = $this->ipn_data['custom'];
        $delimiter = "&";
        $customvariables = array();

        $namevaluecombos = explode($delimiter, $custom);
        foreach ($namevaluecombos as $keyval_unparsed) {
            $equalsignposition = strpos($keyval_unparsed, '=');
            if ($equalsignposition === false) {
                $customvariables[$keyval_unparsed] = '';
                continue;
            }
            $key = substr($keyval_unparsed, 0, $equalsignposition);
            $value = substr($keyval_unparsed, $equalsignposition + 1);
            $customvariables[$key] = $value;
        }
        $transaction_type = $this->ipn_data['txn_type'];
        $transaction_id = $this->ipn_data['txn_id'];
        $gross_total = $this->ipn_data['mc_gross'];
        if ($gross_total < 0) {
            // This is a refund or reversal
            eMember_handle_subsc_cancel_stand_alone($this->ipn_data, true);
            $this->debug_log('This is a refund notification. Refund amount: ' . $gross_total, true);
            return true;
        }

        $cart_items = array();
        $this->debug_log('Transaction Type: Buy Now/Subscribe', true);
        $item_number = $this->ipn_data['item_number'];
        $item_name = urldecode($this->ipn_data['item_name']);
        $quantity = $this->ipn_data['quantity'];
        $mc_gross = $this->ipn_data['mc_gross'];
        $mc_currency = $this->ipn_data['mc_currency'];

        $current_item = array(
            'item_number' => $item_number,
            'item_name' => $item_name,
            'quantity' => $quantity,
            'mc_gross' => $mc_gross,
            'mc_currency' => $mc_currency,
        );
        array_push($cart_items, $current_item);

        $product_id_array = Array();
        $product_name_array = Array();
        $product_price_array = Array();
        $attachments_array = Array();
        $download_link_array = Array();
        $counter = 0;
        foreach ($cart_items as $current_cart_item) {
            $cart_item_data_num = $current_cart_item['item_number'];
            $cart_item_data_name = trim($current_cart_item['item_name']);
            $cart_item_data_quantity = $current_cart_item['quantity'];
            $cart_item_data_total = $current_cart_item['mc_gross'];
            $cart_item_data_currency = $current_cart_item['mc_currency'];
            if (empty($cart_item_data_quantity)) {
                $cart_item_data_quantity = 1;
            }
            $this->debug_log('Item Number: ' . $cart_item_data_num, true);
            $this->debug_log('Item Name: ' . $cart_item_data_name, true);
            $this->debug_log('Item Quantity: ' . $cart_item_data_quantity, true);
            $this->debug_log('Item Total: ' . $cart_item_data_total, true);
            $this->debug_log('Item Currency: ' . $cart_item_data_currency, true);


            //*** Handle Membership Payment ***
            //--------------------------------------------------------------------------------------
            // ========= Need to find the $member_ref (level ID) in the custom variable ============
            $subsc_ref = $customvariables['subsc_ref'];
            $this->debug_log('Membership payment paid for membership level ID: ' . $subsc_ref, true);
            if (!empty($subsc_ref)) {
                $eMember_id = "";
                if (isset($customvariables['eMember_id'])) {
                    $eMember_id = $customvariables['eMember_id'];
                }
                if ($transaction_type == "web_accept") {
                    eMember_handle_subsc_signup_stand_alone($this->ipn_data, $subsc_ref, $this->ipn_data['txn_id'], $eMember_id);
                } else if ($transaction_type == "subscr_payment") {
                    eMember_update_member_subscription_start_date_if_applicable($this->ipn_data);
                }
            } else {
                $this->debug_log('Membership level ID is missing in the payment notification! Cannot process this notification', false);
            }
            //== End of Membership payment handling ==
            $counter++;
        }
        //Do post payment operation and cleanup
        //Save the transaction data
        $this->debug_log('Saving transaction data to the database.', true);
        $this->ipn_data['status'] = $this->ipn_data['payment_status'];
        eMember_Transactions::save_txn_record($this->ipn_data, $cart_items);
        $this->debug_log('Transaction data saved.', true);

        //Check if affiliate referral needs to be tracked
        if (function_exists('wp_aff_platform_install')) {
            $this->debug_log('WP Affiliate Platform is installed, checking if custom field has affiliate data...', true);
            //It expects the value of the custom field to be like the following:
            //<input type="hidden" name="custom" value="subsc_ref=4&ap_id=AFF_ID" />

            $custom_field_val = $this->ipn_data['custom'];
            $this->debug_log('Custom field value: ' . $custom_field_val, true);
            $findme = 'ap_id';
            $pos = strpos($custom_field_val, $findme);
            if ($pos !== false) {
                parse_str($custom_field_val);
                $referrer = $ap_id;
            } else {
                $this->debug_log('Could not find affiliate ID (ap_id) data in the custom field', true);
            }

            if (!empty($referrer)) {
                $total_tax = $this->ipn_data['tax'];
                if (empty($total_tax)) {
                    $total_tax = 0;
                }
                $total_shipping = 0;
                if (!empty($this->ipn_data['shipping'])) {
                    $total_shipping = $this->ipn_data['shipping'];
                } else if (!empty($this->ipn_data['mc_shipping'])) {
                    $total_shipping = $this->ipn_data['mc_shipping'];
                }
                $gross_sale_amt = $this->ipn_data['mc_gross'];
                $this->debug_log('Gross sale amount: ' . $gross_sale_amt . ' Tax: ' . $total_tax . ' Shipping: ' . $total_shipping, true);
                $sale_amount = $gross_sale_amt - $total_shipping - $total_tax;

                $txn_id = $this->ipn_data['txn_id'];
                $item_id = $this->ipn_data['item_number'];
                $buyer_email = $this->ipn_data['payer_email'];
                $buyer_name = $this->ipn_data['first_name'] . " " . $this->ipn_data['last_name'];
                wp_aff_award_commission_unique($referrer, $sale_amount, $txn_id, $item_id, $buyer_email, '', '', $buyer_name);
                $aff_details_debug = "Referrer: " . $referrer . " Sale Amt: " . $sale_amount . " Buyer Email: " . $buyer_email . " Txn ID: " . $txn_id;
                $this->debug_log('Affiliate Commission Details => ' . $aff_details_debug, true);
            } else {
                $this->debug_log("Referrer value is empty! No commission will be awarded for this sale", true);
            }
        }

        //Trigger the IPN processed action hook (so other plugins can can listen for this event).
        do_action('emember_braintree_ipn_processed', $this->ipn_data);

        do_action('emember_ipn_processed', $this->ipn_data);

        return true;
    }

    function eMember_validate_ipn() {

        $this->debug_log("Braintree Buy Now IPN received. Processing request...", true);

        //Read and sanitize the request parameters.
        $button_id = sanitize_text_field($_REQUEST['item_number']);
        $button_id = absint($button_id);
        $button_title = sanitize_text_field($_REQUEST['item_name']);
        $payment_amount = sanitize_text_field($_REQUEST['item_price']);

        //Retrieve the CPT for this button
        $button_cpt = get_post($button_id);
        if (!$button_cpt) {
            //Fatal error. Could not find this payment button post object.
            $this->log("Fatal Error! Failed to retrieve the payment button post object for the given button ID: " . $button_id, false);
            return false;
        }

        $membership_level_id = get_post_meta($button_id, 'membership_level_id', true);

        //Validate and verify some of the main values.
        $true_payment_amount = get_post_meta($button_id, 'payment_amount', true);
        if ($payment_amount != $true_payment_amount) {
            //Fatal error. Payment amount may have been tampered with.
            $error_msg = 'Fatal Error! Received payment amount (' . $payment_amount . ') does not match with the original amount (' . $true_payment_amount . ')';
            $debug_log($error_msg, false);
            return false;
        }

        //Validation passed. Go ahead with the charge.        
        //Set Braintree library environment and keys
        require_once WP_EMEMBER_PATH . 'lib/braintree/lib/Braintree.php';
        try {
            Braintree_Configuration::environment($this->braintree_env);
            Braintree_Configuration::merchantId(get_post_meta($button_id, 'braintree_merchant_acc_id', true));
            Braintree_Configuration::publicKey(get_post_meta($button_id, 'braintree_public_key', true));
            Braintree_Configuration::privateKey(get_post_meta($button_id, 'braintree_private_key', true));

            $braintree_merc_acc_name = get_post_meta($button_id, 'braintree_merchant_acc_name', true);


            // Create the charge on Braintree's servers - this will charge the user's card

            $result = Braintree_Transaction::sale([
                        'amount' => $payment_amount,
                        'paymentMethodNonce' => $_POST['payment_method_nonce'],
                        'channel' => 'TipsandTricks_SP',
                        'options' => [
                            'submitForSettlement' => True
                        ],
                        'merchantAccountId' => $braintree_merc_acc_name,
            ]);
        } catch (Exception $e) {
            $this->debug_log("Braintree library error occured: " . get_class($e) . ", button ID: " . $button_id, false);
            return false;
        }

        if (!$result->success) {
            $this->debug_log("Braintree transaction error occured: " . $result->transaction->status . ", button ID: " . $button_id, false);
            return false;
        } else {

            //Everything went ahead smoothly with the charge.
            $this->debug_log("Braintree Buy Now charge successful.", true);

            //Grab the transaction ID.
            $txn_id = $result->transaction->id; //$charge->balance_transaction;

            $custom = urldecode($_REQUEST['custom']);

            //Create the $ipn_data array.
            $ipn_data = array();
            $ipn_data['txn_type'] = 'web_accept';
            $ipn_data['mc_gross'] = $payment_amount;
            $ipn_data['mc_currency'] = $result->transaction->currencyIsoCode;
            $ipn_data['first_name'] = sanitize_text_field($_REQUEST['first_name']);
            $ipn_data['last_name'] = sanitize_text_field($_REQUEST['last_name']);
            $ipn_data['payer_email'] = sanitize_text_field($_REQUEST['member_email']);
            $ipn_data['membership_level'] = $membership_level_id;
            $ipn_data['txn_id'] = $txn_id;
            $ipn_data['item_number'] = $button_id;
            $ipn_data['item_name'] = $button_title;
            $ipn_data['quantity'] = '1';            
            $ipn_data['subscr_id'] = $txn_id;
            $ipn_data['custom'] = $custom;
            $ipn_data['gateway'] = 'braintree';
            $ipn_data['payment_status'] = 'Completed';

            $ipn_data['address_street'] = '';
            $ipn_data['address_city'] = '';
            $ipn_data['address_state'] = '';
            $ipn_data['address_zipcode'] = '';
            $ipn_data['country'] = '';

            $this->ipn_data = $ipn_data;

            return true;
        }
    }

    function log_ipn_results($success) {
        if (!$this->ipn_log)
            return;  // is logging turned off?
        // Timestamp
        $text = '[' . date('m/d/Y g:i A') . '] - ';

        // Success or failure being logged?
        if ($success)
            $text .= "SUCCESS!\n";
        else
            $text .= 'FAIL: ' . $this->last_error . "\n";

        // Log the POST variables
        $text .= "IPN POST Vars from Paypal:\n";
        foreach ($this->ipn_data as $key => $value) {
            $text .= "$key=$value, ";
        }

        // Log the response from the paypal server
        $text .= "\nIPN Response from Paypal Server:\n " . $this->ipn_response;

        // Write to log
        $fp = fopen($this->ipn_log_file, 'a');
        fwrite($fp, $text . "\n\n");

        fclose($fp);  // close file
    }

    function debug_log($message, $success, $end = false) {

        if (!$this->ipn_log)
            return;  // is logging turned off?
        // Timestamp
        $text = '[' . date('m/d/Y g:i A') . '] - ' . (($success) ? 'SUCCESS :' : 'FAILURE :') . $message . "\n";

        if ($end) {
            $text .= "\n------------------------------------------------------------------\n\n";
        }

        // Write to log
        $fp = fopen($this->ipn_log_file, 'a');
        fwrite($fp, $text);
        fclose($fp);  // close file
    }

}

// Start of IPN handling (script execution)
$emember_config = Emember_Config::getInstance();
$ipn_handler_instance = new eMember_buttons_braintree_ipn_handler();

if ($emember_config->getValue('eMember_enable_debug') == 1) {
    $debug_log = "ipn_handle_debug_eMember.txt"; // Debug log file name
    $ipn_handler_instance->ipn_log = true;
}

if ($emember_config->getValue('eMember_enable_sandbox') == 1) { // Enable sandbox testing
    $ipn_handler_instance->braintree_env = "sandbox";
    $ipn_handler_instance->sandbox_mode = true;
} else {
    $ipn_handler_instance->braintree_env = "production";
    $ipn_handler_instance->sandbox_mode = false;
}

$ipn_handler_instance->debug_log('WP eMember Button IPN Hanlder. Braintree Class Initiated by ' . $_SERVER['REMOTE_ADDR'], true);

// Validate the IPN
if ($ipn_handler_instance->eMember_validate_ipn()) {
    $ipn_handler_instance->debug_log('Creating product Information to send.', true);

    if (!$ipn_handler_instance->eMember_validate_and_create_membership()) {
        $ipn_handler_instance->debug_log('IPN product validation failed.', false);
    }
}
$ipn_handler_instance->debug_log('Braintree class finished.', true, true);

if (isset($_REQUEST['return_url'])) {
    $url = urldecode($_REQUEST['return_url']);
    wp_emember_redirect_to_url($url);
}
