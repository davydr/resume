<?php

if (!defined('ABSPATH')) {
    include_once('../../../../wp-load.php');
}
include_once('eMember_handle_subsc_ipn_stand_alone.php');

$debug_enabled = false;
$emember_config = Emember_Config::getInstance();
if ($emember_config->getValue('eMember_enable_debug') == 1) {
    $debug_enabled = true;
}

if ($debug_enabled) {
    echo 'Debug is enabled.';
    if (empty($_POST["cverify"])) {//JVZoo IPN always has the "cverify" value in the request as it is used to validate the IPN.
        eMember_log_debug('Not a genuine JVZoo IPN. This debug line was generated because you entered the URL of the ipn handling script in the browser.', true, true);
        exit;
    }
}
eMember_log_debug("JVZoo IPN received! Processing IPN ...", true);
eMember_log_debug_array($_REQUEST, true);

//Lets verify the JVZoo IPN using secret key
if (!emember_jvzipn_verification()) {
    eMember_log_debug("JVZoo IPN verfification faield. Can't process this IPN. Make sure you have entered the correct secret key in the settings.", false);
    exit;
}

eMember_log_debug("JVZoo IPN verfified.", true);

$name = sanitize_text_field(trim($_REQUEST['ccustname']));
$last_name = (strpos($name, ' ') === false) ? '' : preg_replace('#.*\s([\w-]*)$#', '$1', $name);
$first_name = trim( preg_replace('#'.$last_name.'#', '', $name ) );
    
$jvzoo_ipn_data = array();
$jvzoo_ipn_data['txn_type'] = sanitize_text_field($_REQUEST['ctransaction']);
$jvzoo_ipn_data['payer_email'] = sanitize_email($_REQUEST['ccustemail']);
$jvzoo_ipn_data['first_name'] = $first_name;
$jvzoo_ipn_data['last_name'] = $last_name;
$jvzoo_ipn_data['address_street'] = "";
$jvzoo_ipn_data['address_city'] = "";
$jvzoo_ipn_data['address_state'] = "";
$jvzoo_ipn_data['address_zip'] = "";
$jvzoo_ipn_data['address_country'] = "";
$jvzoo_ipn_data['txn_id'] = sanitize_text_field($_REQUEST['ctransreceipt']);
$jvzoo_ipn_data['custom'] = sanitize_text_field($_REQUEST['cvendthru']);
eMember_log_debug_array($jvzoo_ipn_data, true);

$jvzoo_ipn_data['membership_level_id'] = sanitize_text_field($_REQUEST['membership_level_id']);
eMember_log_debug("Payment received for membership level ID:" . $jvzoo_ipn_data['membership_level_id'], true);

//Check the transaction Types
if($jvzoo_ipn_data['txn_type'] == 'CGBK' || $jvzoo_ipn_data['txn_type'] == 'INSF'){
    eMember_log_debug("This is a chargeback type transaction. Nothing to do for now.", true);
    return;
    
}
if($jvzoo_ipn_data['txn_type'] == 'CANCEL-REBILL'){
    //The cancellation of a recurring billing product
    eMember_log_debug("This is a CANCEL-REBILL type transaction.", true);
    $jvzoo_ipn_data['parent_txn_id'] = sanitize_text_field($_REQUEST['ctransreceipt']);
    eMember_handle_subsc_cancel_stand_alone($jvzoo_ipn_data);
    return;
}
if($jvzoo_ipn_data['txn_type'] == 'RFND'){
    //The refund of a product
    eMember_log_debug("This is a refund type transaction.", true);
    $jvzoo_ipn_data['parent_txn_id'] = sanitize_text_field($_REQUEST['ctransreceipt']);
    eMember_handle_subsc_cancel_stand_alone($jvzoo_ipn_data, true);    
    return;
}

/* Handle the normal sale or bill type transactions */

//Verify that the notification contains a valid membership level ID
if (empty($jvzoo_ipn_data['membership_level_id']) || !emember_membership_level_id_exists($jvzoo_ipn_data['membership_level_id'])) {
    //This membersip level ID is invalid.
    eMember_log_debug("Error! The membership level ID doesn't exist on this site. Can't process this payment.", false);
    exit;
}

//handle the membership payment data
eMember_handle_subsc_signup_stand_alone($jvzoo_ipn_data, $jvzoo_ipn_data['membership_level_id'], $jvzoo_ipn_data['txn_id']);

eMember_log_debug("End of JVZoo membership payment processing!", true, true);


/* This function is used to verify the JVZoo IPN */
function emember_jvzipn_verification() {
    $emember_config = Emember_Config::getInstance();
    $jvzoo_secretKey = $emember_config->getValue('jvzoo_secret_key');
    if(empty($jvzoo_secretKey)){
        eMember_log_debug("JVZoo secrete key hasn't been configured. Can't process this IPN. Make sure you have entered the correct secret key saved in the settings.", false);
    }
    
    $secretKey = $jvzoo_secretKey;
    $pop = "";
    $ipnFields = array();
    foreach ($_POST AS $key => $value) {
        if ($key == "cverify") {
            continue;
        }
        $ipnFields[] = $key;
    }
    sort($ipnFields);
    foreach ($ipnFields as $field) {
        // if Magic Quotes are enabled $_POST[$field] will need to be
        // un-escaped before being appended to $pop
        $pop = $pop . $_POST[$field] . "|";
    }
    $pop = $pop . $secretKey;
    if ('UTF-8' != mb_detect_encoding($pop)) {
        $pop = mb_convert_encoding($pop, "UTF-8");
    }
    $calcedVerify = sha1($pop);
    $calcedVerify = strtoupper(substr($calcedVerify, 0, 8));
    return $calcedVerify == $_POST["cverify"];
}
