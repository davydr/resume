<?php

function filter_eMember_registration_form($content) {
    $pattern = '#\[wp_eMember_registration_form:end]#';
    preg_match_all($pattern, $content, $matches);

    foreach ($matches[0] as $match) {
        $replacement = print_eMember_registration_form();
        $content = str_replace($match, $replacement, $content);
    }
    return $content;
}

function print_eMember_registration_form() {
    return show_registration_form();
}

function emember_process_free_rego_with_confirm_form() {
    global $wpdb;
    $emember_config = Emember_Config::getInstance();
    $error_message = "";
    if (isset($_POST['eMember_Register_with_confirmation'])) {
        // Do some validation
        $_POST['wp_emember_aemail'] = sanitize_email($_POST['wp_emember_aemail']);
        if (empty($_POST['wp_emember_aemail']) || !is_email($_POST['wp_emember_aemail'])) {
            $error_message = "<p class='emember_error'><strong>" . EMEMBER_INVALID_EMAIL . "</strong></p>";
        }
        if (($_POST['wp_emember_aemail'] != $_POST['wp_emember_aemail_re'])) {
            $error_message = "<p class='emember_error'><strong>" . EMEMBER_EMAIL_MISMATCH . "</strong></p>";
        }
        if ($emember_config->getValue('eMember_reg_firstname') && $emember_config->getValue('eMember_reg_firstname_required')) {
            if (empty($_POST['wp_emember_afirstname'])) {
                $error_message = "<p class='emember_error'><strong>" . EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS . "</strong></p>";
            } else {
                $_POST['wp_emember_afirstname'] = sanitize_text_field($_POST['wp_emember_afirstname']);
            }
        } else if ($emember_config->getValue('eMember_reg_firstname')) {
            $_POST['wp_emember_afirstname'] = sanitize_text_field($_POST['wp_emember_afirstname']);
        } else {
            $_POST['wp_emember_afirstname'] = "";
        }

        if ($emember_config->getValue('eMember_reg_lastname') && $emember_config->getValue('eMember_reg_lastname_required')) {
            if (empty($_POST['wp_emember_alastname'])) {
                $error_message = "<p class='emember_error'><strong>" . EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS . "</strong></p>";
            } else {
                $_POST['wp_emember_alastname'] = sanitize_text_field($_POST['wp_emember_alastname']);
            }
        } else if ($emember_config->getValue('eMember_reg_lastname')) {
            $_POST['wp_emember_alastname'] = sanitize_text_field($_POST['wp_emember_alastname']);
        } else {
            $_POST['wp_emember_alastname'] = "";
        }

        // Check if the entered email address is blocked
        $user_email = sanitize_email($_POST['wp_emember_aemail']);
        if (is_blocked_email($user_email)) {
            $error_message .= '<div class="emember_error"> ' . $user_email . ' </div>';
            $error_message .= '<div class="emember_error"> ' . EMEMBER_EMAIL_BLACKLISTED . ' </div>';
            $emember_config->set_stacked_message('emember_free_registration_confirm', array('type' => 'warning', 'message' => $error_message));
            return;
        }

        // If all the initial validation passed then proceed with signup request.
        if (empty($error_message)) {
            eMember_log_debug("Processing signup request of free membership with email confirmation for: " . $_POST['wp_emember_aemail'], true);
            $result = emember_recaptcha_verify();
            if ($result->valid) {
                $valid_captcha = apply_filters('emember_captcha_varify', true);
                eMember_log_debug("reCAPTCH is valid... creating member account for: " . $_POST['wp_emember_aemail'], true);
                // create new member account and send the registration completion email
                if (emember_email_exists($_POST['wp_emember_aemail'])) {
                    $error_message = "<p class='emember_error'><strong>" . EMEMBER_EMAIL_TAKEN . "</strong></p>";
                    $emember_config->set_stacked_message('emember_free_registration_confirm', array('type' => 'error', 'message' => $error_message));
                } else if (!$valid_captcha) {
                    $error_message = "<p class='emember_error'><strong>" . EMEMBER_CAPTCHA_FAILED . "</strong></p>";
                    $emember_config->set_stacked_message('emember_free_registration_confirm', array('type' => 'error', 'message' => $error_message));
                } else {
                    $fields = array();
                    $fields['user_name'] = '';
                    $fields['password'] = '';
                    $fields['first_name'] = sanitize_text_field($_POST['wp_emember_afirstname']);
                    $fields['last_name'] = sanitize_text_field($_POST['wp_emember_alastname']);
                    $fields['email'] = sanitize_email($_POST['wp_emember_aemail']);
                    $fields['last_accessed_from_ip'] = get_real_ip_addr();
                    $fields['member_since'] = (date("Y-m-d"));
                    // $fields['subscription_starts'] = date("Y-m-d");
                    if (isset($_POST['wp_emember_membership_level']) && !empty($_POST['wp_emember_membership_level'])) {
                        $fields['membership_level'] = sanitize_text_field($_POST['wp_emember_membership_level']);
                    } else {
                        $fields['membership_level'] = $emember_config->getValue('eMember_free_membership_level_id');
                    }
                    // $fields['initial_membership_level'] = $emember_config->getValue('eMember_free_membership_level_id');
                    $eMember_manually_approve_member_registration = $emember_config->getValue('eMember_manually_approve_member_registration');
                    if ($eMember_manually_approve_member_registration) {
                        $fields['account_state'] = 'pending';
                    } else {
                        $fields['account_state'] = 'active';
                    }

                    $reg_code = uniqid(); // rand(10, 1000);
                    $md5_code = md5($reg_code);
                    $fields['reg_code'] = sanitize_text_field($reg_code);
                    $data_formats = array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s');
                    $wpdb->insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields, $data_formats);

                    $resultset = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' reg_code=\'' . sanitize_text_field($reg_code) . '\'');
                    $id = $resultset->member_id;

                    $separator = '?';
                    $url = $emember_config->getValue('eMember_registration_page');
                    if (strpos($url, '?') !== false) {
                        $separator = '&';
                    }
                    $reg_url = $url . $separator . 'member_id=' . sanitize_text_field($id) . '&code=' . sanitize_text_field($md5_code);

                    $subject = $emember_config->getValue('eMember_email_subject');
                    $body = $emember_config->getValue('eMember_email_body');
                    $from_address = $emember_config->getValue('senders_email_address');

                    $tags = array("{first_name}", "{last_name}", "{reg_link}");
                    $vals = array(sanitize_text_field($_POST['wp_emember_afirstname']), sanitize_text_field($_POST['wp_emember_alastname']), sanitize_text_field($reg_url));
                    $email_body = str_replace($tags, $vals, $body);
                    $headers = 'From: ' . sanitize_email($from_address) . "\r\n";
                    $to_email = sanitize_email($_POST['wp_emember_aemail']);

                    eMember_log_debug("Sending registration completion email for free registration with confirmation to: " . $to_email, true);
                    wp_mail($to_email, $subject, $email_body, $headers);

                    $chk_mail_msg = '<div class="emember_check_email_msg">' . EMEMBER_PLEASE_CHECK_YOUR_INBOX . '<br />' . EMEMBER_EMAIL . ': ' . $to_email . '</div>';
                    $output = apply_filters('emember_registration_check_email_msg', $chk_mail_msg);

                    eMember_log_debug("Free registration with confirmation complete.", true);
                    $_SESSION['emember_dsc_nonce'] = sanitize_text_field($_REQUEST['emember_dsc_nonce']);
                    $_SESSION['emember_frwc_msg'] = sanitize_text_field($output);
                    $emember_config->set_stacked_message('emember_free_registration_confirm', array('type' => 'success', 'message' => $output));

                    if (isset($_POST['free_rego_with_confirm_redirect'])) { // Do the after submission redirection
                        $redirect_url = sanitize_text_field($_POST['free_rego_with_confirm_redirect']);
                        wp_emember_redirect_to_url($redirect_url);
                    }
                }
            } else {
                $emember_config->set_stacked_message('emember_free_registration_confirm', array('type' => 'error', 'message' => $result->message));
            }
        } else {
            $emember_config->set_stacked_message('emember_free_registration_confirm', array('type' => 'error', 'message' => $error_message));
        }
        $_SESSION['emember_frwc_msg'] = sanitize_text_field($error_message);
    }
}

function free_rego_with_email_confirmation_handler($args = NULL) {
    extract(shortcode_atts(array(
        'level' => '',
        'redirect_to' => '',
                    ), $args));

    $emember_config = Emember_Config::getInstance();
    $error_message = "";
    if ($emember_config->getValue('eMember_enable_free_membership') == '') {//Free membership is disabled
        $output = EMEMBER_FREE_MEMBER_DISABLED;
        $output .= "<br />Enable free membership in the settings if you want to use this functionality.";
        return $output;
    }
    $stacked_msg = $emember_config->get_stacked_message('emember_free_registration_confirm');
    $recaptcha_error = $emember_config->get_stacked_message('emember_free_registration_confirm_captcha');
    $output = '';
    if (!empty($stacked_msg)) {
        if (($stacked_msg['type'] == 'warning') || ($stacked_msg['type'] == 'success')) {
            return $stacked_msg['message'];
        }
    }
    if (!empty($stacked_msg) && ($stacked_msg['type'] == 'error')) {
        $error_message .= $stacked_msg['message'];
    }

    ob_start();
    echo $error_message;
    ?>
    <script type="text/javascript" src="<?php echo site_url(); ?>?emember_load_js=registration&id=wp_emember_regoFormWithConfirmation"></script>
    <link rel='stylesheet' href='<?php echo WP_EMEMBER_URL; ?>/css/pure-min.css?ver=<?php echo WP_EMEMBER_VERSION; ?>' type='text/css' media='all' />
    <form action="" method="post" name="wp_emember_regoFormWithConfirmation" id="wp_emember_regoFormWithConfirmation" class="pure-form pure-form-stacked" >
        <input type="hidden" name="emember_dsc_nonce" value="<?php echo uniqid(); ?>">
        <?php
        if (!empty($level)) {
            echo '<input type="hidden" name="wp_emember_membership_level" value="' . $level . '">';
        }
        if (!empty($redirect_to)) {
            echo '<input type="hidden" name="free_rego_with_confirm_redirect" value="' . $redirect_to . '">';
        }
        ?>
	    <div class="emember_free_rego_with_confirm_form_msg">
		<?php echo EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE;?>
	    </div>
	<fieldset>
	    <?php if ($emember_config->getValue('eMember_reg_firstname')): ?>
	    <input type="text" id="wp_emember_afirstname" name="wp_emember_afirstname" size="20" value="<?php echo isset($_POST['wp_emember_afirstname']) ? $_POST['wp_emember_afirstname'] : ""; ?>" class="<?php echo $emember_config->getValue('eMember_reg_firstname_required') ? 'validate[required] ' : ""; ?>pure-input-1" placeholder="<?php echo EMEMBER_FIRST_NAME;?>" />
            <?php endif; ?>
            <?php if ($emember_config->getValue('eMember_reg_lastname')): ?>
            <input type="text" id="wp_emember_alastname" name="wp_emember_alastname" size="20" value="<?php echo isset($_POST['wp_emember_alastname']) ? $_POST['wp_emember_alastname'] : ""; ?>" class="<?php echo $emember_config->getValue('eMember_reg_lastname_required') ? 'validate[required] ' : ""; ?>pure-input-1"  placeholder="<?php echo EMEMBER_LAST_NAME;?>" />
            <?php endif; ?>
	    <input type="text" id="wp_emember_aemail" name="wp_emember_aemail" size="20" value="<?php echo isset($_POST['wp_emember_aemail']) ? $_POST['wp_emember_aemail'] : ""; ?>" class="validate[required] pure-input-1" placeholder="<?php echo EMEMBER_EMAIL; ?>" />
	    <input type="text" id="wp_emember_aemail_re" name="wp_emember_aemail_re" size="20" value="<?php echo isset($_POST['wp_emember_aemail_re']) ? $_POST['wp_emember_aemail_re'] : ""; ?>" class="validate[required] pure-input-1" placeholder="<?php echo EMEMBER_RETYPE_EMAIL; ?>" />
	</fieldset>
	<fieldset class="emember-centered">
            <div class="wp_emember_recaptcha">
		<div class="emember-recaptcha-section">
		    <?php
                    $captcha = emember_recaptcha_html();
                    echo apply_filters('emember_captcha', $captcha);
                    ?>
		</div>
            </div>
	</fieldset>
	<fieldset class="pure-controls emember-centered">
            <div class="eMember_Register">
                <button id="eMember_Register_with_confirmation" type="submit" class="pure-button pure-button-active emember-rego-confirm-submit-button"><?php echo EMEMBER_SEND_VERIFICATION; ?></button>
                <input class="pure-button pure-button-active emember-rego-confirm-submit-input" name="eMember_Register_with_confirmation" type="hidden" value="<?php echo EMEMBER_SEND_VERIFICATION; ?>">
            </div>
        </fieldset>
    </form>
    <?php
    $output = ob_get_contents();
    ob_end_clean();
    return $output;
}

function emember_process_reg_form() {
    $emember_config = Emember_Config::getInstance();

    // Check for IP address block (if that feature is being used)
    if (is_blocked_ip(get_real_ip_addr())) {
        $message = '<span class="emember_error">' . EMEMBER_IP_BLACKLISTED . ' </span>';
        $emember_config->set_stacked_message('emember_full_registration', array('type' => 'warning', 'message' => $message));
        return;
    }

    $output = '';
    $eMember_id = sanitize_text_field(filter_input(INPUT_GET, 'member_id'));
    $code = sanitize_text_field(filter_input(INPUT_GET, "code"));
    $recaptcha_error = null;
    $resp = null;
    global $wpdb;
    $is_reg_successfull = false;
    if (isset($_POST['eMember_Register'])) {
        do_action('emember_registration_form_submitted');

        // Keeping the nonce verification on registration form OFF for now. This is to help with caching plugin compatibility
        // $nonce = $_REQUEST['_wpnonce'];
        // if (!wp_verify_nonce($nonce, 'emember-plain-registration-nonce')) {
        //    eMember_log_debug("Registration nonce check failed ", true);
        //    die("Security check failed on registration");
        //}

        // This filter can be used by addons to perform additional validation checks after the registration form is submitted.
        $validation_error = array();
        $validation_error = apply_filters('emember_do_pre_registration_validation', $validation_error);
        if (!empty($validation_error)) {
            // There are some custom validation errors caught by an addon or custom code. Set the error message and bail out.
            $output .= '<span class="emember_error">' . implode('<br/>', $validation_error) . '</span>';
            $emember_config->set_stacked_message('emember_full_registration', array('type' => 'error', 'message' => $output));
            return;
        }

        $_POST['wp_emember_email'] = sanitize_email($_POST['wp_emember_email']);
        $user_email = $_POST['wp_emember_email'];
        $_POST['wp_emember_user_name'] = sanitize_text_field($_POST['wp_emember_user_name']);
        $_POST['wp_emember_pwd'] = ($_POST['wp_emember_pwd']);

        eMember_log_debug("Processing signup request of membership for: " . $user_email, true);

        if ($emember_config->getValue('eMember_show_terms_conditions')) {
            if (!isset($_POST['emember_terms_conditions'])) {
                $output .= '<span class="emember_error">' . EMEMBER_TERMS_WARNING . '</span>';
                $emember_config->set_stacked_message('emember_full_registration', array('type' => 'warning', 'message' => $output));
                return;
            }
        }

        if (is_blocked_email($user_email)) {
            $output .= '<div class="emember_error"> ' . sanitize_email($user_email) . ' </div>';
            $output .= '<div class="emember_error"> ' . EMEMBER_EMAIL_BLACKLISTED . ' </div>';
            $emember_config->set_stacked_message('emember_full_registration', array('type' => 'warning', 'message' => $output));
            return;
        }

        $captcha_result = emember_recaptcha_verify();
        if ($captcha_result->valid) {
            eMember_log_debug("reCAPTCHA is valid... creating membership account: " . $_POST['wp_emember_email'], true);
            include_once(ABSPATH . WPINC . '/class-phpass.php');
            $wp_hasher = new PasswordHash(8, TRUE);
            $password = $wp_hasher->HashPassword($_POST['wp_emember_pwd']);

            // Do various basic form field validation.
            include_once('emember_validator.php');
            $validator = new Emember_Validator();
            $validator->add(array('value' => $_POST['wp_emember_user_name'], 'label' => EMEMBER_USERNAME, 'rules' => array('user_required', 'user_minlength', 'user_name', 'user_unavail')));
            $validator->add(array('value' => $_POST['wp_emember_email'], 'label' => EMEMBER_EMAIL, 'rules' => array('email_required', 'email')));
            $validator->add(array('value' => $_POST['wp_emember_pwd'], 'label' => EMEMBER_PASSWORD, 'rules' => array('pass_required')));
            $messages = $validator->validate();

            // Do the email unavailable check (email_unavail)
            $email = $_POST['wp_emember_email'];
            if (emember_registered_email_exists($email)) {
                // Check emember's record. If this email exists in emember table then this email can't be used.
                $messages[] = EMEMBER_EMAIL_TAKEN;
            } else if (emember_wp_email_exists($email)) {
                // Check WP User's record. If this email exists in WP but not emember then give a more appropriate error message so the admin knows where to look.
                $wp_user = get_user_by('email', $email);
                $error_msg = 'The email already belongs to an existing WordPress user record.';
                $error_msg .= '<br />Username of the WP user account is: ' . $wp_user->user_login;
                $error_msg .= '<p>Site admin can import this WP User by going to WP eMember -> Members -> Import WP User </p>';
                $messages[] = $error_msg;
            }

            // Check the confirm password matches (if enabled)
            $show_confirm_pass = $emember_config->getValue('eMember_show_confirm_pass_field');
            if ($show_confirm_pass) {
                if ($_POST['wp_emember_pwd'] != $_POST['wp_emember_pwd_re']) {
                    $messages[] = EMEMBER_PASSWORD . ':' . EMEMBER_PASSWORD_MISMATCH;
                }
            }

            $valid_captcha = apply_filters('emember_captcha_varify', true);
            if (!$valid_captcha) {
                // Captcha failed
                $output .= "<p class='emember_error'><strong>" . EMEMBER_CAPTCHA_FAILED . "</strong></p>";
                $emember_config->set_stacked_message('emember_full_registration', array('type' => 'error', 'message' => $output));
            } else if (count($messages) > 0) {
                // Field validation failed
                $output .= '<span class="emember_error">' . implode('<br/>', $messages) . '</span>';
                $emember_config->set_stacked_message('emember_full_registration', array('type' => 'error', 'message' => $output));
            } else {
                // Success - Create new member account and send the registration completion email
                $fields = array();
                $custom_fields = array();

                /* === Common registration fields value === */
                if (isset($_COOKIE['ap_id'])) {
                    $fields['referrer'] = sanitize_text_field($_COOKIE['ap_id']);
                } else {
                    $fields['referrer'] = '';
                }
                if (isset($_POST['emember_custom']) && is_array($_POST['emember_custom'])) {
                    $referrer_field_key = "Referrer";
                    if (array_key_exists($referrer_field_key, $_POST['emember_custom'])) {
                        $fields['referrer'] = sanitize_text_field(strip_tags(trim($_POST['emember_custom'][$referrer_field_key])));
                    }
                }

                if (isset($_POST['eMember_id']) && isset($_POST['eMember_reg_code'])) {
                    // Update the membership data with the registration complete details (this path is exercised when the unique link is clicked from the email to do the registration complete action)
                    eMember_log_debug("Completing the registration for premium membership account. Member Email: " . $_POST['wp_emember_email'] . " eMember ID: " . sanitize_text_field($eMember_id), true);
                    $mresultset = $wpdb->get_row("SELECT reg_code,membership_level FROM " . WP_EMEMBER_MEMBERS_TABLE_NAME . " where member_id='" . sanitize_text_field($eMember_id) . "'", ARRAY_A);

                    $fields['user_name'] = sanitize_text_field($_POST['wp_emember_user_name']);
                    $fields['password'] = $password;
                    $fields['membership_level'] = sanitize_text_field($mresultset['membership_level']);
                    $fields['reg_code'] = '';
                    $fields['title'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_title'));
                    $fields['first_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_firstname'));
                    $fields['last_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_lastname'));
                    $fields['phone'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_phone'));
                    $fields['address_street'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_street'));
                    $fields['address_city'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_city'));
                    $fields['address_state'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_state'));
                    $fields['address_zipcode'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_zipcode'));
                    $fields['country'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_country'));
                    $fields['gender'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_gender'));
                    $fields['company_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_company_name'));

                    $fields['member_since'] = (date("Y-m-d"));
                    $fields['subscription_starts'] = date("Y-m-d");
                    $fields['autoupgrade_starts'] = date("Y-m-d");

                    // No need to update the membership level as it has already been set for this member when the unique rego complete link was sent out

                    $eMember_manually_approve_member_registration = $emember_config->getValue('eMember_manually_approve_member_registration');
                    if ($eMember_manually_approve_member_registration) {
                        $fields['account_state'] = 'pending';
                    } else {
                        $fields['account_state'] = 'active';
                    }
                    $fields['email'] = sanitize_email(filter_input(INPUT_POST, 'wp_emember_email'));
                    $fields['last_accessed_from_ip'] = get_real_ip_addr();

                    $reg_code = sanitize_text_field(filter_input(INPUT_POST, 'eMember_reg_code'));
                    if (md5($mresultset['reg_code']) == $reg_code) {
                        $ret = $wpdb->update(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields, array('member_id' => sanitize_text_field($eMember_id)));
                        eMember_log_debug("Updating premium member account data. eMember ID: " . sanitize_text_field($eMember_id), true);
                        $lastid = sanitize_text_field($eMember_id);
                        $fields['member_id'] = sanitize_text_field($eMember_id);

                        if (isset($_POST['emember_custom'])) {
                            foreach ($_POST['emember_custom'] as $key => $value) {
                                $custom_fields[$key] = sanitize_text_field($value);
                            }
                            $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . '( user_id, meta_key, meta_value ) VALUES(' . $lastid . ',\'custom_field\',' . '\'' . addslashes(serialize($_POST['emember_custom'])) . '\')');
                        }

                        if ($ret === false) {
                            $output .= '<br />' . ' DB Error.';
                            $emember_config->set_stacked_message('emember_full_registration', array('type' => 'error', 'message' => $output));
                            $is_reg_successfull = false;
                        } else {
                            $is_reg_successfull = true;
                            if (isset($_SESSION['eMember_id'])) {
                                unset($_SESSION['eMember_id']);
                            }
                            if (isset($_SESSION['reg_code'])) {
                                unset($_SESSION['reg_code']);
                            }
                        }
                    } else {
                        $output .= '<span class="emember_error">Error! Unique registration code do not match!</span>';
                        $emember_config->set_stacked_message('emember_full_registration', array('type' => 'warning', 'message' => $output));
                    }
                } else {
                    // Create a new account for a free member or the level specified in the shortcode. This path is exercised when someone directly goes to the registration page and submits the details.
                    eMember_log_debug("Creating a new account for free membership or for the level specified in the shortcode. Member Email: " . sanitize_email($_POST['wp_emember_email']), true);
                    $fields['user_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_user_name'));
                    $fields['password'] = $password;

                    $fields['title'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_title'));
                    $fields['first_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_firstname'));
                    $fields['last_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_lastname'));
                    $fields['phone'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_phone'));
                    $fields['address_street'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_street'));
                    $fields['address_city'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_city'));
                    $fields['address_state'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_state'));
                    $fields['address_zipcode'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_zipcode'));
                    $fields['country'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_country'));
                    $fields['gender'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_gender'));
                    $fields['company_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_company_name'));

                    $fields['member_since'] = (date("Y-m-d"));
                    $fields['subscription_starts'] = date("Y-m-d");
                    $fields['autoupgrade_starts'] = date("Y-m-d");

                    if (isset($_POST['custom_member_level_shortcode'])) {
                        $fields['membership_level'] = sanitize_text_field($_POST['custom_member_level_shortcode']);
                        // $fields['initial_membership_level']    = $_POST['custom_member_level_shortcode'];
                    } else {
                        $fields['membership_level'] = $emember_config->getValue('eMember_free_membership_level_id');
                        // $fields['initial_membership_level']    = $emember_config->getValue('eMember_free_membership_level_id');
                    }
                    $eMember_manually_approve_member_registration = $emember_config->getValue('eMember_manually_approve_member_registration');
                    if ($eMember_manually_approve_member_registration) {
                        $fields['account_state'] = 'pending';
                    } else {
                        $fields['account_state'] = 'active';
                    }
                    $fields['email'] = sanitize_email(filter_input(INPUT_POST, 'wp_emember_email'));
                    $fields['last_accessed_from_ip'] = get_real_ip_addr();

                    $fields = array_filter($fields); // Remove any null values.
                    $ret = $wpdb->insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
                    $lastid = sanitize_text_field($wpdb->insert_id);
                    $fields['member_id'] = sanitize_text_field($lastid);
                    if (isset($_POST['emember_custom'])) {
                        foreach ($_POST['emember_custom'] as $key => $value) {
                            $custom_fields[$key] = sanitize_text_field($value);
                        }
                        $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . '( user_id, meta_key, meta_value ) VALUES(' . $lastid . ',\'custom_field\',' . '\'' . addslashes(serialize($_POST['emember_custom'])) . '\')');
                    }
                    if ($ret === false) {
                        $output .= '<br />' . ' DB Error.';
                        $emember_config->set_stacked_message('emember_full_registration', array('type' => 'error', 'message' => $output));
                        $is_reg_successfull = false;
                    } else {
                        $is_reg_successfull = true;
                    }
                }
                if ($is_reg_successfull) {
                    eMember_log_debug("Processing registration submission...", true);

                    // Send notification to any other plugin listening for the eMember registration complete event.
                    do_action('eMember_registration_complete', $fields, $custom_fields);

                    // Query the membership level table to get a handle for the level
                    $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" . sanitize_text_field($fields['membership_level']) . "'");

                    // Create the corresponding wordpress user
                    $wp_user_id = '';
                    $should_create_wp_user = $emember_config->getValue('eMember_create_wp_user');
                    if ($should_create_wp_user) {
                        $role_names = array(1 => 'Administrator', 2 => 'Editor', 3 => 'Author', 4 => 'Contributor', 5 => 'Subscriber');
                        $wp_user_info = array();
                        $wp_user_info['user_nicename'] = implode('-', explode(' ', sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_user_name'))));
                        $wp_user_info['display_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_user_name'));
                        $wp_user_info['nickname'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_user_name'));
                        $wp_user_info['first_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_firstname'));
                        $wp_user_info['last_name'] = sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_lastname'));
                        $wp_user_info['role'] = sanitize_text_field($membership_level_resultset->role);
                        $wp_user_info['user_registered'] = date('Y-m-d H:i:s');

                        // $wp_user_id = wp_create_user($_POST['wp_emember_user_name'], $_POST['wp_emember_pwd'], $_POST['wp_emember_email']);
                        $wp_user_id = eMember_wp_create_user(sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_user_name')), sanitize_text_field(filter_input(INPUT_POST, 'wp_emember_pwd')), sanitize_email(filter_input(INPUT_POST, 'wp_emember_email')), $wp_user_info);
                        // do_action( 'set_user_role', $wp_user_id, $membership_level_resultset->role );
                    }

                    // Trigger the eMember registration complete after wp user creation action hook.
                    $fields['wp_user_id'] = sanitize_text_field($wp_user_id);
                    do_action('eMember_registration_complete_after_wp_user_creation', $fields, $custom_fields);

                    //-----------------
                    $subject_rego_complete = $emember_config->getValue('eMember_email_subject_rego_complete');
                    $body_rego_complete = $emember_config->getValue('eMember_email_body_rego_complete');
                    $from_address = sanitize_email($emember_config->getValue('senders_email_address'));
                    $login_link = $emember_config->getValue('login_page_url');
                    // Do the full dynamic member details replacement
                    $curr_member_id = sanitize_text_field($lastid);
                    $additional_params = array('password' => $_POST['wp_emember_pwd'], 'login_link' => sanitize_text_field($login_link));

                    $subject_rego_complete = emember_dynamically_replace_member_details_in_message($curr_member_id, $subject_rego_complete, $additional_params);
                    $email_body1 = emember_dynamically_replace_member_details_in_message($curr_member_id, $body_rego_complete, $additional_params);

                    // The filter for email notification body
                    $email_body1 = apply_filters('eMember_notification_email_body_filter', $email_body1, $curr_member_id);

                    $headers = 'From: ' . $from_address . "\r\n";
                    $member_email = sanitize_email($_POST['wp_emember_email']);

                    if (!empty($email_body1)) {
                        wp_mail($member_email, $subject_rego_complete, $email_body1, $headers);
                        eMember_log_debug("Member registration complete email successfully sent to: " . $member_email, true);
                    } else {
                        eMember_log_debug("The email body field is empty. No registration complete email will be sent.", true);
                    }

                    if ($emember_config->getValue('eMember_admin_notification_after_registration')) {
                        //Note: this can contain a comma separated list of email addresses. So do sanitization after the explode call.
                        $admin_email_list = $emember_config->getValue('eMember_admin_notification_email_address');
                        $notify_emails_array = explode(",", $admin_email_list);
                        foreach ($notify_emails_array as $notify_email_address) { // Send notification emails to all addresses
                            $notify_email_address = sanitize_email($notify_email_address);//Sanitize the email value.
                            if (!empty($notify_email_address)) {
                                $admin_notification_subject = EMEMBER_NEW_ACCOUNT_MAIL_HEAD;
                                $admin_email_body = EMEMBER_NEW_ACCOUNT_MAIL_BODY .
                                        "\n\n-------Member Email----------\n" .
                                        $email_body1 .
                                        "\n\n------End------\n";
                                wp_mail($notify_email_address, $admin_notification_subject, $admin_email_body, $headers);
                                eMember_log_debug("Admin notification email successfully sent to: " . $notify_email_address, true);
                            }
                        }
                    }
                    // Create the corresponding affliate account
                    if ($emember_config->getValue('eMember_auto_affiliate_account')) {
                        eMember_log_debug("Creating affiliate account for this member.", true);
                        eMember_handle_affiliate_signup(sanitize_text_field($_POST['wp_emember_user_name']), $_POST['wp_emember_pwd'], sanitize_text_field($_POST['wp_emember_firstname']), sanitize_text_field($_POST['wp_emember_lastname']), sanitize_email($_POST['wp_emember_email']), eMember_get_aff_referrer());
                    }

                    /* === Signup the member to Autoresponder List (Autoresponder integration) === */
                    eMember_log_debug("===> Performing autoresponder signup if needed <===", true);
                    $membership_level_id = sanitize_text_field($fields['membership_level']);
                    $firstname = isset($_POST['wp_emember_firstname']) ? sanitize_text_field($_POST['wp_emember_firstname']) : "";
                    $lastname = isset($_POST['wp_emember_lastname']) ? sanitize_text_field($_POST['wp_emember_lastname']) : "";
                    $emailaddress = sanitize_email($_POST['wp_emember_email']);
                    eMember_level_specific_autoresponder_signup($membership_level_id, $firstname, $lastname, $emailaddress);
                    eMember_global_autoresponder_signup($firstname, $lastname, $emailaddress);
                    /* === end of autoresponder integration === */

                    /* === check redirection options and redirect accordingly === */
                    $after_rego_page = $emember_config->getValue('eMember_after_registration_page');
                    $redirect_page = $emember_config->getValue('login_page_url');
                    $auto_login_after_rego = $emember_config->getValue('eMember_enable_auto_login_after_rego');
                    if ($auto_login_after_rego) {
                        if (!empty($redirect_page)) {
                            $separator = wp_emember_get_query_separator_for_url($redirect_page);
                            $encoded_pass = base64_encode($_POST['wp_emember_pwd']);
                            $redirect_page = $redirect_page . $separator . "doLogin=1&pwd_encoded=1&emember_u_name=" . urlencode(sanitize_text_field($_POST['wp_emember_user_name'])) . "&emember_pwd=" . urlencode($encoded_pass);
                            // $redirect_page = wp_nonce_url($redirect_page,'emember-login-nonce');
                            $login_nonce = wp_create_nonce('emember-login-nonce');
                            $redirect_page = $redirect_page . "&_wpnonce=" . $login_nonce;
                            wp_emember_redirect_to_url($redirect_page);
                        } else {
                            $output .= '<div class="emember_error">Error! The "Login Page URL" field value is missing! Go to the Pages/Forms settings menu and correct the mistake.</div>';
                            $emember_config->set_stacked_message('emember_full_registration', array('type' => 'warning', 'message' => $output));
                        }
                    } else if (!empty($after_rego_page)) {
                        wp_emember_redirect_to_url($after_rego_page);
                    } else {
                        if ($eMember_manually_approve_member_registration) {
                            $output .= '<p class="emember_registration_complete_msg">' . EMEMBER_REG_COMPLETE_PENDING_APPROVAL . '</p>';
                        } else {
                            $output .= '<p class="emember_registration_complete_msg">' . EMEMBER_REG_COMPLETE . EMEMBER_PLEASE . ' <a href="' . sanitize_text_field($redirect_page) . '">' . EMEMBER_LOGIN . '</a></p>';
                        }
                        $emember_config->set_stacked_message('emember_full_registration', array('type' => 'success', 'message' => $output));
                    }
                    // End of redirection stuff
                } else {
                    $output .= "<b><br/>Something went wrong. Please Contact <a href='mailto:" . sanitize_email(get_bloginfo('admin_email')) . "'>Admin.</a></b>";
                    $emember_config->set_stacked_message('emember_full_registration', array('type' => 'warning', 'message' => $output));
                }
            } // End no error on submission
        } // End recaptcha valid block
        else {
            $emember_config->set_stacked_message('emember_full_registration', array('type' => 'error', 'message' => $captcha_result->message));
        }
    } // End POST register submission
    return;
}

function show_registration_form($level = 0) {
    do_action('emember_before_rendering_registration_form');

    $result = apply_filters('emember_registration_override', $level);
    if ($result != $level)
        return $result;

    global $wpdb;
    $emember_config = Emember_Config::getInstance();
    $recaptcha_error = $emember_config->get_stacked_message('emember_full_registration_captcha');
    $eMember_id = sanitize_text_field(isset($_GET["member_id"]) ? $_GET["member_id"] : "");
    $code = sanitize_text_field(isset($_GET["code"]) ? $_GET["code"] : "");
    $stacked_msg = $emember_config->get_stacked_message('emember_full_registration');
    $output = '';
    if (!empty($stacked_msg)) {
        if (($stacked_msg['type'] == 'warning') || ($stacked_msg['type'] == 'success'))
            return $stacked_msg['message'];
    }
    if (!empty($stacked_msg) && ($stacked_msg['type'] == 'error'))
        $output .= $stacked_msg['message'];


    if (!empty($eMember_id) && !empty($code)) {
        $resultset = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . esc_sql($eMember_id));

        if (empty($resultset->reg_code)) {//Error condition
            $output = '<span class="emember_error">' . EMEMBER_ALREADY_USED_REGISTRATION_CODE . '</span>';
            return $output;
        }

        $md5code = md5($resultset->reg_code);
        if ($code == $md5code) {
            $free_member_level = $resultset->membership_level;
            $level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id=' . esc_sql($free_member_level));
            $_POST['wp_emember_member_level'] = $level_resultset->alias;
            $_POST['wp_emember_firstname'] = $resultset->first_name;
            $_POST['wp_emember_lastname'] = $resultset->last_name;
            $_POST['wp_emember_email'] = $resultset->email;
            $_SESSION['eMember_id'] = $eMember_id;
            $_SESSION['reg_code'] = $code;
            $_POST['eMember_id'] = $eMember_id;
            $_POST['eMember_reg_code'] = $code;
            $output .= '<div class="wp_emember_user_pass_msg">' . EMEMBER_USER_PASS_MSG . '</div>';
            $output .= eMember_reg_form($recaptcha_error);
        }
    } else if ($emember_config->getValue('eMember_enable_free_membership') || !empty($level)) {
        if (isset($_POST['custom_member_level_shortcode'])) {
            $level = $_POST['custom_member_level_shortcode'];
        }
        if (!empty($level)) {
            $level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id=' . esc_sql($level));
            if (!$level_resultset) {
                $output .= '<p style="color:red;">You seem to have specified a membership level ID that does not exist. Please correct the membership level ID in the shortcode.</p>';
                return $output;
            }
            $_POST['wp_emember_member_level'] = $level_resultset->alias;
            $output .= eMember_reg_form($recaptcha_error, $level);
        } else {
            $free_member_level = $emember_config->getValue('eMember_free_membership_level_id');
            if (empty($free_member_level))
                return "<b>Free Membership Level ID has not been specified. Site Admin needs to correct the settings in the settings menu of eMember.</b>";
            if (!is_numeric($free_member_level))
                return "<b>Free Membership Level should be numeric. Site Admin needs to correct the settings in the settings menu of eMember.</b>";
            $level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id=' . esc_sql($free_member_level));
            $_POST['wp_emember_member_level'] = $level_resultset->alias;
            $eMember_free_members_must_confirm_email = $emember_config->getValue('eMember_free_members_must_confirm_email');
            if ($eMember_free_members_must_confirm_email) {
                $output .= free_rego_with_email_confirmation_handler();
            } else {
                $output .= eMember_reg_form($recaptcha_error, $level);
            }
        }
    } else {
        //Free membership is disabled
        $output .= EMEMBER_FREE_MEMBER_DISABLED;
        $payment_page = $emember_config->getValue('eMember_payments_page');
        if (!empty($payment_page)) {
            $output .= '<br />' . EMEMBER_VISIT_PAYMENT_PAGE . '. ' . EMEMBER_CLICK . ' <a href="' . $payment_page . '">' . EMEMBER_HERE . '</a>';
        }
    }
    return $output;
}

function eMember_reg_form($error = null, $level = 0) {
    global $wpdb;

    $emember_config = Emember_Config::getInstance();
    //Check if the email field should be read only
    $readonlyemail = '';
    $eMember_free_members_must_confirm_email = $emember_config->getValue('eMember_free_members_must_confirm_email');
    if ($eMember_free_members_must_confirm_email && !empty($_POST['wp_emember_email'])) {
        //Check and see if this is a rego complete for free level
        $membership_level_name = $_POST['wp_emember_member_level'];
        $level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " alias='" . $membership_level_name . "'");
        $free_member_level = $emember_config->getValue('eMember_free_membership_level_id');
        if ($level_resultset->id == $free_member_level) {
            $readonlyemail = 'readonly="readonly"';
        }
    }

    //Recaptcha
    ob_start();
    $letter_number_underscore = $emember_config->getValue('eMember_auto_affiliate_account') ?
            ',custom[onlyLetterNumberUnderscore]' : ',custom[ememberUserName]';
    ?>
    <script type="text/javascript" src="<?php echo site_url(); ?>?emember_load_js=registration&id=wp_emember_regoForm"></script>
    <link rel='stylesheet' href='<?php echo WP_EMEMBER_URL; ?>/css/pure-min.css?ver=<?php echo WP_EMEMBER_VERSION; ?>' type='text/css' media='all' />
    <form action="" method="post" name="wp_emember_regoForm" id="wp_emember_regoForm" class="pure-form pure-form-stacked" >
        <fieldset>
            <?php wp_nonce_field('emember-plain-registration-nonce'); ?>
            <input type="hidden" name="emember_dsc_nonce" value="<?php echo uniqid(); ?>">
            <?php if (isset($level) && !empty($level)) { ?>
                <input type="hidden" name="custom_member_level_shortcode" value="<?php echo $level; ?>" />
            <?php } ?>
            <?php if (isset($_POST['eMember_id']) && isset($_POST['eMember_reg_code'])) { ?>
                <input type="hidden" name="eMember_id" value="<?php echo esc_attr($_POST['eMember_id']); ?>" />
                <input type="hidden" name="eMember_reg_code" value="<?php echo esc_attr($_POST['eMember_reg_code']); ?>" />
            <?php } ?>
            <div class="wp_emember_user_name">
                <input type="text" id="wp_emember_user_name" name="wp_emember_user_name" autocomplete="off" size="20" title="<?php echo EMEMBER_USERNAME; ?>" placeholder="<?php echo EMEMBER_USERNAME; ?>" value="<?php echo strip_tags(isset($_POST['wp_emember_user_name']) ? $_POST['wp_emember_user_name'] : ""); ?>" class="validate[required,custom[noapostrophe],minSize[4]<?php echo $letter_number_underscore ?>,ajax[ajaxUserCall]] pure-input-1" />
            </div>
            <div class="wp_emember_pwd">
                <input type="password" id="wp_emember_pwd" name="wp_emember_pwd" autocomplete="off" size="20" title="<?php echo EMEMBER_PASSWORD; ?>" placeholder="<?php echo EMEMBER_PASSWORD; ?>" value="" class="validate[required,minSize[6]] pure-input-1" />
            </div>
            <?php if ($emember_config->getValue('eMember_show_confirm_pass_field')): ?>
                <div class="wp_emember_pwd_re">
                    <input type="password" id="wp_emember_pwd_re" name="wp_emember_pwd_re" autocomplete="off" size="20" title="<?php echo EMEMBER_PASSWORD_REPEAT; ?>" placeholder="<?php echo EMEMBER_PASSWORD_REPEAT; ?>" value="" class="validate[required,minSize[6],equals[wp_emember_pwd] pure-input-1" />
                </div>
            <?php endif; ?>
            <div class="wp_emember_email">
                <input type="text" id="wp_emember_email" name="wp_emember_email" size="20" title="<?php echo EMEMBER_EMAIL; ?>" placeholder="<?php echo EMEMBER_EMAIL; ?>" value="<?php echo trim(strip_tags(isset($_POST['wp_emember_email']) ? $_POST['wp_emember_email'] : "")); ?>" class="validate[required,custom[email]] pure-input-1" <?php echo $readonlyemail; ?> />
            </div>
            <div class="wp_emember_member_level<?php echo $emember_config->getValue('eMember_hide_membership_field') ? " hidden" : ""; ?>">
                <input type="text" id="wp_emember_member_level" name="wp_emember_member_level" size="20" title="<?php echo EMEMBER_MEMBERSHIP_LEVEL; ?>" placeholder="<?php echo EMEMBER_MEMBERSHIP_LEVEL; ?>: <?php echo strip_tags(isset($_POST['wp_emember_member_level']) ? $_POST['wp_emember_member_level'] : ""); ?>" value="" class="pure-input-1" readonly /></td>
            </div>
        </fieldset>
        <fieldset>
            <?php if ($emember_config->getValue('eMember_reg_title')): ?>
                <div class="wp_emember_title">
                    <select name="wp_emember_title" title="<?php echo EMEMBER_TITLE; ?>" class="pure-input-1">
                        <option  <?php echo ((isset($_POST['wp_emember_title']) && ($_POST['wp_emember_title'] === 'not specified')) ? 'selected=\'selected\'' : '' ) ?> value="not specified"><?php echo EMEMBER_TITLE . ': ' . EMEMBER_GENDER_UNSPECIFIED ?></option>
                        <option <?php echo ((isset($_POST['wp_emember_title']) && ($_POST['wp_emember_title'] === 'Mr')) ? 'selected=\'selected\'' : '' ) ?> value="Mr"><?php echo EMEMBER_MR; ?></option>
                        <option <?php echo ((isset($_POST['wp_emember_title']) && ($_POST['wp_emember_title'] === 'Mrs')) ? 'selected=\'selected\'' : '' ) ?> value="Mrs"><?php echo EMEMBER_MRS; ?></option>
                        <option <?php echo ((isset($_POST['wp_emember_title']) && ($_POST['wp_emember_title'] === 'Miss')) ? 'selected=\'selected\'' : '' ) ?> value="Miss"><?php echo EMEMBER_MISS; ?></option>
                        <option <?php echo ((isset($_POST['wp_emember_title']) && ($_POST['wp_emember_title'] === 'Ms')) ? 'selected=\'selected\'' : '' ) ?> value="Ms"><?php echo EMEMBER_MS; ?></option>
                        <option <?php echo ((isset($_POST['wp_emember_title']) && ($_POST['wp_emember_title'] === 'Dr')) ? 'selected=\'selected\'' : '' ) ?> value="Dr"><?php echo EMEMBER_DR; ?></option>
                    </select>
                </div>
            <?php endif; ?>
            <?php
            $optionNames = array('eMember_reg_firstname', 'eMember_reg_lastname', 'eMember_reg_phone', 'eMember_reg_company', 'eMember_reg_street', 'eMember_reg_city', 'eMember_reg_state', 'eMember_reg_zipcode');
            $fieldNames = array('wp_emember_firstname', 'wp_emember_lastname', 'wp_emember_phone', 'wp_emember_company_name', 'wp_emember_street', 'wp_emember_city', 'wp_emember_state', 'wp_emember_zipcode');
            $labelNames = array(EMEMBER_FIRST_NAME, EMEMBER_LAST_NAME, EMEMBER_PHONE, EMEMBER_COMPANY, EMEMBER_ADDRESS_STREET, EMEMBER_ADDRESS_CITY, EMEMBER_ADDRESS_STATE, EMEMBER_ADDRESS_ZIP);

            foreach ($optionNames as $key => $option) {
                if ($emember_config->getValue($option)) {
                    $value = esc_attr(isset($_POST[$fieldNames[$key]]) ? $_POST[$fieldNames[$key]] : "");
                    $class = $emember_config->getValue($option . '_required') ? 'validate[required] ' : "";
                    echo "<div class='{$fieldNames[$key]}'><input type='text' id='{$fieldNames[$key]}' name='{$fieldNames[$key]}' size='20' title='{$labelNames[$key]}' placeholder='{$labelNames[$key]}' value='{$value}' class='{$class}pure-input-1' /></div>";
                }
            }
            if ($emember_config->getValue('eMember_reg_country')):
                ?>
                <div class="wp_emember_country">
                    <select name="wp_emember_country" title="<?php echo EMEMBER_ADDRESS_COUNTRY; ?>" id="wp_emember_country" class="<?php echo $emember_config->getValue('eMember_reg_country_required') ? 'validate[required] ' : ""; ?>pure-input-1" >
                        <?php
                        $selected_country = isset($_POST['wp_emember_country']) ? sanitize_text_field($_POST['wp_emember_country']) : "";
                        echo emember_country_list_dropdown($selected_country);
                        ?>
                    </select>
                </div>
                <?php
            endif;
            if ($emember_config->getValue('eMember_reg_gender')):
                ?>
                <div class="wp_emember_gender">
                    <select name="wp_emember_gender" title="<?php echo EMEMBER_GENDER; ?>" id="wp_emember_gender" class="pure-input-1">
                        <option  <?php echo ((isset($_POST['wp_emember_gender']) && ($_POST['wp_emember_gender'] === 'not specified')) ? 'selected=\'selected\'' : '' ) ?> value="not specified"><?php echo EMEMBER_GENDER . ': ' . EMEMBER_GENDER_UNSPECIFIED ?></option>
                        <option  <?php echo ((isset($_POST['wp_emember_gender']) && ($_POST['wp_emember_gender'] === 'male')) ? 'selected=\'selected\'' : '' ) ?> value="male"><?php echo EMEMBER_GENDER_MALE ?></option>
                        <option  <?php echo ((isset($_POST['wp_emember_gender']) && ($_POST['wp_emember_gender'] === 'female')) ? 'selected=\'selected\'' : '' ) ?> value="female"><?php echo EMEMBER_GENDER_FEMALE ?></option>
                    </select>
                </div>
            <?php endif; ?>
        </fieldset>
        <?php
        include ('custom_field_template.php');
        $use_ssl = false;
        if (isset($_SERVER["HTTPS"]) && ($_SERVER["HTTPS"] == "on")) {
            $use_ssl = true;
        }
        ?>
        <fieldset class="emember-centered">
            <?php
            if ($emember_config->getValue('eMember_show_terms_conditions')):
                ?>
                <div class="emember_terms_conditions">
                    <label class="pure-checkbox"><input type="checkbox" class="validate[required]" id="emember_terms_conditions" name="emember_terms_conditions" value="1"> <?php echo EMEMBER_ACCEPT; ?> <a href="<?php echo $emember_config->getValue('eMember_terms_conditions_page'); ?>" target="_blank"> <?php echo EMEMBER_TERMS_CONDITIONS; ?></a></label>
                </div>
                <?php
            endif;
            ?>
            <div class="wp_emember_recaptcha">
                <?php
                $recaptcha = emember_recaptcha_html();
                echo apply_filters('emember_captcha', $recaptcha);
                ?>
            </div>
        </fieldset>
        <fieldset class="pure-controls emember-centered">
            <div class="eMember_Register">
                <button id="eMember_Register" type="submit" class="pure-button pure-button-active emember-registration-submit-button"><?php echo EMEMBER_REGISTRATION; ?></button>
                <input class="pure-button pure-button-active emember-registration-submit-input" name="eMember_Register" type="hidden" value="<?php echo EMEMBER_REGISTRATION; ?>" />
            </div>
        </fieldset>
    </form><br />
    <?php
    $output = ob_get_contents();
    ob_end_clean();
    return $output;
}

function create_new_emember_user($data) {
    global $wpdb;
    $data = array_filter($data); //Remove any null values.
    $wpdb->insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $data);
}

function is_blocked_email($user_email) {
    $user_email = trim($user_email);
    $emember_config = Emember_Config::getInstance();

    //Check if the email address is blacklisted
    $blacklisted_emails = $emember_config->getValue('blacklisted_emails');
    $blacklisted_emails = empty($blacklisted_emails) ? array() : explode(';', $blacklisted_emails);
    foreach ($blacklisted_emails as $email) {
        $email = trim($email);
        if ((!empty($email)) && stristr($user_email, $email)) {
            //This is a blacklisted email
            return true;
        }
    }

    //Check if the email address pattern is blacklisted
    $blacklisted_email_patterns = $emember_config->getValue('blacklisted_email_patterns');
    $blacklisted_email_patterns = empty($blacklisted_email_patterns) ? array() : explode(';', $blacklisted_email_patterns);
    foreach ($blacklisted_email_patterns as $email_pattern) {
        $email_pattern = trim($email_pattern);
        if ((!empty($email_pattern)) && stristr($user_email, $email_pattern)) {
            //This user's address matches with a blacklisted email pattern.
            return true;
        }
    }

    //This address is clear (not blacklisted)
    return false;
}

function is_blocked_ip($user_ip) {
    $user_ip = trim($user_ip);
    $emember_config = Emember_Config::getInstance();
    $blacklisted_ips = $emember_config->getValue('blacklisted_ips');
    $blacklisted_ips = empty($blacklisted_ips) ? array() : explode(';', $blacklisted_ips);
    $current_ip = get_real_ip_addr();
    foreach ($blacklisted_ips as $ip) {
        $ip_port = explode(':', $ip);
        $ip = trim($ip_port[0]);

        if (!empty($ip) && (preg_match('/^(' . $ip . ')/', $user_ip) === 1))
            return true;
    }
    return false;
}
