<?php

function recaptcha_settings() {
    $emember_config = Emember_Config::getInstance();
    $msg = null;
    echo '<div class="wrap">';
    echo '<div id="poststuff"><div id="post-body">';
    if (isset($_POST['info_update'])) {
        // Verify nonce
        if (!isset($_POST['emember_recaptcha_settings_nonce']) || !wp_verify_nonce($_POST['emember_recaptcha_settings_nonce'], 'emember_recaptcha_settings_action')) {
            wp_die('Nonce security check failed');
        }
        
        if (isset($_POST["emember_enable_recaptcha"])) {
            if (empty($_POST["emember_recaptcha_public"]) || empty($_POST["emember_recaptcha_private"])) {
                $emember_config->setValue('emember_enable_recaptcha', 0);
                $msg = 'Google reCAPTCHA can\'t be enabled without public and private API keys.';
            } else {
                $emember_config->setValue('emember_enable_recaptcha', 1);
                $emember_config->setValue('emember_recaptcha_public', trim($_POST["emember_recaptcha_public"]));
                $emember_config->setValue('emember_recaptcha_private', trim($_POST["emember_recaptcha_private"]));
                //Check if the login form captcha is enabled
                isset($_POST["emember_enable_recaptcha_login_form"]) ? $emember_config->setValue('emember_enable_recaptcha_login_form', 1) : $emember_config->setValue('emember_enable_recaptcha_login_form', 0);
            }
        } else {
            $emember_config->setValue('emember_enable_recaptcha', 0);
            $msg = 'Google reCAPTCHA is recommended for protection against spam.';
        }

        echo '<div id="message" class="updated fade"><p>';
        echo ($msg) ? $msg : 'Options Updated!';
        echo '</p></div>';
        $emember_config->saveConfig();
    }

    $enable_captcha_login_form = $emember_config->getValue('emember_enable_recaptcha_login_form');
    ?>

    <div class="eMember_grey_box">
        <p>It is recommended to use Google reCAPTCHA on your registration form to prevent spam registration (Specially, if you are offering any kind of free membership registration on your site).</p>
    </div>

    <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
        <?php wp_nonce_field('emember_recaptcha_settings_action', 'emember_recaptcha_settings_nonce'); ?>	
        <input type="hidden" name="info_update" id="info_update" value="true" />
        <div class="postbox">
            <h3 class="hndle"><label for="title">reCAPTCHA Settings (If you want to use <a href="https://www.google.com/recaptcha/admin/create" target="_blank">reCAPTCHA</a> then you need to get reCAPTCHA API keys from <a href="https://www.google.com/recaptcha/admin/create" target="_blank">here</a> and use in the settings below)</label></h3>
            <div class="inside">
                <table width="100%" border="0" cellspacing="0" cellpadding="6">
                    <tr valign="top"><td width="25%" align="left">
                            Enable reCAPTCHA:</td>
                        <td align="left">
                            <?php
                            if (version_compare(PHP_VERSION, '5.3.2') >= 0) {
                                //Google captcha can be used
                                $enable_captcha = $emember_config->getValue('emember_enable_recaptcha');
                                ?>
                                <input name="emember_enable_recaptcha" type="checkbox" <?php echo ($enable_captcha) ? 'checked="checked"' : ''; ?> value="1"/>
                                <p class="description">Enable this option if you want to use Google reCAPTCHA on the member registration form. It will enable captcha on the password reset form also.</p>
                                <?php
                            } else {
                                //PHP version too old. Can't support the new Google captcha library.
                                echo '<p style="color: red;">Warning! PHP version of your server is too old. You need to upgrade PHP version to PHP 5.6+ to be able to use Google reCAPTCHA.</p>';
                                //Disable recaptcha option
                                $emember_config->setValue('emember_enable_recaptcha', 0);
                                $emember_config->saveConfig();
                            }
                            ?>
                        </td></tr>

                    <tr valign="top">
                        <td width="25%" align="left">Site/Public key:</td>
                        <td align="left">
                            <input name="emember_recaptcha_public" size=60 type="text"   value="<?php echo $emember_config->getValue('emember_recaptcha_public'); ?>"/>
                            <p class="description">The public key for the reCAPTCHA API</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <td width="25%" align="left">Secret/Private key:</td>
                        <td align="left">
                            <input name="emember_recaptcha_private" type="text" size=60 value="<?php echo $emember_config->getValue('emember_recaptcha_private'); ?>"/>
                            <p class="description">The private key for the reCAPTCHA API</p>
                        </td>
                    </tr>

                    <tr valign="top">
                        <td width="25%" align="left">Enable reCAPTCHA on Login Form:</td>
                        <td align="left">
                            <?php
                            $auto_login_after_rego = $emember_config->getValue('eMember_enable_auto_login_after_rego');
                            if ($auto_login_after_rego) {//Auto login after registration is enabled. After registration redirection is useless.
                                echo '<div class="eMember_grey_box">You have activated the "Auto Login After Registration" feature in the general settings. However, automatic login won\'t work with the captcha. If you want to use a login captcha, please disable the auto login option.';
                                echo '</div>';
                            } else {//Allow after registration redirect configuration.
                            ?>
                            <input name="emember_enable_recaptcha_login_form" type="checkbox" <?php echo ($enable_captcha_login_form) ? 'checked="checked"' : ''; ?> value="1"/>
                            <p class="description">Use this if you want to enable reCAPTCHA on the member login form also.</p>
                            <?php 
                            }
                            ?>
                        </td>
                    </tr>

                </table>
            </div>
        </div>

        <div class="submit">
            <input type="submit" name="info_update" class="button-primary" value="<?php _e('Update options'); ?> &raquo;" />
        </div>
    </form>

    <?php
    echo '</div></div>';
    echo '</div>';
}
