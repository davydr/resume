<script>
    jQuery('.eMember_show_pw_btn').click(function() {
        if (jQuery(this).find('i').hasClass('dashicons-visibility')) {
            jQuery(this).find('i').removeClass('dashicons-visibility').addClass('dashicons-hidden');
            jQuery('#login_pwd').prop('type', 'text');
        } else {
            jQuery(this).find('i').removeClass('dashicons-hidden').addClass('dashicons-visibility');
            jQuery('#login_pwd').prop('type', 'password');
        }
    });
</script>