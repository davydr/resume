jQuery(document).ready(function ($) {
    //Add date picker listener on date fields
    if ($.fn.datepicker) {
        //Jquery UI datepicker library loaded. 
        //So replace the type="date" with "text" then attach our date picker for better user friendly interface.
        //This prevents conflict with datepicker and browser's standard date type field handling.
        
        //Replace date type field with "text" type.
        $('.emember_date_picker').each(function () {
            this.type = "text";
        });

        //Attach our datepicker.
        $('.emember_date_picker').datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true, 
            changeYear: true, 
            yearRange: "-100:+100"
        });
    }
});