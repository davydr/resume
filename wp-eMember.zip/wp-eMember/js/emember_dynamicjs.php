<?php
//Add the dynamic js stuff if specified in the settings
$debug_marker = "<!-- WP eMember plugin v" . WP_EMEMBER_VERSION . " - http://www.tipsandtricks-hq.com/wordpress-emember-easy-to-use-wordpress-membership-plugin-1706 -->";
echo "\n" . $debug_marker . "\n";
$emember_config = Emember_Config::getInstance();
?>
<script type="text/javascript">
    /* <![CDATA[ */
    jQuery(document).ready(function($) {
<?php
$enable_bookmark = $emember_config->getValue('eMember_enable_bookmark');
if ($enable_bookmark):
    ?>
            $(".ememberbookmarkbutton").find("a").click(function(e) {
                e.preventDefault();
                var id = jQuery(this).attr("href");
                if (!id)
                    return;
                var $this = this;
                $.get('<?php echo admin_url("admin-ajax.php"); ?>',
                        {event: "bookmark_ajax",
                            action: "bookmark_ajax",
                            id: id,
                            "_ajax_nonce": "<?php echo wp_create_nonce('emember-add-bookmark-nonce'); ?>"},
                function(data) {
                    $($this).parent().html(data.msg);
                },
                        "json"
                        );
            });
<?php endif; ?>
<?php if ($emember_config->getValue('eMember_enable_fancy_login') == '1' || $emember_config->getValue('eMember_enable_fancy_login') == '2'): ?>
            //fancy login start//
            $('#emem_ui_close').click(function(e) {
                $(this).parent().hide('slow');
                $('#marker').html("");
            });
            $('.emember_fancy_login_link').click(
                    function(e) {
                        var targetId = $(e.target).addClass('emember_activeLink').attr('id');
                        var alreadyOpened = $('#marker');
                        var menu = $('#emember_signin_menu');
                        var offset = $(e.target).offset();
                        if (!alreadyOpened.html()) {
                            alreadyOpened.html(targetId);
                            menu.css({'left': offset.left + 'px', 'top': (offset.top + 20) + 'px'}).show('slow');
                        }
                        else if (targetId != alreadyOpened.html()) {
                            alreadyOpened.html(targetId);
                            menu.hide().css({'left': offset.left + 'px', 'top': (offset.top + 20) + 'px'}).show('slow');
                        } else if (targetId == alreadyOpened.html()) {
                            $(e.target).removeClass('emember_activeLink');
                            alreadyOpened.html("");
                            menu.hide('slow');
                        }
                    }
            );
            $('#emember_fancy_login_form').submit(function() {
                var msg = "<?php echo EMEMBER_PLEASE ?>" + " <?php echo EMEMBER_WAIT; ?> ...";
                $('#emember_fancy_log_msg').css('color', 'black').html(msg + '<br/>');
                $.post('<?php echo admin_url("admin-ajax.php"); ?>', $(this).serialize(), function(result) {
                    if (result.status) {
                        var redirect = '<?php echo $emember_config->getValue('eMember_enable_redirection'); ?>';
                        if (redirect) {
                            var url = get_redirect_url(result.redirect);
                            window.location.href = url;
                        } else {
                            window.location.reload();
                        }
                    }
                    else {
                        $('#emember_fancy_log_msg').css('color', 'red').html(result.msg + '<br/>');
                    }
                }, 'json');
                return false;
            });
            //fancy login end//
<?php elseif ($emember_config->getValue('eMember_enable_fancy_login') == '2'): ?>
//Fancy login 2 is disabled for now. It will show fancy 1 (to keep it backward compatible).
<?php endif; ?>
        function get_redirect_url($redirects) {
            var $after_login_page = '<?php echo $emember_config->getValue('after_login_page'); ?>';
            if ($redirects.own)
                return $redirects.own;
            if ($redirects.level)
                return $redirects.level;
            if ($after_login_page)
                return $after_login_page;
            return '';
        }
    });
    /* ]]> */
</script>
