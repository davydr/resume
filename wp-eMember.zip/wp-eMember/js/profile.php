<?php
$emember_auth = Emember_Auth::getInstance();
$emember_config = Emember_Config::getInstance();
$use_gravatar = $emember_config->getValue('eMember_use_gravatar');
?>
jQuery(document).ready(function($){
var ememAttrName='';
var uploadBtnPrevContent='';
$('#emember-profile-remove-cont').on('emember_profile',function(){
var button = $('#remove_button');
if ($(button).is(':button')) {
ememAttrName = 'data-imagepath';
} else {
ememAttrName = 'href';
}
var id = button.attr(ememAttrName);
if(id)$(this).show();
else $(this).hide();
}).trigger('emember_profile');

<?php if ($emember_config->getValue('eMember_profile_thumbnail') && empty($use_gravatar)): ?>
    $('#remove_button').click(function(e){
    if ($(this).is(':button')) {
    ememAttrName='data-imagepath';
    } else {
    ememAttrName='href';
    }
    var imagepath = $(this).attr(ememAttrName);
    if(imagepath){
    $.get( '<?php echo admin_url('admin-ajax.php'); ?>',{"action":"delete_profile_picture","path":imagepath},
    function(data){
    $("#emem_profile_image").attr("src",   "<?php echo WP_EMEMBER_URL; ?>/images/default_profile_image.png?" + (new Date()).getTime());
    $('#remove_button').attr(ememAttrName,'');
    $('#emember-profile-remove-cont').trigger('emember_profile');
    },
    "json");
    }
    e.preventDefault();
    });

    if($('#emember-file-uploader').length)
    var uploader = new qq.FileUploader({
    button_label: '<?php echo EMEMBER_UPLOAD; ?>',
    element: document.getElementById('emember-file-uploader'),
    action: '<?php echo admin_url("admin-ajax.php"); ?>',
    params: {'action':'emember_upload_ajax',
    'image_id':<?php echo $emember_auth->getUserInfo('member_id'); ?>},
    onSubmit: function () {
    uploadBtnPrevContent = $('div.qq-upload-button span').html();
    $('div.qq-upload-button span').html('<img src="<?php echo WP_EMEMBER_URL ?>/images/loading-tiny.gif">');
    },
    onComplete: function(id, fileName, responseJSON){
    $('div.qq-upload-button span').html(uploadBtnPrevContent);
    if(responseJSON.success){
    <?php $upload_dir = wp_upload_dir(); ?>
    var $url = "<?php echo $upload_dir['baseurl']; ?>/emember/" +responseJSON.filename +"?" + (new Date()).getTime();
    var $dir =  +responseJSON.id;
    $("#emem_profile_image").attr("src", $url);
    $('#remove_button').attr(ememAttrName,$dir);
    $('#emember-profile-remove-cont').trigger('emember_profile');
    }
    }});
<?php endif; ?>
});
