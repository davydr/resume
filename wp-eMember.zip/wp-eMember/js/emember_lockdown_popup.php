<div id="lockdownbox" class="emember_modal" style="display: block; margin-left: auto; margin-right: auto; margin-top: 100px;">
    <div>
        <h2>
            <?php echo esc_html(EMEMBER_AUTH_REQUIRED); ?> <br/>
        </h2>
        <form action="<?php //echo esc_url($login_url) ?>" id="loginForm" class="wp_emember_loginForm" name="loginForm" method="post">
            <?php wp_nonce_field('emember-login-nonce'); ?>
            <p class="textbox">
                <label for="login_user_name" class="eMember_label"><?php echo esc_html(EMEMBER_USER_NAME); ?></label>
                <input type="text" tabindex="4" title="username" value="" name="login_user_name" id="login_user_name" />
            </p>
            <p class="textbox">
                <label for="login_pwd" class="eMember_label"><?php echo esc_html(EMEMBER_PASSWORD); ?></label>
                <input type="password" tabindex="5" title="password" value="" name="login_pwd" id="login_pwd" />
            </p>
            <p class="textbox">
                <?php echo apply_filters('emember_captcha_login', ""); ?>
            </p>
            <p class="rememberme">
                <input type="submit" tabindex="7" value="<?php echo esc_attr(EMEMBER_SIGNIN); ?>" name="doLogin" class="emember_button" id="doLogin" />
                <input type="checkbox" tabindex="6" value="forever" name="rememberme" id="rememberme" />
                <input type="hidden" value="1" name="testcookie" />
                <label for="rememberme"><?php echo esc_html(EMEMBER_REMEMBER_ME); ?></label>
            </p>
            <p style="color:red;"><?php echo ($emember_auth->getCode() != 1) ? esc_html($emember_auth->getMsg()) : ''; ?></p>
            <p class="forgot">
                <?php
                $password_reset_url = $emember_config->getValue('eMember_password_reset_page');
                if ($password_reset_url):
                    ?>
                    <a id="forgot_pass" href="<?php echo esc_url($password_reset_url); ?>"><?php echo esc_html(EMEMBER_FORGOT_PASS); ?></a>
                <?php else : ?>
                    <a id="forgot_pass" rel="#emember_forgot_pass_prompt" class="forgot_pass_link" href="javascript:void(0);"><?php echo esc_html(EMEMBER_FORGOT_PASS); ?></a>
                <?php endif; ?>
            </p>
            <p class="forgot-username">
                <a title="Join us" id="join_us" href="<?php echo esc_url($join_url); ?>"><?php echo esc_html(EMEMBER_JOIN_US); ?></a>
            </p>
        </form>
    </div>
</div>

</body>
</html>
