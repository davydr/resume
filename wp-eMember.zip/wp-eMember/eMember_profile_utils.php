<?php

function filter_eMember_edit_profile_form($content) {
    $auth = Emember_Auth::getInstance();
    $pattern = '#\[wp_eMember_profile_edit_form:end]#';
    preg_match_all($pattern, $content, $matches);
    if ((count($matches[0]) > 0) && !$auth->isLoggedIn()) {
        return EMEMBER_PROFILE_MESSAGE;
    }

    foreach ($matches[0] as $match) {
        $replacement = print_eMember_edit_profile_form();
        $content = str_replace($match, $replacement, $content);
    }

    return $content;
}

function print_eMember_edit_profile_form() {
    return show_edit_profile_form();
}

function show_edit_profile_form() {
    $result = apply_filters('emember_profile_form_override', '');
    if (!empty($result)) {
        return $result;
    }
    $emember_auth = Emember_Auth::getInstance();
    if (!$emember_auth->isLoggedIn()) {
        return EMEMBER_PROFILE_MESSAGE;
    }
    if (isset($_POST['eMember_update_profile']) && isset($_POST['eMember_profile_update_result'])) {
        $output = $_POST['eMember_profile_update_result'];
        if (!empty($_POST['wp_emember_pwd'])) {//Password has been changed
            $output .= '<div class="emember_warning">' . EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED . '</div>';
        }
        return $output;
    }

    global $wpdb;
    $emember_config = Emember_Config::getInstance();
    $d = WP_EMEMBER_URL . '/images/default_image.gif';
    $member_id = $emember_auth->getUserInfo('member_id');
    $resultset = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . esc_sql($member_id));
    $custom_fields_resultset = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . esc_sql($member_id) . ' AND meta_key=\'custom_field\'');
    if (isset($custom_fields_resultset->meta_value)) {
        //Grab the custom fields values.
        $edit_custom_fields = unserialize($custom_fields_resultset->meta_value);
    } else {
        //Empty custom fields
        $edit_custom_fields = array();
    }

    $title = $resultset->title;
    $username = $resultset->user_name;
    $first_name = $resultset->first_name;
    $last_name = $resultset->last_name;
    $phone = $resultset->phone;
    $email = $resultset->email;
    $password = $resultset->password;
    $address_street = $resultset->address_street;
    $address_city = $resultset->address_city;
    $address_state = $resultset->address_state;
    $address_zipcode = $resultset->address_zipcode;
    $country = $resultset->country;
    $gender = $resultset->gender;
    $company = $resultset->company_name;
    $image_url = null;
    $image_path = null;
    $upload_dir = wp_upload_dir();
    $upload_url = $upload_dir['baseurl'] . '/emember/';
    $pro_pic = $emember_auth->getUserInfo('profile_image');
    $use_gravatar = $emember_config->getValue('eMember_use_gravatar');
    if ($use_gravatar) {
        $image_url = WP_EMEMBER_GRAVATAR_URL . "/" . md5(strtolower($email)) . "?d=" . urlencode($d) . "&s=" . 96;
    } else if (!empty($pro_pic)) {
        $image_url = $upload_url . $pro_pic . '?' . time();
        $pro_pic = $member_id;
    } else {
        $image_url = WP_EMEMBER_URL . '/images/default_profile_image.png';
    }

    $allow_delete = $emember_config->getValue('eMember_allow_account_removal');
    $delete_button = '';
    if (!empty($allow_delete)) {
        $delete_account_confirm_msg = 'If you proceed, your account will be deleted permanently. ' . EMEMBER_CONFIRM;
        $delete_confirm_code = 'return confirm(\'' . $delete_account_confirm_msg . '\')';
        $delete_button = '<a id="delete_account_btn" href="' . WP_EMEMBER_SITE_HOME_URL . '?event=delete_account" onclick="' . $delete_confirm_code . '">' . EMEMBER_DELETE_ACC . '</a> ';
    }

    ob_start();
    echo isset($msg) ? '<span class="emember_error">' . $msg . '</span>' : '';
    ?>
    <script type="text/javascript" src="<?php echo site_url(); ?>?emember_load_js=profile&id=wp_emember_profileUpdateForm"></script>
    <link rel='stylesheet' href='<?php echo WP_EMEMBER_URL; ?>/css/pure-min.css?ver=<?php echo WP_EMEMBER_VERSION; ?>' type='text/css' media='all' />
    <form action="" method="post" name="wp_emember_profileUpdateForm" id="wp_emember_profileUpdateForm" class="pure-form pure-form-stacked">
        <input type="hidden" name="member_id" id="member_id" value ="<?php echo $member_id; ?>" />
        <?php wp_nonce_field('emember-update-profile-nonce'); ?>
        <fieldset class="emember-centered">
            <label></label>
            <?php if ($emember_config->getValue('eMember_profile_thumbnail')): ?>
                <div class='wp-emember-profile-image'>
                    <img id="emem_profile_image" src="<?php echo $image_url; ?>"/>
                    <?php if (empty($use_gravatar)): ?>
                        <div class="wp-emember-file-uploader">
                            <div id="emember-file-uploader">
                                <noscript>
                                <p>Please enable JavaScript to use file uploader.</p>
                                <!-- or put a simple form for upload here -->
                                </noscript>
                            </div>
                            <div id="emember-profile-remove-cont" style="display:none;">
                                <button id="remove_button" class="pure-button pure-button-primary emember-remove-image-btn" data-imagepath="<?php echo $pro_pic; ?>"><?php echo EMEMBER_REMOVE; ?></button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="clear"></div>
                </div>
            <?php endif; ?>
        </fieldset>
        <fieldset>
            <input type="text" id="wp_emember_user_name" title="<?php echo EMEMBER_USERNAME ?>" value="<?php echo EMEMBER_USERNAME ?>: <?php echo $username; ?>" class="pure-input-1" readonly>
            <div class="wp_emember_pwd">
                <input type="password" id="wp_emember_pwd" name="wp_emember_pwd" size="20" title="<?php echo EMEMBER_PASSWORD ?>" placeholder="<?php echo EMEMBER_PASSWORD ?>" value="" class="validate[minSize[6]] pure-input-1" />
            </div>
            <div class="wp_emember_pwd_r">
                <input type="password" id="wp_emember_pwd_r" name="wp_emember_pwd_r" size="20" title="<?php echo EMEMBER_PASSWORD_REPEAT ?>" placeholder="<?php echo EMEMBER_PASSWORD_REPEAT ?>" value="" class="validate[equals[wp_emember_pwd]] pure-input-1" />
            </div>
        </fieldset>
        <fieldset>
            <?php if ($emember_config->getValue('eMember_edit_title')): ?>
                <div class="wp_emember_title">
                    <select name="wp_emember_title" title="<?php echo EMEMBER_TITLE; ?>" class="pure-input-1">
                        <option  <?php echo $title === 'not specified' ? 'selected=\'selected\'' : '' ?> value="not specified"><?php echo EMEMBER_TITLE . ': ' . EMEMBER_GENDER_UNSPECIFIED ?></option>
                        <option <?php echo $title === 'Mr' ? 'selected=\'selected\'' : '' ?> value="Mr"><?php echo EMEMBER_MR; ?></option>
                        <option <?php echo $title === 'Mrs' ? 'selected=\'selected\'' : '' ?> value="Mrs"><?php echo EMEMBER_MRS; ?></option>
                        <option <?php echo $title === 'Miss' ? 'selected=\'selected\'' : '' ?> value="Miss"><?php echo EMEMBER_MISS; ?></option>
                        <option <?php echo $title === 'Ms' ? 'selected=\'selected\'' : '' ?> value="Ms"><?php echo EMEMBER_MS; ?></option>
                        <option <?php echo $title === 'Dr' ? 'selected=\'selected\'' : '' ?> value="Dr"><?php echo EMEMBER_DR; ?></option>
                    </select>
                </div>
            <?php endif; ?>
            <?php
            $optionNames = array('eMember_edit_firstname', 'eMember_edit_lastname', 'eMember_edit_phone', 'eMember_edit_company', 'eMember_edit_email', 'eMember_edit_street', 'eMember_edit_city', 'eMember_edit_state', 'eMember_edit_zipcode');
            $fieldNames = array('wp_emember_firstname', 'wp_emember_lastname', 'wp_emember_phone', 'wp_emember_company_name', 'wp_emember_email', 'wp_emember_street', 'wp_emember_city', 'wp_emember_state', 'wp_emember_zipcode');
            $labelNames = array(EMEMBER_FIRST_NAME, EMEMBER_LAST_NAME, EMEMBER_PHONE, EMEMBER_COMPANY, EMEMBER_EMAIL, EMEMBER_ADDRESS_STREET, EMEMBER_ADDRESS_CITY, EMEMBER_ADDRESS_STATE, EMEMBER_ADDRESS_ZIP);
            $values = array($first_name, $last_name, $phone, $company, $email, $address_street, $address_city, $address_state, $address_zipcode);
            foreach ($optionNames as $key => $option) {
                if ($emember_config->getValue($option)) {
                    $value = $values[$key];
                    $class = $emember_config->getValue($option . '_required') ? 'validate[required] ' : "";
                    echo "<div class='{$fieldNames[$key]}'><input type='text' id='{$fieldNames[$key]}' name='{$fieldNames[$key]}' size='20' title='{$labelNames[$key]}' placeholder='{$labelNames[$key]}' value='{$value}' class='{$class}pure-input-1' /></div>";
                }
            }
            ?>
            <?php if ($emember_config->getValue('eMember_edit_country')): ?>
                <div class="wp_emember_country">
                    <select name="wp_emember_country" title="<?php echo EMEMBER_ADDRESS_COUNTRY; ?>" id="wp_emember_country" class="<?php echo $emember_config->getValue('eMember_edit_country_required') ? 'validate[required] ' : ""; ?>pure-input-1" >
                        <?php echo emember_country_list_dropdown(stripslashes($country)); ?>
                    </select>
                </div>
            <?php endif; ?>
            <?php if ($emember_config->getValue('eMember_edit_gender')): ?>
                <div class="wp_emember_gender">
                    <select name="wp_emember_gender" title="<?php echo EMEMBER_GENDER; ?>" id="wp_emember_gender" class="pure-input-1">
                        <option  <?php echo (($gender === 'not specified') ? 'selected=\'selected\'' : '' ) ?> value="not specified"><?php echo EMEMBER_GENDER . ': ' . EMEMBER_GENDER_UNSPECIFIED ?></option>
                        <option  <?php echo (($gender === 'male') ? 'selected=\'selected\'' : '' ) ?> value="male"><?php echo EMEMBER_GENDER_MALE ?></option>
                        <option  <?php echo (($gender === 'female') ? 'selected=\'selected\'' : '' ) ?> value="female"><?php echo EMEMBER_GENDER_FEMALE ?></option>
                    </select>
                </div>
                <?php
            endif;
            ?>
        </fieldset>
        <?php
        include ('custom_field_template.php');
        ?>
        <fieldset><?php echo $delete_button ?></fieldset>
        <fieldset class="pure-controls emember-centered">
            <div class="eMember_update_profile">
                <button id="eMember_update_profile" type="submit" class = "pure-button pure-button-active emember-profile-submit-button"><?php echo EMEMBER_UPDATE ?></button>
                <input class="eMember_button emember_edit_profile_submit emember-profile-submit-input" name="eMember_update_profile" type="hidden" id="eMember_update_profile_input" value="<?php echo EMEMBER_UPDATE ?>" />
            </div>
        </fieldset>
    </form><br />
    <?php
    $output = ob_get_contents();
    ob_end_clean();
    return $output;
}

function emember_delete_account_from_profile_page_init() {
    //This function is run on front-end on 'init'.

    $wpemem_evt = isset($_REQUEST['event']) ? trim($_REQUEST['event']) : "";
    switch ($wpemem_evt) {
        case 'delete_account':
            emember_delete_self_account();
            break;
        case 'delete_account_success':
            emember_post_delete_self_account_success();
            break;
    }
}

function emember_post_delete_self_account_success() {
    //Only executes when the query parameter has "delete_account_success" and the delete account feature is enabled.
    if ( isset( $_REQUEST['event']) && $_REQUEST['event'] == 'delete_account_success' ){
        //Show the account deleted success message
        $acc_deleted_success_msg = 'Success! Your account has been deleted. You can close this browser window or <a href="'. WP_EMEMBER_SITE_HOME_URL .'">click here to go the home page</a>.';
        wp_die($acc_deleted_success_msg);
    }
}

function emember_delete_self_account() {
    //Only executes when the query parameter has "delete_account" and the delete account feature is enabled.
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();

    if (!$emember_auth->isLoggedIn()) {
        return;
    }

    $allow_account_delete_feature_enabled = $emember_config->getValue('eMember_allow_account_removal');
    if ($allow_account_delete_feature_enabled) {
        //The feature is enabled, go forward.
        $f = $emember_config->getValue('eMember_allow_wp_account_removal');
        if ($f) {
            $wp_user_id = username_exists($emember_auth->getUserInfo('user_name'));
            $ud = get_userdata($wp_user_id);
            if (isset($ud->wp_capabilities['administrator']) || $ud->wp_user_level == 10) {
                if ($_GET['confirm'] != 2) {
                    $u = get_bloginfo('wpurl');
                    $_GET['confirm'] = 2;
                    $u .= '?' . http_build_query($_GET);
                    $warning = "<html><body><div id='message' style=\"color:red;\" ><p>You are about to delete an account that has admin privilege.
                  If you are using WordPress user integration then this will delete the corresponding user
                  account from WordPress and you may not be able to log in as admin with this account.
                  Continue? <a href='" . $u . "'>yes</a>/<a href='javascript:void(0);' onclick='top.document.location=\"" . get_bloginfo('wpurl') . "\";' >no</a></p></div></body></html>";
                    echo $warning;
                    exit;
                }
            }
            wp_clear_auth_cookie();
            if ($wp_user_id) {
                include_once(ABSPATH . 'wp-admin/includes/user.php');
                wp_delete_user($wp_user_id, 1); //assigns all related to this user to admin.
            }
        }
        $ret = dbAccess::delete(WP_EMEMBER_MEMBERS_TABLE_NAME, 'member_id=' . $emember_auth->getUserInfo('member_id'));
        $ret = dbAccess::delete(WP_EMEMBER_MEMBERS_META_TABLE, 'user_id=' . $emember_auth->getUserInfo('member_id'));
        $emember_auth->silent_logout();
        //Send the user to a post account delete success page and exit out.
        $post_delete_redirect_url = WP_EMEMBER_SITE_HOME_URL . '?event=delete_account_success';
        wp_emember_redirect_to_url($post_delete_redirect_url);
        exit;
    }
}

function emember_update_profile_init() {
    if (isset($_POST['eMember_update_profile'])) {
        $nonce = $_REQUEST['_wpnonce'];
        if (!wp_verify_nonce($nonce, 'emember-update-profile-nonce')) {
            eMember_log_debug("Profile update nonce check failed ", true);
            die("Security check failed on profile update");
        }
        global $wpdb;
        $emember_config = Emember_Config::getInstance();
        include_once(ABSPATH . WPINC . '/class-phpass.php');

        $_POST['member_id'] = strip_tags($_POST['member_id']);
        $resultset = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . esc_sql($_POST['member_id']));
        $wp_user_id = username_exists($resultset->user_name);

        $username = $resultset->user_name;
        $member_id = sanitize_text_field($_POST['member_id']);
        $email_before_edit = $resultset->email;

        $updatable = true;
        if (isset($_POST['wp_emember_email'])) {
            $emmber_email_owner = emember_email_exists($_POST['wp_emember_email']);
            $wp_email_owner = email_exists($_POST['wp_emember_email']);
            if (!is_email($_POST['wp_emember_email'])) {
                $_POST['eMember_profile_update_result'] = EMEMBER_EMAIL_INVALID;
                $updatable = false;
            } else if (($wp_email_owner && ($wp_email_owner != $wp_user_id)) || ($emmber_email_owner && ($emmber_email_owner != $_POST['member_id']))) {
                $_POST['eMember_profile_update_result'] = '<span class="emember_error">' . EMEMBER_EMAIL_UNAVAIL . ' </span>';
                $updatable = false;
            }
        }
        if (($_POST['wp_emember_pwd'] != $_POST['wp_emember_pwd_r'])) {
            $_POST['eMember_profile_update_result'] = '<span class="emember_error">' . EMEMBER_PASSWORD_MISMATCH . '</span>';
            $updatable = false;
        }

        if ($updatable) {
            $wp_hasher = new PasswordHash(8, TRUE);
            $fields = array();
            if (isset($_POST['wp_emember_title']))
                $fields['title'] = strip_tags($_POST['wp_emember_title']);
            if (isset($_POST['wp_emember_firstname']))
                $fields['first_name'] = strip_tags($_POST['wp_emember_firstname']);
            if (isset($_POST['wp_emember_lastname']))
                $fields['last_name'] = strip_tags($_POST['wp_emember_lastname']);
            if (isset($_POST['wp_emember_email']))
                $fields['email'] = strip_tags($_POST['wp_emember_email']);
            if (isset($_POST['wp_emember_phone']))
                $fields['phone'] = strip_tags($_POST['wp_emember_phone']);
            if (isset($_POST['wp_emember_street']))
                $fields['address_street'] = strip_tags($_POST['wp_emember_street']);
            if (isset($_POST['wp_emember_city']))
                $fields['address_city'] = strip_tags($_POST['wp_emember_city']);
            if (isset($_POST['wp_emember_state']))
                $fields['address_state'] = strip_tags($_POST['wp_emember_state']);
            if (isset($_POST['wp_emember_zipcode']))
                $fields['address_zipcode'] = strip_tags($_POST['wp_emember_zipcode']);
            if (isset($_POST['wp_emember_country']))
                $fields['country'] = strip_tags($_POST['wp_emember_country']);
            if (isset($_POST['wp_emember_gender']))
                $fields['gender'] = strip_tags($_POST['wp_emember_gender']);
            if (isset($_POST['wp_emember_company_name']))
                $fields['company_name'] = strip_tags($_POST['wp_emember_company_name']);
            if (!empty($_POST['wp_emember_pwd'])) {
                $password = $wp_hasher->HashPassword($_POST['wp_emember_pwd']);
                $fields['password'] = $password;
            }

	    //Trigger the before profile update hook
	    do_action('eMember_before_profile_update_query', $member_id, $fields);

            if ($wp_user_id) {
                $wp_user_info = array();
                $wp_user_info['first_name'] = strip_tags(isset($_POST['wp_emember_firstname']) ? $_POST['wp_emember_firstname'] : "");
                $wp_user_info['last_name'] = strip_tags(isset($_POST['wp_emember_lastname']) ? $_POST['wp_emember_lastname'] : "");
                $wp_user_info['user_email'] = strip_tags(isset($_POST['wp_emember_email']) ? $_POST['wp_emember_email'] : "");
                $wp_user_info['ID'] = $wp_user_id;

                if (!empty($_POST['wp_emember_pwd'])){
                    $wp_user_info['user_pass'] = $_POST['wp_emember_pwd'];
		}
                wp_update_user($wp_user_info);
            }

            if (count($fields) > 0) {
                $ret = dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id =' . esc_sql($_POST['member_id']), $fields);
            }

            $custom_fields = array();
            if (isset($_POST['emember_custom'])) {
                $custom_fields = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . esc_sql($_POST['member_id']) . ' AND meta_key=\'custom_field\'');
                if ($custom_fields) {
                    $ret = $wpdb->query('UPDATE ' . WP_EMEMBER_MEMBERS_META_TABLE .
                            ' SET meta_value =' . '\'' . addslashes(serialize($_POST['emember_custom'])) . '\' WHERE meta_key = \'custom_field\' AND  user_id=' . $_POST['member_id']);
                } else {
                    $ret = $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE .
                            '( user_id, meta_key, meta_value ) VALUES(' . $_POST['member_id'] . ',"custom_field",' . '\'' . addslashes(serialize($_POST['emember_custom'])) . '\')');
                }
            } else {
                $ret = $wpdb->query('DELETE FROM ' . WP_EMEMBER_MEMBERS_META_TABLE . '  WHERE meta_key = \'custom_field\' AND  user_id=' . esc_sql($_POST['member_id']));
            }

            if ($ret === false) {
                $_POST['eMember_profile_update_result'] = 'Failed';
            } else {
                $edit_profile_page = $emember_config->getValue('eMember_profile_edit_page');
                $profile_updated_msg = '<div class="emember_profile_updated_msg">';
                $profile_updated_msg .= EMEMBER_PROFILE_UPDATED;
                if (!empty($edit_profile_page)) {
                    $profile_updated_msg .= ' <a href="' . $edit_profile_page . '">' . EMEMBER_EDIT_YOUR_PROFILE_AGAIN . '</a>';
                }
                $profile_updated_msg .= '</div>';

                $_POST['eMember_profile_update_result'] = $profile_updated_msg;

                $fields['member_id'] = $member_id;
                $fields['username'] = $username;
                $fields['email_before_edit'] = $email_before_edit;
                do_action('eMember_profile_updated', $fields, $custom_fields);
                //Update the affiliate end if using the auto affiliate feature
                eMember_handle_affiliate_profile_update();
            }
        }
    }
}
