<?php

function emember_bootstrap() {
    //This function is Hooked to "plugins_loaded" which runs before "init".

    $language_override = apply_filters('emember_language_loading_override', '');
    if (!empty($language_override)) {
        eMember_log_debug('Notice - another plugin or addon has overriden the emember language loading.', true);
        return;
    }

    $emember_config = Emember_Config::getInstance();
    $lang = $emember_config->getValue('eMember_language');
    if (!empty($lang)) {
        $eMember_language_file = WP_EMEMBER_PATH . "lang/" . $lang . ".php";
    } else {
        $eMember_language_file = WP_EMEMBER_PATH . "lang/eng.php";
    }
    $eMember_language_file = apply_filters('emember_get_language_path', $eMember_language_file, $lang);
    include_once($eMember_language_file);
}

function emember_initialize() {    
    //Both front end and admin side init time tasks
    load_library();

    //Create the Custom Post Types used in the plugin.
    emember_create_custom_post_types();

    //Front end only init time tasks
    if (!is_admin()) {
        if (isset($_REQUEST['emember_feed_key'])) {
            $emember_auth = Emember_Auth::getInstance();
            $emember_auth->login_with_feed_key($_REQUEST['emember_feed_key']);
        }
        emember_init_frontend();
        emember_delete_account_from_profile_page_init();
        $emember_allow_comment = Emember_Config::getInstance()->getValue('eMember_member_can_comment_only');
        if ($emember_allow_comment) {
            emember_check_comment();
        }
        emember_del_bookmark();
        emember_do_caching_plugin_compatibility();

        do_action('emember_frontend_init');
    }

    //Admin side only init time tasks
    if (is_admin()) {
        emember_init_admin_side();
    }
}

function emember_init_frontend() {
    emember_dynamic_js_load();
    emember_process_reg_form();
    emember_process_free_rego_with_confirm_form();

    //Check and process login form submission
    if (isset($_REQUEST['doLogin'])) {
        //Check if core plugin's reCAPTCHA feature for login is enabled.
        $emember_config = Emember_Config::getInstance();
        $enable_captcha_login_form = $emember_config->getValue('emember_enable_recaptcha_login_form');
        if( $enable_captcha_login_form ){
            //Login form recaptcha is enabled
            $captcha_result = emember_recaptcha_verify();
            if ( !$captcha_result->valid ) {
                //Captcha failed.
                wp_die('Captcha verification failed. Go back and try again.', '', array('back_link' => true));
            }
        }

        //Apply filter for the Captcha Addon
        $valid_captcha = apply_filters('emember_captcha_varify_login', true);
        if (!$valid_captcha) {
            wp_die('Security check - Captcha verification failed. Please try again.', '', array('back_link' => true));
        }
        //Keeping the nonce verification on login form OFF for now. This is to help with caching plugin compatibility
        //$nonce = $_REQUEST['_wpnonce'];
        //if (!wp_verify_nonce($nonce, 'emember-login-nonce')) {
        //    eMember_log_debug("Login nonce check failed ", true);
        //    die("Security check failed on login");
        //}
        if (isset($_REQUEST['emember_u_name']) && isset($_REQUEST['emember_pwd'])) {
            $_POST['login_user_name'] = sanitize_text_field($_REQUEST['emember_u_name']);
            $_POST['login_pwd'] = sanitize_text_field($_REQUEST['emember_pwd']);
   }
        emember_login_init();
    } else {
        emember_logout_init();
    }
    emember_update_profile_init();
    emember_general_init_code();
}

function emember_init_admin_side() {
    $page = filter_input(INPUT_GET, 'page');
    $action = filter_input(INPUT_GET, 'members_action');
    if ($page == 'wp_eMember_manage' && empty($action)) {
        if (!empty($_REQUEST['_wp_http_referer'])) {
            wp_redirect(remove_query_arg(array('_wp_http_referer', '_wpnonce'), wp_unslash(esc_url_raw($_SERVER['REQUEST_URI']))));
            exit;
        }
    }
}

function emember_login_init($redirect = true) {
    do_action('eMember_user_login_init');
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();
    $user = isset($_POST['login_user_name']) ? sanitize_text_field($_POST['login_user_name']) : '';
    $clientip = get_real_ip_addr();

    if ($emember_config->getValue('eMember_multiple_logins') == '1') {
        unset($_POST['rememberme']);
    }

    eMember_log_debug("Authenticating login request for username: " . $user . ". Request came from IP Address: " . $clientip, true);
    if (empty($user)) {
        eMember_log_debug("Username value is missing. Cannot process this request.", false);
        return;
    } else {
        //Uncomment the following line if we want to see all the request parameter details for the login request submission.
        //eMember_log_debug_array($_REQUEST);
    }

    if ($emember_auth->isLoggedIn()) {
	eMember_log_debug("Authentication completed for username: " . $user . ". IP Address: " . $clientip, true);
        $_SESSION['membership_level_name'] = $emember_auth->permitted->primary_level->get('alias');

	$proceed_after_auth=apply_filters('eMember_login_auth_completed_filter', true);

	if (!$proceed_after_auth) {
	   $emember_auth->silent_logout(true);
	   return;
	}

        do_action('eMember_login_authentication_completed');

        //The following redirect only takes place after a member has logged into the site
        if (isset($_REQUEST['no-redirect']) && $_REQUEST['no-redirect'] == '1') {
            //No redirect argument is set in this request. Do not do any after login redirect
        } else if (isset($_REQUEST['redirect_to']) && !empty($_REQUEST['redirect_to'])) {
            //The url has a "redirect_to" query parameter. Redirect the member to this URL (as it takes priority over other after login redirection).
            $redirect_to = esc_url($_REQUEST['redirect_to']);
            wp_emember_redirect_to_url($redirect_to);
        } else {
            //Do after login redirection according to the settings
            $enable_after_login_redirect = $emember_config->getValue('eMember_enable_redirection');
            if ($redirect && $enable_after_login_redirect) {
                eMember_log_debug("Redirecting member to the after login redirection page.", true);
                $separate_home_page = emember_get_after_login_page_url_of_current_user();
                if (!empty($separate_home_page)) {
                    wp_emember_redirect_to_url($separate_home_page);
                    exit;
                }
            }
        }
    }
}

function emember_logout_init() {
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();
    if (!$emember_auth->isLoggedIn())
        return;
    $sign_in_wp = $emember_config->getValue('eMember_signin_wp_user');
    if ($sign_in_wp && !is_user_logged_in()) {//If Not logged into WP while emember is logged in
        if (username_exists($emember_auth->getUserInfo('user_name'))) {
            eMember_log_debug("User Exists in WP but not logged in. ", true);
            $emember_auth->silent_logout();
            eMember_log_debug("Logging out of emember because wp cookie for this user expired ", true);
        } else {
            eMember_log_debug("You have auto login to WP enabled but WP User doesn't exist for this user! WP User login won't execute.", true);
        }
    }
}

function emember_general_init_code() {
    if (isset($_REQUEST['emember_paypal_ipn'])) {
        //Handle the hosted paypal button IPN
        include_once('ipn/eMember_handle_paypal_ipn.php');
        exit;
    }

    if (isset($_REQUEST['emember_process_paypal_ipn'])) {
        //Handle the IPN for buttons created inside the plugin
        include_once('ipn/emember_paypal_ipn_plugin_buttons.php');
        exit;
    }

    if (isset($_REQUEST['emember_process_braintree_buy_now'])) {
        //Handle the IPN for buttons created inside the plugin
        include_once('ipn/emember_braintree_buy_now_ipn.php');
        exit;
    }

    if (isset($_REQUEST['emember_cb_ipn'])) {
        include_once('ipn/eMember_handle_clickbank_ipn.php');
        exit;
    }

    if (isset($_REQUEST['emember_jvzoo_ipn'])) {
        include_once('ipn/emember_handle_jvzoo_ipn.php');
        exit;
    }

    if (isset($_REQUEST['emember_aweber_success'])) {
        include_once('api/aweber-success.php');
        exit;
    }
}

function emember_do_caching_plugin_compatibility() {
    if (wp_emember_is_member_logged_in()) {//Do not cache page for logged in members
	//Cache plugin compatibility
	if(!defined('DONOTCACHEPAGE')){define('DONOTCACHEPAGE', TRUE);}
    }
}

function emember_create_custom_post_types() {
    //The payment button data for membership levels will be stored using this CPT
    register_post_type('emem_payment_button', array(
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => false,
        'query_var' => false,
        'rewrite' => false,
        'capability_type' => 'page',
        'has_archive' => false,
        'hierarchical' => false,
        'supports' => array('title', 'editor')
    ));

    //The transactions data for membership payments will be stored using this CPT
    register_post_type('emem_transactions', array(
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => false,
        'query_var' => false,
        'rewrite' => false,
        'capability_type' => 'page',
        'has_archive' => false,
        'hierarchical' => false,
        'supports' => array('title', 'editor')
    ));
}
