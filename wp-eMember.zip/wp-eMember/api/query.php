<?php

//This API is used to query a member record using the member's ID or email address
//Mandatory data - Secret key, (member ID or email address)

if (!isset($_REQUEST['secret_key'])) {
    exit;
}
include_once('../../../../wp-load.php');
include_once('../eMember_debug_handler.php');
include_once(ABSPATH . WPINC . '/class-phpass.php');

global $wpdb;
$emember_config = Emember_Config::getInstance();
$eMember_allow_remote_post = $emember_config->getValue('wp_eMember_enable_remote_post');
if (!$eMember_allow_remote_post) {
    echo "Remote POST is disabled";
    eMember_log_debug('Remote POST is disabled in the settings.', false);
    exit;
}

eMember_log_debug('Start Processing of member query request via API...', true);

$secret_key_received = $_REQUEST['secret_key'];
$right_secret_key = $emember_config->getValue('wp_eMember_secret_word_for_post');
if ($secret_key_received != $right_secret_key) {
    echo "Error!\n";
    echo "Secret key is invalid\n";
    eMember_log_debug('secret key invalid...', false);
    exit;
}

//Check to make sure the mandatory query parameters are present
$member_id = isset($_REQUEST['member_id'])? strip_tags($_REQUEST['member_id']) : '';
$email = isset($_REQUEST['email'])? strip_tags($_REQUEST['email']) : '';

if (empty($member_id) && empty($email)) {
    echo "Error!\n";
    echo "Missing mandatory field. Member ID or Email addresss value must be present!\n";
    eMember_log_debug('Missing mandatory field. Member ID or Email addresss value must be present.', false);
    exit;
}

//Query the member info
if(!empty($member_id)){//Query using member ID
    $resultset_ary = $wpdb->get_row("SELECT * FROM " . WP_EMEMBER_MEMBERS_TABLE_NAME . " where member_id='$member_id'", ARRAY_A);
} else if(!empty($email)){
    $resultset_ary = $wpdb->get_row("SELECT * FROM " . WP_EMEMBER_MEMBERS_TABLE_NAME . " where email='$email'", ARRAY_A);
} else{
    eMember_log_debug('Error! Missing mandatory field. Member ID or Email addresss value must be present in the query.', false);
    exit;    
}

//$custom_fields_resultset_ary = $wpdb->get_row("SELECT * FROM " . WP_EMEMBER_MEMBERS_META_TABLE . " where user_id='$member_id' AND meta_key='custom_field'", ARRAY_A);
//print_r($custom_fields_resultset_ary);

$args = (array(
    'result' => 'success', 
    'message' => 'Member details retrieved successfully.', 
    'member_id' => $resultset_ary['member_id'],
    'member_data' => $resultset_ary,
));

//Send response
echo json_encode($args);
exit(0);
