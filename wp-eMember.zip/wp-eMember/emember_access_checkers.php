<?php

function secure_content($content) {
    global $post;

    //Trigger filter to override this.
    $overridden = apply_filters('emember_override_before_filtering_the_content', false, $content);
    if ( $overridden ){
        eMember_log_debug("emember_override_before_filtering_the_content filter has overridden the standard filtering", true);
        return $content;
    }
    
    //Handle the inline login widget
    if (isset($_GET['event']) && ($_GET['event'] == 'login')) {
        //We may need to show the inline login widget. Lets check the settings.
        $is_logged_in = wp_emember_is_member_logged_in();
        $emember_config = Emember_Config::getInstance();
        $disable_inline_login = $emember_config->getValue('eMember_disable_inline_login');
        if(!$is_logged_in && !$disable_inline_login){//This is not a logged-in member. Also, the inline widget option is being used.
            if (is_singular()){//This is a single post/page/attachement/cpt view
                //Show the login widget instead of the post content.
                return eMember_login_widget();
            }
        }
    }

    if(emember_expired_user_has_access_to_this_page()) {
        //This is an expired user. And it is a system page. So allow access.
        return $content;
    }

    //Get the custom post types
    $args = array('public' => true, '_builtin' => false);
    $post_types = get_post_types($args);

    //Check and apply content protection
    if (is_category()){
        return auth_check_category($content);
    }

    if ( isset( $post->post_type ) ){
        if ($post->post_type === 'page'){
            return auth_check_page($content);
        }
        if ($post->post_type === 'post'){
            return auth_check_post($content);
        }
        if (in_array($post->post_type, $post_types)){
            return auth_check_custom_post($content);
        }
    }

    return $content;
}

function eMember_my_more_link($more_link, $more_link_text = "More") {
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();
    global $post;
    $id = isset($post->ID)? $post->ID : '';
    if (empty($id)){
        return $more_link;
    }

    $emember_auth->hasmore[$id] = $id;//This will set the hasmore variable which the plugin will check later in the check_post_content() function and apply more tag protection (if applicable).
    if ($emember_auth->is_protected_category($id) || $emember_auth->is_protected_parent_category($id)) {
        if ($emember_auth->isLoggedIn()) {
            $expires = $emember_auth->getUserInfo('account_state');

            if (!emember_check_all_subscriptions_expired()) {
                if (emember_if_post_older_than_member($post->post_date)) {
                    return wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                }
                if ($emember_auth->is_permitted_category($id))
                    return str_replace($more_link_text, EMEMBER_MORE_LINK . ' ', $more_link);
                else {
                    return wp_emember_format_message(EMEMBER_CONTENT_RESTRICTED);
                }
            } else
                return str_replace($more_link_text, EMEMBER_MORE_LINK . ' ', get_renewal_link());
        }
        else {
            $join_url = $emember_config->getValue('eMember_payments_page');
            if (empty($join_url)) {
                //return '<b>Membership Payment/Join Page</b> is not defined in the settings page.Please Contact <a href="mailto:'.get_option('admin_email').'">Admin</a>.';
                $msg = '<b>Membership Payment/Join Page</b> is not defined in the settings page.Please Contact <a href="mailto:' . get_option('admin_email') . '">Admin</a>.';
                return wp_emember_format_message($msg);
            } else
                $join_url = ' href ="' . $join_url . '" ';
            return str_replace($more_link_text, EMEMBER_MORE_LINK . ' ', '<a ' . $join_url . '>' . EMEMBER_MORE_LINK . ' ' . '</a>');
        }
    } else if ($emember_auth->is_protected_post($id)) {
        if ($emember_auth->isLoggedIn()) {
            $expires = $emember_auth->getUserInfo('account_state');

            if (!emember_check_all_subscriptions_expired()) {
                if (emember_if_post_older_than_member($post->post_date)) {
                    return wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                }
                if ($emember_auth->is_permitted_post($id))
                    return str_replace($more_link_text, EMEMBER_MORE_LINK . ' ', $more_link);
                else {
                    return wp_emember_format_message(EMEMBER_LEVEL_NOT_ALLOWED);
                }
            } else
                return str_replace($more_link_text, EMEMBER_MORE_LINK . ' ', get_renewal_link());
        }
        else {
            $join_url = $emember_config->getValue('eMember_payments_page');
            if (empty($join_url)){
                return '<b>Membership Payment/Join Page</b> is not defined in the settings page.Please Contact <a href="mailto:' . get_option('admin_email') . '">Admin</a>.';
	    } else {
                $join_url = ' href ="' . $join_url . '" ';
	    }
            return str_replace($more_link_text, EMEMBER_MORE_LINK . ' ', '<a ' . $join_url . '>' . EMEMBER_MORE_LINK . ' ' . '</a>');
        }
    } else {
        return str_replace($more_link_text, EMEMBER_MORE_LINK . ' ', $more_link);
    }
}

function auth_check_category($content) {
    global $post;
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();
    $id = isset($post->ID)? $post->ID : '';
    if (empty($id)){
        return $content;
    }
    if (isset($emember_auth->hasmore[$id])) {
        unset($emember_auth->hasmore[$id]);
        return $content;
    } else {
        if ($emember_auth->is_protected_category($id) || $emember_auth->is_protected_parent_category($id)) {
            if ($emember_auth->isLoggedIn()) {
                $expires = $emember_auth->getUserInfo('account_state');

                if (!emember_check_all_subscriptions_expired()) {
                    if (emember_if_post_older_than_member($post->post_date)) {
                        return wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                    }
                    if ($emember_auth->is_permitted_category($id)) {
                        return $content;
                    } else {
                        return wp_emember_format_message(EMEMBER_LEVEL_NOT_ALLOWED);
                    }
                } else{
                    return EMEMBER_CONTENT_RESTRICTED;
                }
            }
            else {
                return get_login_link();
            }
        } else {
            if ($emember_auth->is_protected_post($id)) {
                if ($emember_auth->isLoggedIn()) {
                    $expires = $emember_auth->getUserInfo('account_state');

                    if (!emember_check_all_subscriptions_expired()) {
                        if (emember_if_post_older_than_member($post->post_date)) {
                            return wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                        }
                        if ($emember_auth->is_permitted_post($id))
                            return $content;
                        else {
                            return wp_emember_format_message(EMEMBER_CONTENT_RESTRICTED);
                        }
                    } else{
                        return EMEMBER_CONTENT_RESTRICTED;
                    }
                } else {
                    return get_login_link();
                }

            }
            return $content;
        }
    }
}

function auth_check_attachment($content) {
    global $post;
    $id = isset($post->ID)? $post->ID : '';
    if (empty($id)){
        return $content;
    }
    $default_image = WP_EMEMBER_URL . '/images/emember-restrict.png';
    $emember_config = Emember_Config::getInstance();
    $emember_auth = Emember_Auth::getInstance();

    if ($emember_auth->is_protected_attachment($id)) {
        if ($emember_auth->isLoggedIn()) {
            $expires = $emember_auth->getUserInfo('account_state');

            if (!emember_check_all_subscriptions_expired()) {
                if ($emember_auth->is_permitted_attachment($id)) {
                    if (emember_if_post_older_than_member($post->post_date)) {
                        return $default_image;
                    }
                    $emember_auth->is_post_visible = true;
                    return $content;
                } else {
                    //return '<br/><b>' . EMEMBER_CONTENT_RESTRICTED .'</b>';
                    return $default_image;
                }
            } else
                return $default_image;
        }
        else {
            return $default_image;
        }
    } else {
        if (isset($emember_auth->hasmore[$id]) && is_attachment($emember_auth->hasmore[$id])) {
            unset($emember_auth->hasmore);
        }
        $emember_auth->is_post_visible = true;
        return $content;
    }
    //}
}

function auth_check_custom_post($content) {
    global $post;
    $before_more = "";
    $emember_auth = Emember_Auth::getInstance();
    $id = isset($post->ID)? $post->ID : '';
    if (empty($id)){
        return $content;
    }
    if ($emember_auth->is_protected_category($id) || $emember_auth->is_protected_parent_category($id)) {
        if ($emember_auth->isLoggedIn()) {
            $expires = $emember_auth->getUserInfo('account_state');

            if (!emember_check_all_subscriptions_expired()) {
                if ($emember_auth->is_permitted_category($id)) {
                    if (emember_if_post_older_than_member($post->post_date)) {
                        return $before_more . wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                    }
                    $emember_auth->is_post_visible = true;
                    return $content;
                } else {
                    return $before_more . wp_emember_format_message(EMEMBER_LEVEL_NOT_ALLOWED);
                }
            } else {
                return $before_more . get_renewal_link();
            }
        }
        else {
            return $before_more . get_login_link();
        }
    }
    else {
        if ($emember_auth->is_protected_custom_post($id)) {
            if ($emember_auth->isLoggedIn()) {
                $expires = $emember_auth->getUserInfo('account_state');

                if (!emember_check_all_subscriptions_expired()) {
                    if ($emember_auth->is_permitted_custom_post($id)) {
                        if (emember_if_post_older_than_member($post->post_date)) {
                            return $before_more . wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                        }
                        $emember_auth->is_post_visible = true;
                        return $content;
                    } else {
                        return $before_more . wp_emember_format_message(EMEMBER_CONTENT_RESTRICTED);
                    }
                } else {
                    return $before_more . get_renewal_link();
                }
            }
            else {
                if (isset($emember_auth->hasmore[$id])) {
                    unset($emember_auth->hasmore);
                    return $content;
                }
                return $before_more . get_login_link();
            }
        } else {
            if (isset($emember_auth->hasmore[$id])) {
                unset($emember_auth->hasmore);
            }
            $emember_auth->is_post_visible = true;
            return $content;
        }
    }
}

function auth_check_post($content) {
    global $post;
    $id = isset($post->ID)? $post->ID : '';
    if (empty($id)){
        return $content;
    }
    $id = apply_filters('emember_auth_check_post_id', $id);
    return check_post_content($id, $content);
}

function auth_check_page($content) {
    global $post;
    $id = isset($post->ID)? $post->ID : '';
    if (empty($id))
        return $content;
    return check_page_content($id, $content);
}

function check_page_content($id, $content) {
    $emember_auth = Emember_Auth::getInstance();
    if ($emember_auth->is_my_page_post($id)){
        return $content;
    }
    global $post;
    global $more;
    $before_more = '';
    if (isset($emember_auth->hasmore[$id])) {
        $before_more = explode('<span id="more-' . $id . '"></span>', $content);
        if (count($before_more) == 1)
            $before_more = '';
        else
            $before_more = $before_more[0] . '<br/>';
    }
    if ($emember_auth->is_protected_category($id) || $emember_auth->is_protected_parent_category($id)) {
        if ($emember_auth->isLoggedIn()) {
            $expires = $emember_auth->getUserInfo('account_state');

            if (!emember_check_all_subscriptions_expired()) {
                if ($emember_auth->is_permitted_category($id)) {
                    if (emember_if_post_older_than_member($post->post_date)) {
                        return $before_more . wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                    }
                    $emember_auth->is_post_visible = true;
                    return $content;
                } else {
                    return $before_more . wp_emember_format_message(EMEMBER_LEVEL_NOT_ALLOWED);
                }
            } else {
                return $before_more . get_renewal_link();
            }
        }
        else {
            return $before_more . get_login_link();
        }
    }
    else {
        if ($emember_auth->is_protected_page($id)) {
            if ($emember_auth->isLoggedIn()) {
                $expires = $emember_auth->getUserInfo('account_state');
                /* if ($expires == 'expired')
                  return $before_more . get_renewal_link(); */
                if (!emember_check_all_subscriptions_expired()) {
                    if ($emember_auth->is_permitted_page($id)) {
                        if (emember_if_post_older_than_member($post->post_date)) {
                            return $before_more . wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                        }
                        $emember_auth->is_post_visible = true;
                        return $content;
                    } else {
                        //return '<br/><b>' . EMEMBER_CONTENT_RESTRICTED .'</b>';
                        return $before_more . wp_emember_format_message(EMEMBER_CONTENT_RESTRICTED);
                    }
                } else
                    return $before_more . get_renewal_link();
            }
            else {
                if (isset($emember_auth->hasmore[$id])) {
                        unset($emember_auth->hasmore);
                        return $content;
                    }
                    return $before_more . get_login_link();
                }
        } else {
            if (isset($emember_auth->hasmore[$id])) {
                unset($emember_auth->hasmore);
            }
            $emember_auth->is_post_visible = true;
            return $content;
        }
    }
}

function auth_check_comment($content) {
    global $comment;
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();
    if ($emember_config->getValue('eMember_protect_comments_separately')) {
        $id = $comment->comment_ID;
        if ($emember_auth->is_protected_comment($id)) {
            if ($emember_auth->isLoggedIn()) {
                $expires = $emember_auth->getUserInfo('account_state');
                /* if ($expires == 'expired')
                  return get_renewal_link(); */

                if (!emember_check_all_subscriptions_expired()) {
                    if (emember_if_post_older_than_member($post->post_date)) {
                        return $before_more . wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                    }
                    if ($emember_auth->is_permitted_comment($id))
                        return $content;
                    else {
                        //return '<br/><b>' . EMEMBER_CONTENT_RESTRICTED .'</b>';
                        return wp_emember_format_message(EMEMBER_CONTENT_RESTRICTED);
                    }
                } else
                    return get_renewal_link();
            }
            else {
                if (isset($emember_auth->hasmore[$id])) {
                    unset($emember_auth->hasmore[$id]);
                    return $content;
                }
                return get_login_link();
            }
        } else {
            if (isset($emember_auth->hasmore[$id])) {
                unset($emember_auth->hasmore[$id]);
            }
            return $content;
        }
    }  //
    else {
        $post = get_post($comment->comment_post_ID);
        if ($post->post_type == 'page')
            return check_page_content($comment->comment_post_ID, $content);
        else
            return check_post_content($comment->comment_post_ID, $content);
    }
}

function check_post_content($id, $content) {
    global $post;
    $emember_auth = Emember_Auth::getInstance();
    if ($emember_auth->is_my_page_post($id)){
        return $content;
    }

    if (isset($emember_auth->hasmore[$id])) {
        //The plugin has already set the hasmore variable with the this post's ID via the "the_content_more_link" filter.
        //So now we can just go ahead and show the $content which will show the content upto the more tag. And the more link will be linked to the payment page.
        //This code is usually executed on the blog posts listing page.
        unset($emember_auth->hasmore[$id]);
        $emember_auth->is_post_visible = true;
        return $content;
    } else {
        //This code will be executed on the individual post (single_post) page.
        global $more;
        $before_more = '';
        $emember_config = Emember_Config::getInstance();
        $enable_more_tag = $emember_config->getValue('eMember_enable_more_tag');
        if ($more && $enable_more_tag) {
            $before_more = explode('<span id="more-' . $id . '"></span>', $content);
            if (count($before_more) == 1){
                $before_more = '';
            }
            else{
                $before_more = '<div class="eMember_single_post_before_more_tag_teaser">'.$before_more[0] . '</div>';
            }
        }
        if ($emember_auth->is_protected_category($id) || $emember_auth->is_protected_parent_category($id)) {
            if ($emember_auth->isLoggedIn()) {
                $expires = $emember_auth->getUserInfo('account_state');

                if (!emember_check_all_subscriptions_expired()) {
                    if ($emember_auth->is_permitted_category($id)) {
                        if (emember_if_post_older_than_member($post->post_date)) {
                            return $before_more . wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                        }
                        $emember_auth->is_post_visible = true;
                        return $content;
                    } else {
                        return $before_more . wp_emember_format_message(EMEMBER_LEVEL_NOT_ALLOWED);
                    }
                } else {
                    return $before_more . get_renewal_link();
                }
            }
            else {
                return $before_more . get_login_link();
            }
        }
        else if ($emember_auth->is_protected_post($id)) {
            if ($emember_auth->isLoggedIn()) {
                $expires = $emember_auth->getUserInfo('account_state');

                if (!emember_check_all_subscriptions_expired()) {
                    if ($emember_auth->is_permitted_post($id)) {
                        if (emember_if_post_older_than_member($post->post_date)) {
                            return $before_more . wp_emember_format_message(EMEMBER_OLD_POST_PROTECTED_MSG);
                        }
                        $emember_auth->is_post_visible = true;
                        return $content;
                    } else {
                        return $before_more . wp_emember_format_message(EMEMBER_CONTENT_RESTRICTED);
                    }
                } else
                    return $before_more . get_renewal_link();
            }
            else {
                return $before_more . get_login_link();
            }
        }
        else {
            $emember_auth->is_post_visible = true;
            return $content;
        }
    }
}

function emember_check_all_subscriptions_expired() {
    $emember_auth = Emember_Auth::getInstance();
    // check if primary level  is expired.
    if (!$emember_auth->is_subscription_expired()) {
        return false;
    }

    // At this point primary level is expired. So if secondary level feature is disabled, then return true to indicate ALL is expired.
    $seconary_level_enabled = Emember_Config::getInstance()->getValue('eMember_enable_secondary_membership');
    if (empty($seconary_level_enabled)) {
        //Secondary level feature is disabled.
        return true;
    }

    return $emember_auth->is_secondary_level_expired();
}

/******************* emember_protected shortcode start **************** */
function emember_protected_handler($attrs, $contents, $codes = '') {
    global $post;
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();
    $emember_auth->hasmore[$post->ID] = $post->ID;

    $contents = do_shortcode($contents);
    if (emember_is_first_click()){
        return '<div class="paywall">' . $contents . '</div>'; //google first click free enabled.
    }

    $do_not_show_restricted_msg = isset($attrs['do_not_show_restricted_msg']) ? $attrs['do_not_show_restricted_msg'] : "";
    $do_not_show_expired_msg = isset($attrs['do_not_show_expired_msg']) ? $attrs['do_not_show_expired_msg'] : "";

    if (!$emember_auth->isLoggedIn()) {
        // Show the content to anyone who is not logged in
        if (isset($attrs['scope']) && ($attrs['scope'] == "not_logged_in_users_only")){
            return $contents;
        }
    }

    if ($emember_auth->isLoggedIn()) {
        $acc_status = $emember_auth->getUserInfo('account_state');

        // Do not show the content to anyone who is logged in
        if (isset($attrs['scope']) && ($attrs['scope'] == "not_logged_in_users_only")){
            return "";
        }

        // Show content to anyone who is logged in
        if (isset($attrs['scope']) && ($attrs['scope'] == "verified_users_only")){
            return $contents;
        }

        if (isset($attrs['scope']) && ($attrs['scope'] == "expired")){
            $returnval = emember_evaluate_scope_expired_section_protection($attrs, $contents);
            return $returnval;
        }

        if ($acc_status == 'expired') {//This member account is expired
            //If an account is expired then the expiry message is shown to users even if the "do_not_show_restricted_msg" parameter is used in the shortcode.
            //So the "do_not_show_expired_msg" parameter allows you to turn off the "account expired" message.
            if($do_not_show_expired_msg){
                return "";
            }
            //Show the renewal message as this account is expired and the shortcode is not using the "do_not_show_expired_msg" parameter
            return get_renewal_link();
        }

        if (isset($attrs['member_id'])) {
            $member_id = $emember_auth->getUserInfo('member_id');
            $permitted_member_ids = explode('-', $attrs['member_id']);
            if (in_array($member_id, $permitted_member_ids)){
                return $contents;
            } else {
                if (!empty($do_not_show_restricted_msg)) {
                    return ""; //do not show the restrcted content message
                }
                return wp_emember_format_message(EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED);
            }
        }
        if (isset($attrs['for'])) {
            $level = $emember_auth->getUserInfo('membership_level');
            $permitted_levels = explode('-', $attrs['for']);
            if (in_array($level, $permitted_levels)){
                return $contents;
            }

            if ($emember_config->getValue('eMember_enable_secondary_membership')) {
                $sec_levels = $emember_auth->getUserInfo('more_membership_levels');
                if ($sec_levels) {
                    if (is_string($sec_levels)){
                        $sec_levels = explode(',', $sec_levels);
                    }
                    foreach ($sec_levels as $sec_level){
                        if (in_array($sec_level, $permitted_levels)){
                            //Lets make sure the users's secondary level is not expired before showing the content.
                            $member_id = $emember_auth->getUserInfo('member_id');

                            if(emember_is_secondary_level_expired($member_id, $sec_level)){
                                //This secondary level is expired. So can't show the content.
                                if (!empty($do_not_show_restricted_msg)) {
                                    return ""; //do not show the restrcted content message
                                }
                                return wp_emember_format_message('Your subscription for this membership level access has expired.');
                            }
                            return $contents;
                        }
                    }
                }
            }

            if (!empty($do_not_show_restricted_msg)) {
                return ""; //do not show the restrcted content message
            }

            if (isset($attrs['custom_msg'])) {//Show the custom message
                $replacement = $attrs['custom_msg'];
                return wp_emember_format_message($replacement);
            } else {//Show the standard hidden content
                $account_upgrade_url = $emember_config->getValue('eMember_account_upgrade_url');
                return wp_emember_format_message(EMEMBER_HIDDEN_CONTENT_MESSAGE . '<br/>' . EMEMBER_PLEASE . ' <a href=" ' . $account_upgrade_url . '" target=_blank>' . EMEMBER_RENEW_OR_UPGRADE . '</a> ' . EMEMBER_YOUR_ACCOUNT);
            }
        }
        if (isset($attrs['not_for'])) {
            $level = $emember_auth->getUserInfo('membership_level');
            $ban_levels = explode('-', $attrs['not_for']);
            $banned = false;
            if (in_array($level, $ban_levels)){
                $banned = true;
            }
            else if ($emember_config->getValue('eMember_enable_secondary_membership')) {
                $sec_levels = $emember_auth->getUserInfo('more_membership_levels');
                if (!empty($sec_levels)) {
                    if (is_string($sec_levels)){
                        $sec_levels = explode(',', $sec_levels);
                    }
                    foreach ($sec_levels as $sec_level){
                        if (in_array($sec_level, $ban_levels)){
                            $banned = true;
                        }
                    }
                }
            }
            if ($banned) {
                if (!empty($do_not_show_restricted_msg)) {
                    return ""; //do not show the restrcted content message
                }
                return wp_emember_format_message(EMEMBER_HIDDEN_CONTENT_MESSAGE);
            }
        }
        return $contents;
    }

    $join_url = $emember_config->getValue('eMember_payments_page');
    if (empty($join_url)) {
        return wp_emember_format_message('<b>Membership Payment/Join Page</b>value is not set in eMember settings. Site admin needs to complete the settings in the pages/forms settings menu of eMember before the plugin can work.');
    } else
        $join_url = ' href ="' . $join_url . '" ';

    if (!empty($do_not_show_restricted_msg)) {
        return ""; //do not show the restrcted content message
    }

    if (isset($attrs['custom_msg'])) {
        $replacement = $attrs['custom_msg'];
    } else {
        $replacement = '<a ' . $join_url . ' ><b>' . EMEMBER_MEMBERS_ONLY_MESSAGE . '</b></a>';
    }
    return wp_emember_format_message($replacement);
}

function emember_evaluate_scope_expired_section_protection($attrs, $contents)
{
    $emember_auth = Emember_Auth::getInstance();
    $emember_config = Emember_Config::getInstance();

    $sec_level_enabled = $emember_config->getValue('eMember_enable_secondary_membership');
    $acc_status = $emember_auth->getUserInfo('account_state');
    $level = $emember_auth->getUserInfo('membership_level');

    //Content is shown if account status is "expired" AND the membership level is one of the ones specified in the shortcode.
    if (isset($attrs['for'])) {
        //Level requirement is being used with the shortcode

        //Check if the account is expired or inactive.
        if ($acc_status == 'expired' || $acc_status == 'inactive') {
            //This account is expired. Show the content if level requirement is met.
            $permitted_levels = explode('-', $attrs['for']);
            if (in_array($level, $permitted_levels)){
                return $contents;
            }

            if ($sec_level_enabled) {
                $sec_levels = $emember_auth->getUserInfo('more_membership_levels');
                if ($sec_levels) {
                    if (is_string($sec_levels)){
                        $sec_levels = explode(',', $sec_levels);
                    }
                    foreach ($sec_levels as $sec_level){
                        if (in_array($sec_level, $permitted_levels)){
                            return $contents;
                        }
                    }
                }
            }
        }

        //Account is not expired or it doesn't meet the level requirement. Do not show this secton.
        if (isset($attrs['custom_msg'])) {//Show the custom message
            return wp_emember_format_message($attrs['custom_msg']);
        }else{
            return '';
        }
    }

    //TODO - add other requirement via shortcode parameters (if necessary).

    //None of the above extra conditions are specified in the shortcode so it is safe to use the fallback
    if ($acc_status == 'expired') {
        //This account is expired and the scope="expired" is set. Show the content to this user.
        return $contents;
    }else{
        //Account is not expired. Do not show this secton as it is ONLY for expired users.
        if (isset($attrs['custom_msg'])) {//Show the custom message
            return wp_emember_format_message($attrs['custom_msg']);
        }else{
            return '';
        }
    }
}
/*********** emember_protected shortcode end *********/