<?php if ($emember_config->getValue('eMember_enable_fancy_login') == '1' || $emember_config->getValue('eMember_enable_fancy_login') == '2'): ?>
    <fieldset id="emember_signin_menu">
        <span id="emem_ui_close" class="emember_ui_close">X</span>
        <form action="<?php echo esc_url(isset($login_url) ? $login_url : ''); ?>" id="emember_fancy_login_form" class="wp_emember_loginForm" name="loginForm" method="post">
            <input type="hidden" name="_ajax_nonce" value="<?php echo esc_attr(wp_create_nonce('emember-login-nonce')); ?>" />
            <input type="hidden" name="action" value="emember_ajax_login" />
            <p class="textbox">
                <label for="login_user_name" class="eMember_label"><?php echo esc_html(EMEMBER_USER_NAME); ?></label>
                <input type="text" tabindex="4" title="username" value="" name="login_user_name" id="login_user_name">
            </p>
            <p class="textbox">
                <label for="login_pwd" class="eMember_label"><?php echo esc_html(EMEMBER_PASSWORD); ?></label>
                <input type="password" tabindex="5" title="password" value="" name="login_pwd" id="login_pwd">
            </p>

            <p class="rememberme">
                <input type="submit" tabindex="7" value="<?php echo esc_attr(EMEMBER_SIGNIN); ?>" class="emember_button" name="doLogin" id="doLogin">
                <input type="hidden" value="1" name="testcookie" />
                <?php if ($emember_config->getValue('eMember_multiple_logins') != '1'): ?>
                    <input type="checkbox" tabindex="6" value="forever" name="rememberme" id="rememberme">
                    <label for="remember"><?php echo esc_html(EMEMBER_REMEMBER_ME); ?></label>
                <?php endif; ?>
            </p>
            <span id="emember_fancy_log_msg"></span>
            <p class="forgot">
                <?php
                $password_reset_url = $emember_config->getValue('eMember_password_reset_page');
                if ($password_reset_url):
                    ?>
                    <a id="forgot_pass" href="<?php echo esc_url($password_reset_url); ?>"><?php echo esc_html(EMEMBER_FORGOT_PASS); ?></a>
                <?php else : ?>
                    <a id="forgot_pass" rel="#emember_forgot_pass_prompt" class="forgot_pass_link" href="javascript:void(0);"><?php echo esc_html(EMEMBER_FORGOT_PASS); ?></a>
                <?php endif; ?>
            </p>
            <p class="forgot-username">
                <a title="Join us" id="join_us" href="<?php echo esc_url($join_url); ?>"><?php echo esc_html(EMEMBER_JOIN_US); ?></a>
            </p>
        </form>
        <div id="marker" style="display: none;"></div>
    </fieldset>
<?php endif; ?>

<?php
//Fancy login widget 2 is disabled for now. It will show fancy1 (for backwards compatibility).
?>
