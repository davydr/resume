<?php

class Emember_User_Permission {
    
    public $primary_level;
    public $secondary_levels;
    public $more_membership_levels_start_date;
    public $subscription_duration;
    public $primary_subscription_starts;

    public function __construct($userInfo) {
        $level_info = array();
        $current_level = $userInfo->membership_level;

        $more_levels = $userInfo->more_membership_levels;
        $more_levels = isset($more_levels) ? $more_levels : '';//Ensures if the value is null, then it will use empty string.
        $more_levels = is_array($more_levels) ? array_filter($more_levels) : $more_levels;
        if (is_array($more_levels)) {
            //Use the existing array
            $userInfo->more_membership_levels = $more_levels;
        } else {
            //Create array from the string data
            $userInfo->more_membership_levels = explode(',', $more_levels);
        }
        $this->primary_level = Emember_Permission::get_instance($userInfo->membership_level);
        $this->secondary_levels = array();
        $this->more_membership_levels_start_date = $userInfo->more_membership_levels_start_date;

        $config = Emember_Config::getInstance();
        $options = $this->primary_level->get_options();
        if (isset($options['promoted_level_id']) && ($options['promoted_level_id'] != -1)) {
            $current_subscription_starts = strtotime($userInfo->subscription_starts);
            $sec_levels = $userInfo->more_membership_levels; //This is an array
            $level_before = $userInfo->membership_level;
            $current_time = time();
            while (1) {
                if ($current_level === $options['promoted_level_id'])
                    break;
                $promoted_after = trim($options['days_after']);
                if (empty($promoted_after))
                    break;
                $d = ($promoted_after == 1) ? ' day' : ' days';
                $expires = strtotime(" + " . abs($promoted_after) . $d, $current_subscription_starts);
                if ($expires > $current_time)
                    break;
                if (!isset($options['promoted_level_id']) || ($options['promoted_level_id'] == -1))
                    break;
                //$current_subscription_starts = $expires;
                $sec_levels[] = $current_level;
                if (!array_key_exists(absint($current_level), $this->more_membership_levels_start_date)) {
                    $this->more_membership_levels_start_date[absint($current_level)] = date('Y-m-d', $current_subscription_starts);
                }
                $current_level = $options['promoted_level_id'];
                $current_subscription_starts = $current_subscription_starts;
                $this->primary_level = Emember_Permission::get_instance($current_level);
                $options = $this->primary_level->get_options();
            }
            if (($current_level != -1)) {
                $level_info ['membership_level'] = $current_level;
                $level_info['subscription_starts'] = date('Y-m-d', $current_subscription_starts);
                $userInfo->subscription_starts = date('Y-m-d', $current_subscription_starts);
                if ($config->getValue('eMember_enable_secondary_membership')) {
                    $sec_levels = array_unique((array) $sec_levels);
                    $level_info['more_membership_levels'] = implode(',', $sec_levels);
                    $level_info['more_membership_levels_start_date'] = json_encode($this->more_membership_levels_start_date);
                    $userInfo->more_membership_levels = $sec_levels;
                }
                $userInfo->membership_level = $current_level;
                global $wpdb;
                $wpdb->update(WP_EMEMBER_MEMBERS_TABLE_NAME, $level_info, array('member_id' => $userInfo->member_id));
                if ($level_info['membership_level'] != $level_before)
                    do_action('emember_membership_changed', array('member_id' => $userInfo->member_id,
                        'from_level' => $level_before,
                        'to_level' => $level_info['membership_level']));
            }
        }

        if ($config->getValue('eMember_enable_secondary_membership')) {
            if (!empty($userInfo->more_membership_levels)) {
                foreach ($userInfo->more_membership_levels as $l) {
                    if (empty($l))
                        continue;
                    $this->secondary_levels[] = Emember_Permission::get_instance($l);
                }
            }
        }
        $my_subcript_period = $this->primary_level->get('subscription_period');
        $my_subscript_unit = $this->primary_level->get('subscription_unit');
        if (($my_subcript_period == 0) && empty($my_subscript_unit))
            $type = 'noexpire';
        else if (($my_subcript_period == 0) && !empty($my_subscript_unit)) {
            $type = 'fixeddate';
            $my_subcript_period = $my_subscript_unit;
        } else {
            $type = 'interval';
            switch ($my_subscript_unit) {
                case 'Days':
                    break;
                case 'Weeks':
                    $my_subcript_period = $my_subcript_period * 7;
                    break;
                case 'Months':
                    $my_subcript_period = $my_subcript_period * 30;
                    break;
                case 'Years':
                    $my_subcript_period = $my_subcript_period * 365;
                    break;
            }
        }
        $this->subscription_duration = array(
            'duration' => $my_subcript_period,
            'type' => $type);
        $this->primary_subscription_starts = $userInfo->subscription_starts;
        $userInfo->more_membership_levels_start_date = $this->more_membership_levels_start_date;
    }

    public function is_permitted($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted($id)) {
            return true;
        }
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted($id))
                return true;
        }
        return false;
    }

    public function is_permitted_attachment($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted_attachment($id))
            return true;
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted_attachment($id))
                return true;
        }
        return false;
    }

    public function is_permitted_custom_post($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted_custom_post($id))
            return true;
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted_custom_post($id))
                return true;
        }
        return false;
    }

    public function is_permitted_category($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted_category($id))
            return true;
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted_category($id))
                return true;
        }
        return false;
    }

    public function is_post_in_permitted_category($post_id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($post_id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_post_in_permitted_category($post_id)) {
            return true;
        }

        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_post_in_permitted_category($post_id)) {
                return true;
            }
        }
        return false;
    }

    public function is_permitted_post($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted_post($id)) {
            return true;
        }
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted_post($id)) {
                return true;
            }
        }
        return false;
    }

    public function is_permitted_page($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted_page($id)) {
            return true;
        }
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted_page($id)) {
                return true;
            }
        }
        return false;
    }

    public function is_permitted_comment($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted_comment($id)) {
            return true;
        }
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted_comment($id)) {
                return true;
            }
        }
        return false;
    }

    public function is_permitted_parent_category($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_permitted_parent_category($id)) {
            return true;
        }
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_permitted_parent_category($id)) {
                return true;
            }
        }
        return false;
    }

    public function is_post_in_permitted_parent_category($id, $account_state = 'not set') {
        if (!$this->account_status_check_passed($id, $account_state)) {
            //Account status check failed. So this content will be protected.
            return false;
        }

        if (!wp_emember_is_expired($this->primary_level, $this->primary_subscription_starts) && $this->primary_level->is_post_in_permitted_parent_category($id)) {
            return true;
        }
        $start_dates = $this->more_membership_levels_start_date;
        foreach ($this->secondary_levels as $level) {
            $level_id = absint($level->get('id'));
            $start_date = isset($start_dates[$level_id]) ? $start_dates[$level_id] : $this->primary_subscription_starts;
            if (!wp_emember_is_expired($level, $start_date) && $level->is_post_in_permitted_parent_category($id)) {
                return true;
            }
        }
        return false;
    }

    public function get($key) {
        return $this->primary_level->get($key);
    }

    public function account_status_check_passed($id, $account_state) {
        $seconary_level_enabled = Emember_Config::getInstance()->getValue('eMember_enable_secondary_membership');

        if (!$seconary_level_enabled) {//This site is using only primary level option so check the account status
            if ($account_state != 'active' && $account_state != 'unsubscribed') {
                return false;
            } else {
                return true;
            }
        }

        //Return true for sites using secondary level feature at the moment.
        //TODO - This can be enhanced later with more conditional logic.

        return true;
    }

}
