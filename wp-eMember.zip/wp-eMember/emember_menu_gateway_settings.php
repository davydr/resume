<?php

function emember_payment_gateway_settings_menu() {
    echo '<div class="wrap">';
    echo '<div id="poststuff"><div id="post-body">';

    $emember_config = Emember_Config::getInstance();
    //$paypal_ipn_url = WP_EMEMBER_URL . "/ipn/eMember_handle_paypal_ipn.php";//Deprecated
    $paypal_ipn_url = WP_EMEMBER_SITE_HOME_URL.'/?emember_paypal_ipn=1';
    $cb_ipn_url = WP_EMEMBER_SITE_HOME_URL . "/?emember_cb_ipn=1";
    $jvzoo_ipn_url = WP_EMEMBER_SITE_HOME_URL . "/?emember_jvzoo_ipn=1&membership_level_id=XX";

    if (isset($_POST['info_update_jvzoo_integration'])) {
        //Verify Nonce
        if (!isset($_POST['emember_jvzoo_settings_nonce']) || !wp_verify_nonce($_POST['emember_jvzoo_settings_nonce'], 'emember_jvzoo_settings_action')) {
            wp_die('Nonce security check failed');
        }        
        
        $emember_config->setValue('jvzoo_secret_key', sanitize_text_field(trim($_POST["jvzoo_secret_key"])));
        $emember_config->saveConfig();

        echo '<div id="message" class="updated fade"><p><strong>';
        echo 'Clickbank Options Updated!';
        echo '</strong></p></div>';
    }
    
    if (isset($_POST['emem_generate_av_code'])) {
        //Verify Nonce
        if (!isset($_POST['emember_gen_av_code_settings_nonce']) || !wp_verify_nonce($_POST['emember_gen_av_code_settings_nonce'], 'emember_gen_av_code_settings_action')) {
            wp_die('Nonce security check failed');
        }  
        
        $mem_level = sanitize_text_field(trim($_POST['emember_paypal_av_member_level']));
        $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" . $mem_level . "'");
        if ($membership_level_resultset) {
            $pp_av_code = 'notify_url=' . $paypal_ipn_url . '<br />' . 'custom=subsc_ref=' . $mem_level;
            echo '<div id="message" class="updated fade"><p>';
            echo '<strong>Paste the code below in the "Add advanced variables" field of your PayPal button for membership level ' . $mem_level . '</strong>';
            echo '<br /><code>' . $pp_av_code . '</code>';
            echo '</p></div>';
        } else {
            echo '<div id="message" class="updated fade"><p><strong>';
            echo 'Error! The membership level ID (' . $mem_level . ') you specified is incorrect. Please check this value again.';
            echo '</strong></p></div>';
        }
    }
    ?>
    <div class="postbox">
        <h3 class="hndle"><label for="title">WP eStore Integration Settings</label></h3>
        <div class="inside">

            <p><strong>
                    Please read the <a href="https://www.tipsandtricks-hq.com/wordpress-membership/wp-emember-and-wp-estore-integration-for-membership-payment-60" target="_blank">WP eStore Integration Instruction</a> to integrate eMember with WP eStore's purchase button.
                </strong></p>

        </div></div>

    <div class="postbox">
        <h3 class="hndle"><label for="title">Direct PayPal Integration Settings</label></h3>
        <div class="inside">

            <p><strong>
                    Please read the <a href="https://www.tipsandtricks-hq.com/wordpress-membership/how-to-use-a-simple-paypal-payment-button-to-accept-membership-payment-146" target="_blank">Direct PayPal Button Integration Instruction</a> to integrate eMember directly with a PayPal button.
                </strong></p>

            <table width="100%" border="0" cellspacing="0" cellpadding="6">
                <tr valign="top"><td width="25%" align="left">
                        PayPal IPN (Instant Payment Notification) URL Value:
                    </td><td align="left">
                        <code><?php echo $paypal_ipn_url; ?></code>
                        <br /><br /><i>You will need to use the above URL as the "IPN handling script URL" value in your your PayPal button.</i><br /><br />
                    </td></tr>
            </table>

            <strong>Generate the "Advanced Variables" Code for your PayPal button</strong>
            <br />
            <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
                <?php wp_nonce_field('emember_gen_av_code_settings_action', 'emember_gen_av_code_settings_nonce'); ?>
                Enter the Membership Level ID
                <input name="emember_paypal_av_member_level" type="text" size="4" value="" />
                <input type="submit" name="emem_generate_av_code" class="button-primary" value="Generate Code" />
            </form>

        </div>
    </div>

    <div class="postbox">
        <h3 class="hndle"><label for="title">JVZoo Integration Settings</label></h3>
        <div class="inside">

            <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
                <?php wp_nonce_field('emember_jvzoo_settings_action', 'emember_jvzoo_settings_nonce'); ?>
                <input type="hidden" name="info_update_jvzoo_integration" id="info_update_jvzoo_integration" value="true" />

                <table width="100%" border="0" cellspacing="0" cellpadding="6">
                    <tr valign="top">
                        <td width="25%" align="left">
                            JVZoo Secret Key:
                        </td>
                        <td align="left">
                            <input name="jvzoo_secret_key" type="text" size="50" value="<?php echo $emember_config->getValue('jvzoo_secret_key'); ?>"/>
                            <br /><i>Enter your JVZoo secret key. You can configure your secret key from the MyAccount page of your JVZoo account. Search for <code>Click here to edit JVZIPN Secret Key</code> link in your JVZoo account.</i><br /><br />
                        </td>
                    </tr>

                    <tr valign="top">
                        <td width="25%" align="left">
                            JVZoo Instant Notification URL Value (JVZIPN):
                        </td>
                        <td align="left">
                            <code><?php echo $jvzoo_ipn_url; ?></code>
                            <br /><br /><i>Replace XX with the membership level ID. Enter this URL in your your JVZoo account's "JVZIPN URL" field. You can edit your product (that corresponds to this membership level) in the JVZoo account and enter the URL there.</i><br /><br />
                        </td>
                    </tr>
                </table>

                <div class="submit">
                    <input type="submit" name="info_update_emem_jvzoo" class="button-primary" value="<?php _e('Save JVZoo Otions'); ?>" />
                </div>
            </form>
        </div>
    </div>

    <?php
    echo '</div></div>';
    echo '</div>';
}
