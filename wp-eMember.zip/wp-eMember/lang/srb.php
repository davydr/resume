<?php
define("EMEMBER_MORE_LINK","Nastavak");
define("EMEMBER_LEVEL_NOT_ALLOWED","Vaš tip korisnika nema prava da vidi nastavak sadržaja");
define("EMEMBER_CONTENT_RESTRICTED","Nemate odobrenje da vidite ovaj sadržaj.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Vaš tip korisnika nema pristup ovom sadržaju. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Ovaj sadržaj je dostupan samo registrovanim korisnicima.");
define("EMEMBER_MEMBER_LOGIN",'Prijava korisnika');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Period vaše registracije je istekao. ");
define("EMEMBER_LOGIN","Prijava");
define("EMEMBER_RENEW", "Obnovi");
define("EMEMBER_UPGRADE", "Promeni tip korisnika");
define("EMEMBER_TO_VIEW_CONTENT", "pristup ovom sadržaju. ");
define("EMEMBER_PLEASE", "Molimo");
define("EMEMBER_JOIN","Registrujte se");
define("EMEMBER_NON_MEMBER", "Niste registrovani?");
define("EMEMBER_YOUR_ACCOUNT", " vaš nalog.");
define("EMEMBER_PROFILE_MESSAGE","Prijavite se da bi uredili vaš profil.");
define("EMEMBER_LOGGED_IN_AS", "Prijavljeni ste kao korisnik: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Vaš tip korisnika je: ");
define("EMEMBER_LOGOUT", "Odjava");
define("EMEMBER_EDIT_PROFILE", "Uređivanje profila");
define("EMEMBER_SUPPORT_PAGE","Strana za pomoć");
define("EMEMBER_BOOKMARK_DISABLED", "Označavanje je isključeno.");
define("EMEMBER_NO_BOOKMARK", "Još uvek niste ništa označili kao omiljeno.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Morate se prijaviti da biste videli listu omiljenog.");
define("EMEMBER_FORGOT_PASS","Zaboravili ste lozinku?");
define("EMEMBER_JOIN_US","Pridružite nam se");
define("EMEMBER_USER_NAME", "Korisničko ime");
define("EMEMBER_PASSWORD", "Lozinka");
define("EMEMBER_USER_NAME_TAKEN", "Uneseno korisničko ime je već u upotrebi! <br/>Molimo vas da izaberete neko drugo.");
define("EMEMBER_EMAIL_TAKEN", "Unesena adresa je već u upotrebi! <br/>Molimo vas da izaberete neku drugu. ");
define("EMEMBER_REG_COMPLETE", "Registracija je uspešno završena! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Obaveštenje o registraciji novog korisnika");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Novi korisnik je registrovan. Poslata mu/joj je sledeća poruka.");
define("EMEMBER_USER_PASS_MSG", "Molimo vas da unesete korisničko ime i lozinku. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Besplatno članstvo nije dozvoljeno!");
define("EMEMBER_EMAIL_UNAVAIL","Šifra ove elektronske pošte nije dostupna!");
define("EMEMBER_PROFILE_UPDATED","Vaš profil je ažuriran!");
define("EMEMBER_EMAIL_INVALID","Neispravna adresa.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Ovaj nalog je neaktivan.");
define("EMEMBER_WRONG_PASS","Pogrešna lozinka.");
define("EMEMBER_WRONG_USER_PASS", "Pogrešno korisničko ime ili lozinka.");
define("EMEMBER_LOGOUT_SUCCESS", "Uspešno ste se odjavili. ");
define("EMEMBER_ADDED", "Dodato");
define("EMEMBER_FAVORITE", "Omiljeno");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Vaši detalji");
define("EMEMBER_PASS_EMAILED_MSG","Nova lozinka vam je poslata elektronskom poštom.");
define("EMEMBER_EMAIL_NOT_EXIST","Korisnik sa ovom adresom ne postoji.");
define("EMEMBER_ALREADY_TAKEN","Već u upotrebi.");
define("EMEMBER_STILL_AVAIL","Dostupno.");
define("EMEMBER_WP_TAKEN","Već u upotrebi.");
define('EMEMBER_TITLE','Titula');
define("EMEMBER_FIRST_NAME","Ime");
define("EMEMBER_LAST_NAME","Prezime");
define("EMEMBER_EMAIL","Elektronska pošta");
define("EMEMBER_MEMBERSHIP_LEVEL","Tip");
define("EMEMBER_USERNAME","Korisničko ime");
define("EMEMBER_COMPANY","Firma");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Ulica i broj");
define("EMEMBER_ADDRESS_CITY","Grad");
define("EMEMBER_ADDRESS_STATE","Mesto");
define("EMEMBER_ADDRESS_ZIP","Poštanski broj");
define("EMEMBER_ADDRESS_COUNTRY","Država");
define("EMEMBER_GENDER","Pol");
define("EMEMBER_GENDER_MALE","Muško");
define("EMEMBER_GENDER_FEMALE","Žensko");
define("EMEMBER_GENDER_UNSPECIFIED","Nije bitno");
define("EMEMBER_REGISTRATION","Registracija");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Ostavite prazno ako želite da zadržite postojeću lozinku.");
define("EMEMBER_UPDATE", "Ažuriraj");
define("EMEMBER_ADD","Dodaj");
define("EMEMBER_ADD_FAV","Dodaj u Omiljeno");
define("EMEMBER_BOOKMARK","Obeleži");
define("EMEMBER_LOGIN_TO_BOOKMARK","Prijavi se na obeleženo.");
define("EMEMBER_PASS_RESET","Promeni lozinku");
define("EMEMBER_PASS_RESET_MSG","Unesite adresu vaše elektronske pošte. Tamo ćemo vam poslati novu lozinku.");
define("EMEMBER_RESET","Poništi");
define("EMEMBER_CLOSE","Zatvori");
define("EMEMBER_PROFILE_IMAGE", "Foto profila");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Niste prijavljeni.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Moj bezbedni RSS");
define("EMEMBER_WRONG_RSS_URL","Format adrese je neispravan.");
define("EMEMBER_NO_USER_KEY","Ključ toka nije ispravan!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Premašili ste dozvoljen dnevni broj prijavljivanja.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Informacija o vašem nalogu:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Vaša registracija ističe:");
define("EMEMBER_EMAIL_BLACKLISTED","Vaša adresa je stavljena na crnu listu. <br/>
        		       ne možete se registrovati sa ovom adresom.");
define("EMEMBER_IP_BLACKLISTED","Vaša IP adresa je na crnoj listi. <br/>
		       ne možete se registrovati sa te lokacije.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Zapamti me");
define("EMEMBER_NEVER", "Nikad");
define('EMEMBER_ACTIVE','aktivna');
define('EMEMBER_INACTIVE','neaktivna');
define('EMEMBER_EXPIRED','istekla');
define('EMEMBER_PENDING','čeka odobrenje');
define('EMEMBER_UNSUBSCRIBED','odjavljena');
define('EMEMBER_VISIT_PAYMENT_PAGE','Idite na stranu za plaćanje');
define('EMEMBER_CLICK','Kliknite');
define('EMEMBER_HERE','ovde');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Dobar dan, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " da uđete. Niste registrovani? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Proverite vašu elektronsku poštu i kliknite na vezu u njoj.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Morate uneti adresu elektronske pošte!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Morate popuniti sva polja!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Ponovite lozinku");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'korisničko ime ne može ostati nepopunjeno.');
define('EMEMBER_USERNAME_4_CHARS', 'korisničko ime mora biti duže od 4 znaka');
define('EMEMBER_EMAIL_NOT_EMPTY','adresa elektronske pošte ne može ostati nepopunjena');
define('EMEMBER_INVALID_EMAIL','adresa elektronske pošte je neispravna');
define('EMEMBER_PASSWORD_EMPTY','Lozinka ne može biti nepopunjena');
define('EMEMBER_USERNAME_TAKEN','Ovo korisničko ime je zauzeto');
define('EMEMBER_USERNAME_AVAIL','Ovo korisničko ime je slobodno');
define('EMEMBERR_WAIT','Proveravamo. Molimo vas sačekajte.');
define('EMEMBER_REQUIRED','Ovo polje je obavezno');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'znakova');
define('EMEMBER_FIELD_MISMATCH','Polja nisu identična');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Dozvoljeni su samo slova, brojevi i donja crta');
define('EMEMBER_PASSWORD_MISMATCH','Lozinka se ne poklapa.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Promenili ste lozinku. Molimo vas odjavite se i ponovo se prijavite sa novom lozinkom.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Korisnički profil');
define('EMEMBER_AUTH_REQUIRED','Potrebna je autentikacija');
define('EMEMBER_PROTECTED_BY','Zaštićeno sa');
define('EMEMBER_SIGNIN','Prijavite se');
define('EMEMBER_TO_COMMENT', ' da unesete komentar');
define('EMEMBER_WAIT', 'sačekajte');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Obnovite ili promenite tip korisnika');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Automatski ste odjavljeni zbog neaktivnosti. Prijavite se ponovo');
define('EMEMBER_USER_PASS_EMPTY','Polja za korisničko ime i lozinku ne mogu biti prazna!');
define('EMEMBER_TERMS_WARNING', 'Morate prihvatiti uslove korišćenja.');
define("EMEMBER_ACCEPT", "Prihvatam ");
define('EMEMBER_TERMS_CONDITIONS', 'Uslove korišćenja');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Popunite sledeće podatke. Nečete moći da se registrujete dok ne potvrdimo njihovu verodostojnost");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','g.');
define('EMEMBER_MRS','gđa.');
define('EMEMBER_MISS','gđica.');
define('EMEMBER_MS','g.');
define('EMEMBER_DR','dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Nemate pravo da vidite komentare.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Ovaj sardržaj nije dostupan vašem tipu korisnika.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Šta tražite?');
define('EMEMBER_PREV', 'Prethodno');
define('EMEMBER_NEXT', 'Sledeće');
define('EMEMBER_SEARCH', 'Traži');
define('EMEMBER_DATA_NOT_FOUND', 'Ništa nije pronađeno.');
define('EMEMBER_ALREADY_LOGGED_IN','Odjavljeni ste pošto se isto korisničko ime prijavilo sa drugog mesta.');
define('EMEMBER_WELCOME_PAGE', 'Dobrodošli');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Ukloni");
define('EMEMBER_UPLOAD', 'Postavi');
define('EMEMBER_ACTION', 'Radnja');
define('EMEMBER_DETAILS','Detalji');
define('EMEMBER_DELETE_ACC','Izbriši nalog');
define('EMEMBER_MEMBER_SINCE','Član od');
define('EMEMBER_USER','Korisnik');
define('EMEMBER_USERS','Korisnici');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Unesite prikazan tekst');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Ostavite polje praznim');
define('EMEMBER_CAPTCHA_FAILED','Niste dobro uneli prikazan tekst');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Izaberite jedan');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Oznake');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Niste dobro uneli prikazan tekst.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Hvala što ste se registrovali. Vaš nalog čeka na odobrenje.');
define("EMEMBER_ACCOUNT_PENDING","Ovaj nalog čeka na odobrenje.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Da li ste sigurni? ');
define('EMEMBER_YES','Da');
define('EMEMBER_NO','Ne');
define('EMEMBER_REDIRECTION_MESSAGE','Molimo vas sačekajte.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Tip korisnika je ažuriran.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Morate biti prijavljeni da promenite tip korisnika.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Vaš nalog je aktiviran.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Dobar dan, Vaša registracija je odobrena. Možete se prijaviti.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Dozvoljena su slova, brojevi i donja crta. ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Uredite profil ponovo');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Automatski ste odjavljeni zbog neaktivnosti.');
define('EMEMBER_LOGIN_AGAIN', 'Prijavite se ponovo');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Membership Level');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'This content was published before you joined us. You do not have permission to view this content.');
define('EMEMBER_RETYPE_EMAIL', 'Retype Email');
define('EMEMBER_EMAIL_MISMATCH', 'Email field mismatch');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Error! The unique registration code you used in the URL has already been used or it is invalid!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Remove');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');

