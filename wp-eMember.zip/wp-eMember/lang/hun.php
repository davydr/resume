<?php
define("EMEMBER_MORE_LINK","Tovább olvasom");
define("EMEMBER_LEVEL_NOT_ALLOWED","A tagsági szinted nem teszi lehetővé a további tartalom elérését.");
define("EMEMBER_CONTENT_RESTRICTED","Ehhez a tartalomhoz nincsen jogosultságod.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","A tagsági szinted nem elégséges ennek a tartalomnak az eléréséhez. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Ez a tartalom csak tagoknak érhető el.");
define("EMEMBER_MEMBER_LOGIN",'Tagok belépése');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "A tagságod lejárt. ");
define("EMEMBER_LOGIN","Bejelentkezés");
define("EMEMBER_RENEW", "Megújítás");
define("EMEMBER_UPGRADE", "Feljebb váltás");
define("EMEMBER_TO_VIEW_CONTENT", "a tartalom megnézéséhez. ");
define("EMEMBER_PLEASE", "Kérjük");
define("EMEMBER_JOIN","Csatlakozz most!");
define("EMEMBER_NON_MEMBER", "Még nem vagy tag?");
define("EMEMBER_YOUR_ACCOUNT", " a fiókod.");
define("EMEMBER_PROFILE_MESSAGE","Jelentkezz be a profilod szerkesztéséhez.");
define("EMEMBER_LOGGED_IN_AS", "Be vagy jelentkezve, mint: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Tagsági szinted: ");
define("EMEMBER_LOGOUT", "Kijelentkezés");
define("EMEMBER_EDIT_PROFILE", "Profilod szerkesztése");
define("EMEMBER_SUPPORT_PAGE","Támogatási oldal");
define("EMEMBER_BOOKMARK_DISABLED", "A könyvjelző funkció ki van kapcsolva.");
define("EMEMBER_NO_BOOKMARK", "Még semmit sem adtál a kedvencekhez eddig.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Be kell jelentkezned a könyvjelzőid listájának megnézéséhez.");
define("EMEMBER_FORGOT_PASS","Elfelejtetted a jelszavadat?");
define("EMEMBER_JOIN_US","Csatlakozz hozzánk!");
define("EMEMBER_USER_NAME", "Felhasználónév");
define("EMEMBER_PASSWORD", "Jelszó");
define("EMEMBER_USER_NAME_TAKEN", "A választott felhasználónevet már használja valaki! <br/>Válassz egy másik nevet.");
define("EMEMBER_EMAIL_TAKEN", "A választott email címet már használja valaki! <br/>Válassz egy másik email címet. ");
define("EMEMBER_REG_COMPLETE", "A regisztráció megtörtént! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Új tag regisztrációs értesítés");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Egy új tag regisztrált. A következő emailt küldtük ki a tagnak.");
define("EMEMBER_USER_PASS_MSG", "Válassz egy felhasználónevet és jelszót lentebb a regisztráció befejezéséhez. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Nincsen ingyenes tagság ezen az oldalon!");
define("EMEMBER_EMAIL_UNAVAIL","Ez az email azonosító nem érhető el!");
define("EMEMBER_PROFILE_UPDATED","A profil adataidat frissítettük!");
define("EMEMBER_EMAIL_INVALID","Érvénytelen emailcím.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Ez a fiók inaktív.");
define("EMEMBER_WRONG_PASS","Hibás jelszót adtál meg.");
define("EMEMBER_WRONG_USER_PASS", "Hibás felhasználónév vagy jelszó.");
define("EMEMBER_LOGOUT_SUCCESS", "Sikeresen kijelentleztél. ");
define("EMEMBER_ADDED", "Hozzáadva");
define("EMEMBER_FAVORITE", "Kedvenc");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Tagsági adataid");
define("EMEMBER_PASS_EMAILED_MSG","Az új jelszavadat emailben elküldtük neked.");
define("EMEMBER_EMAIL_NOT_EXIST","Ezzel az email címmel nincsen felhasználónk.");
define("EMEMBER_ALREADY_TAKEN","Upszi! Ezt a felhasználónevet már használják.");
define("EMEMBER_STILL_AVAIL","Ez még elérhető.");
define("EMEMBER_WP_TAKEN","Sajnáljuk, de ezt már használatban van a WordPressben.");
define('EMEMBER_TITLE','Megszólítás');
define("EMEMBER_FIRST_NAME","Keresztneved");
define("EMEMBER_LAST_NAME","Vezetékneved");
define("EMEMBER_EMAIL","Emailed");
define("EMEMBER_MEMBERSHIP_LEVEL","Tagság");
define("EMEMBER_USERNAME","Felhasználóneved");
define("EMEMBER_COMPANY","Cég");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Utca");
define("EMEMBER_ADDRESS_CITY","Város");
define("EMEMBER_ADDRESS_STATE","Állam/megye");
define("EMEMBER_ADDRESS_ZIP","Irányítószám");
define("EMEMBER_ADDRESS_COUNTRY","Ország");
define("EMEMBER_GENDER","Nemed");
define("EMEMBER_GENDER_MALE","Férfi");
define("EMEMBER_GENDER_FEMALE","Nő");
define("EMEMBER_GENDER_UNSPECIFIED","Nincsen megadva");
define("EMEMBER_REGISTRATION","Regisztráció");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Hagy üresen, ha meg akarod tartani a jelenlegi jelszavadat.");
define("EMEMBER_UPDATE", "Frissítés");
define("EMEMBER_ADD","Add");
define("EMEMBER_ADD_FAV","Kedvencekhez adás");
define("EMEMBER_BOOKMARK","Könyvjelző");
define("EMEMBER_LOGIN_TO_BOOKMARK","Bejelentkezés a könyvjelzőkbe.");
define("EMEMBER_PASS_RESET","Jelszó megújítás");
define("EMEMBER_PASS_RESET_MSG","Add meg az email címedet és küldjük az új jelszavadat.");
define("EMEMBER_RESET","Megújítás");
define("EMEMBER_CLOSE","Bezárás");
define("EMEMBER_PROFILE_IMAGE", "Profilkép");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Nem vagy bejelentkezve.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Biztonságos RSS-em");
define("EMEMBER_WRONG_RSS_URL","Sajnáljuk, de az URL nincsen jól formázva.");
define("EMEMBER_NO_USER_KEY","Sajnáljuk, de a feed kulcsa nem tűnik érvényesnek!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Elérted a napi bejelentkezési maximumot.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "A fiókod állapota:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "A tagságod lejár:");
define("EMEMBER_EMAIL_BLACKLISTED","Az email címed fekete listára került. <br/>Ezzel az email címmel nem fogsz tudni regisztrálni. <br/>Kérjük, lépj kapcsolatba az oldal kezelőjével.");
define("EMEMBER_IP_BLACKLISTED","Az IP címed fekete listára került. <br/> Nem fogsz tudni regisztrálni. <br/>Kérjük, lépj kapcsolatba az oldal kezelőjével.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Emlékezz rám");
define("EMEMBER_NEVER", "lemondásig");
define('EMEMBER_ACTIVE','aktív');
define('EMEMBER_INACTIVE','inaktív');
define('EMEMBER_EXPIRED','lejárt');
define('EMEMBER_PENDING','függőben');
define('EMEMBER_UNSUBSCRIBED','leiratkozott');
define('EMEMBER_VISIT_PAYMENT_PAGE','Kérjük, lépj át a fizetési oldalra a tagság megvásárlásához.');
define('EMEMBER_CLICK','Kattints');
define('EMEMBER_HERE','ide');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Helló, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " kezdéshez. Nem vagy tag még? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Ellenőrizd az email fiókodat és kattints az elküldött linkre a regisztráció befejezéséhez.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Adj meg egy emil címet!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Tölts ki minden mezőt!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Jelszó újra");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'a felhasználónév nem lehet üres.');
define('EMEMBER_USERNAME_4_CHARS', 'a felhasználónév nem lehet 4 karakternél rövidebb');
define('EMEMBER_EMAIL_NOT_EMPTY','az email nem lehet üres');
define('EMEMBER_INVALID_EMAIL','az emailcím nem érvényes');
define('EMEMBER_PASSWORD_EMPTY','A jelszó mező nem lehet üres');
define('EMEMBER_USERNAME_TAKEN','Ez a felhasználónév már foglalt');
define('EMEMBER_USERNAME_AVAIL','Ez a név nem érhető el');
define('EMEMBERR_WAIT','Ellenőrizzük, kérlek várj');
define('EMEMBER_REQUIRED','Ez a mező szükséges');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'karakter szükséges');
define('EMEMBER_FIELD_MISMATCH','A mezők nem egyeznek meg.');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Csak betű, szám és alsó vonás lehetséges');
define('EMEMBER_PASSWORD_MISMATCH','A jelszavek nem egyeznek meg.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Megváltoztattad a jelszavadat. Javasoljuk, hogy lépj ki és utána jelentkezz be ismét az új jelszavaddal.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Felhasználói profil');
define('EMEMBER_AUTH_REQUIRED','Azonosítás szükséges');
define('EMEMBER_PROTECTED_BY','Protected by');
define('EMEMBER_SIGNIN','Bejelentkezés');
define('EMEMBER_TO_COMMENT', ' hozzászóláshoz');
define('EMEMBER_WAIT', 'várj');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Megújítás vagy feljebb váltás');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','A munkameneted lejárt. Kérjük jelentkezz be ismét.');
define('EMEMBER_USER_PASS_EMPTY','A felhasználónév/jelszó mező nem lehet üres!');
define('EMEMBER_TERMS_WARNING', 'Kérjük, fogadd el a Felhasználási feltételeket a regisztrációhoz.');
define("EMEMBER_ACCEPT", "I agree to the ");
define('EMEMBER_TERMS_CONDITIONS', 'Felhasználási feltételek');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Ez egy előregisztrációs űrlap. Töltsd ki a következő adatokat az emailed ellenőrzéséhez először. Az ellenőrzést követően fogod elérni a teljes regsiztrációs űrlapot.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Úr');
define('EMEMBER_MRS','Úrhölgy');
define('EMEMBER_MISS','Úrhölgy');
define('EMEMBER_MS','Úrhölgy');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Nincsen jogosultságod a hozzászólások megtekintéséhez.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','A fiókodnak nincsen jogosultsága ehhez a tartalomhoz.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Keresőszó');
define('EMEMBER_PREV', 'Előző');
define('EMEMBER_NEXT', 'Következő');
define('EMEMBER_SEARCH', 'Keresés');
define('EMEMBER_DATA_NOT_FOUND', 'Nem találtam adatot.');
define('EMEMBER_ALREADY_LOGGED_IN','Kijelentkeztettünk, mert egy másik felhasználó bejelentkezett ebbe a fiókba egy másik böngészőből.');
define('EMEMBER_WELCOME_PAGE', 'Üdvözlő oldal');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Eltávolítás");
define('EMEMBER_UPLOAD', 'Feltöltés');
define('EMEMBER_ACTION', 'Művelet');
define('EMEMBER_DETAILS','Részletek');
define('EMEMBER_DELETE_ACC','Fiók törlése');
define('EMEMBER_MEMBER_SINCE','Tagság kezdete');
define('EMEMBER_USER','Felhasználó');
define('EMEMBER_USERS','Felhasználók');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Add meg a captcha kódot');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Hagyd üresen következő mezőket');
define('EMEMBER_CAPTCHA_FAILED','Nem sikerült a captcha ellenőrzés');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Válassz egyet!');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Könyvjelzők');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Nem sikerült a captcha ellenőrzés. Próbáld újra.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Köszönjük, hogy regisztráltál. A fiókod az adminisztrátor jóváhagyására vár jelenleg.');
define("EMEMBER_ACCOUNT_PENDING","Ez a fiók jelenleg jóváhagyásra vár.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Biztosan? ');
define('EMEMBER_YES','Igen');
define('EMEMBER_NO','Nem');
define('EMEMBER_REDIRECTION_MESSAGE','Kérjük várj... hamarosan átirányítunk.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','A tagsági szint frissítve van.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Be kell jelentkezned a tagsági szinted feljebb váltásához.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','A felhasználói fiókodat aktiváltuk.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Helló, A felhasználói fiókodat aktiváltuk. Most már be tudsz jelentkezni az oldalon.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', 'Betű, szám, alsó vonás vagy email engedélyezett');
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Profil szerkesztése ismét');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','A munkamenet lejárt');
define('EMEMBER_LOGIN_AGAIN', 'Kérjük, jelentkezz be ismét');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Tagsági szint');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Ez a tartalom a csatlakozásodat megelőzően volt publikálva. Nincsen jogosultságod a tartalom megtekintéséhez.');
define('EMEMBER_RETYPE_EMAIL', 'Email újra');
define('EMEMBER_EMAIL_MISMATCH', 'Az email mezők nem egyeznek meg');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'HIBA! Az egyedi regisztrációs kódod, ami az URL-ben van már használt vagy már nem érvényes!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Eltávolítás');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Aposztrof karakter nem engedélyezett itt.');
define('EMEMBER_SEND_VERIFICATION', 'Ellenőrző email kiküldése');

