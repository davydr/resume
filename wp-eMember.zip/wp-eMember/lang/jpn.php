<?php
define("EMEMBER_MORE_LINK","続きを読む");
define("EMEMBER_LEVEL_NOT_ALLOWED","この続きを見るには、メンバー登録と必要な権限が与えられたメンバーシップレベルが必要です。");
define("EMEMBER_CONTENT_RESTRICTED","この内容を見るのに必要な権限が与えられていません。");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","この内容見るのに必要な権限が与えられたメンバーシップレベルではありません。 ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","この内容はメンバー専用です。");
define("EMEMBER_MEMBER_LOGIN",'メンバー ログイン');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "購読期間が過ぎています。 ");
define("EMEMBER_LOGIN","ログイン");
define("EMEMBER_RENEW", "更新");
define("EMBMBER_UPGRADE", "アップグレード");
define("EMEMBER_TO_VIEW_CONTENT", "して内容を見る ");
define("EMEMBER_PLEASE", "今すぐ");
define("EMEMBER_JOIN","メンバー登録");
define("EMEMBER_NON_MEMBER", "メンバーではありませんか?");
define("EMEMBER_YOUR_ACCOUNT", " アカウント名");
define("EMEMBER_PROFILE_MESSAGE","ログインしてプロフィールを編集してください。");
define("EMEMBER_LOGGED_IN_AS", "ログイン名 ");
define("EMEMBER_LOGGED_IN_LEVEL", "メンバーシップレベル");
define("EMEMBER_LOGOUT", "ログアウト");
define("EMEMBER_EDIT_PROFILE", "プロフィールを編集する");
define("EMEMBER_SUPPORT_PAGE","サポートページ");
define("EMEMBER_BOOKMARK_DISABLED", "ブックマーク機能は使えません。");
define("EMEMBER_NO_BOOKMARK", "お気に入りには何も登録されていません。");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","ブックマークリストを見るにはログインする必要があります。");
define("EMEMBER_FORGOT_PASS","パスワードをお忘れですか?");
define("EMEMBER_JOIN_US","今すぐメンバー登録");
define("EMEMBER_USER_NAME", "ユーザー名");
define("EMEMBER_PASSWORD", "パスワード");
define("EMEMBER_USER_NAME_TAKEN", "同じユーザー名が既に使われています。 <br/>別のユーザー名を入力してください。");
define("EMEMBER_EMAIL_TAKEN", "同じメールアドレスが既に登録されています。 <br/>別のメールアドレスを入力してください。");
define("EMEMBER_REG_COMPLETE", "ユーザー登録が完了しました。");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "新規ユーザー登録通知");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "新しいメンバーが登録されました。メンバー宛にに以下のメールが送信されました。");
define("EMEMBER_USER_PASS_MSG", "以下にユーザー名とパスワードを入力することでユーザー登録が完了します。 ");
define("EMEMBER_FREE_MEMBER_DISABLED", "このサイトでは無料のメンバーシップが無効になっています。");
define("EMEMBER_EMAIL_UNAVAIL","このメールIDは使用することができません。");
define("EMEMBER_PROFILE_UPDATED","プロフィールが更新されました。");
define("EMEMBER_EMAIL_INVALID","無効なメールアドレスです。");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","このアカウントは使われていません。");
define("EMEMBER_WRONG_PASS","パスワードが正しくありません。");
define("EMEMBER_WRONG_USER_PASS", "ユーザー名かパスワードが正しくありません。");
define("EMEMBER_LOGOUT_SUCCESS", "ログアウトしました。");
define("EMEMBER_ADDED", "追加されした。");
define("EMEMBER_FAVORITE", "お気に入り");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","メンバーシップの詳細情報です。");
define("EMEMBER_PASS_EMAILED_MSG","新しいパスワードがメールで送信されました。");
define("EMEMBER_EMAIL_NOT_EXIST","このメールアドレスのユーザーは存在しません。");
define("EMEMBER_ALREADY_TAKEN","すでに他のユーザーに使われています。");
define("EMEMBER_STILL_AVAIL","このユーザー名は使用可能です。");
define("EMEMBER_WP_TAKEN","このユーザー名は既に管理者によって使われています。");
define('EMEMBER_TITLE','役職');
define("EMEMBER_FIRST_NAME","名前(ファーストネーム)");
define("EMEMBER_LAST_NAME","苗字(ラストネーム)");
define("EMEMBER_EMAIL","メールアドレス");
define("EMEMBER_RETYPE_EMAIL","メールアドレスを再度入力してください。");
define("EMEMBER_MEMBERSHIP_LEVEL","メンバーシップ");
define("EMEMBER_USERNAME","ユーザー名");
define("EMEMBER_COMPANY","会社名");
define("EMEMBER_PHONE","電話番号");
define("EMEMBER_ADDRESS_STREET","番地、マンション名");
define("EMEMBER_ADDRESS_CITY","市区町村");
define("EMEMBER_ADDRESS_STATE","都道府県");
define("EMEMBER_ADDRESS_ZIP","郵便番号");
define("EMEMBER_ADDRESS_COUNTRY","国");
define("EMEMBER_GENDER","性別");
define("EMEMBER_GENDER_MALE","男性");
define("EMEMBER_GENDER_FEMALE","女性");
define("EMEMBER_GENDER_UNSPECIFIED","その他");
define("EMEMBER_REGISTRATION","登録");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","パスワードを変更しない場合は空白にておきます。");
define("EMEMBER_UPDATE", "更新");
define("EMEMBER_ADD","追加");
define("EMEMBER_ADD_FAV","お気に入りに追加する");
define("EMEMBER_BOOKMARK","ブックマーク");
define("EMEMBER_LOGIN_TO_BOOKMARK","ブックマークにログイン");
define("EMEMBER_PASS_RESET","パスワードリセット");
define("EMEMBER_PASS_RESET_MSG","メールアドレスを入力してください。メールでパスワードが送信されます。");
define("EMEMBER_RESET","リセット");
define("EMEMBER_CLOSE","閉じる");
define("EMEMBER_PROFILE_IMAGE", "プロフィール画像");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","ログインしていません");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "セキュアRSS");
define("EMEMBER_WRONG_RSS_URL","URLのフォーマットが正しくありません。");
define("EMEMBER_NO_USER_KEY","フィードキーが正しくありません。");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "一日の閲覧記事の上限回数を超えました。");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "アカウントステータス:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "アカウント有効期限:");
define("EMEMBER_EMAIL_BLACKLISTED","入力されたメールアドレスはブロックされています。 <br/>
        		       このメールIDでは登録ができません。 <br/>管理者にお問い合わせください。");
define("EMEMBER_IP_BLACKLISTED","IPアドレスががブロックされています。 <br/>
		       登録することができません。 <br/>管理者にお問い合わせください。");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "記憶させる");
define("EMEMBER_NEVER", "キャンセルまで有効");
define('EMEMBER_ACTIVE','利用中');
define('EMEMBER_INACTIVE','停止中');
define('EMEMBER_EXPIRED','期限切れ');
define('EMEMBER_PENDING','保留中');
define('EMEMBER_UNSUBSCRIBED','未購読');
define('EMEMBER_VISIT_PAYMENT_PAGE','メンバーになるには、お支払手続きに進む必要があります。');
define('EMEMBER_CLICK','クリック');
define('EMEMBER_HERE','こちら');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "ようこそ");
define("EMEMBER_NOT_A_MEMBER_TEXT", "メンバーではありませんか?");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "受信メールを確認して、残りの登録作業を完了させてください。");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "メールアドレスは必須項目です。");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "すべての項目を入力する必要があります。");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "パスワードを再度入力してください。");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'ユーザー名が空白です。');
define('EMEMBER_USERNAME_4_CHARS', '4文字以上のユーザー名を指定してください。');
define('EMEMBER_EMAIL_NOT_EMPTY','メールアドレスが空白です。');
define('EMEMBER_INVALID_EMAIL','不正なメールアドレスです。');
define('EMEMBER_PASSWORD_EMPTY','パスワードが空白です。');
define('EMEMBER_USERNAME_TAKEN','このユーザー名は既に使われています。');
define('EMEMBER_USERNAME_AVAIL','このユーザー名は無効です。');
define('EMEMBERR_WAIT','確認中です。しばらくお待ちください。');
define('EMEMBER_REQUIRED','入力必須項目です。');
define('EMEMBER_MIN','ユーザー名は');
define('EMEMBER_ALLOWED_CHAR_TEXT', '文字以上にしてください。');
define('EMEMBER_FIELD_MISMATCH','フィールドが一致しません。');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','英数文字とアンダースコアのみを使用することができます。');
define('EMEMBER_PASSWORD_MISMATCH','パスワードが一致しません。');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','パスワードが変更されました。一旦ログアウトしてから再度、新しいパスワードでログインしてください。');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','ユーザープロフィール');
define('EMEMBER_AUTH_REQUIRED','ユーザー認証が必要です');
define('EMEMBER_PROTECTED_BY','パスワードで保護されています');
define('EMEMBER_SIGNIN','サインインして');
define('EMEMBER_TO_COMMENT', ' コメントを入力します。');
define('EMEMBER_WAIT', 'しばらくお待ちください。');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','更新またはアップグレード');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','セッションがタイムアウトになりました。再度ログインして下さい。');
define('EMEMBER_USER_PASS_EMPTY','ユーザー名/パスワードが空白です。');
define('EMEMBER_TERMS_WARNING', '登録前に利用規約をお読みください。');
define("EMEMBER_ACCEPT", "利用規約に合意して登録します。");
define('EMEMBER_TERMS_CONDITIONS', '(利用規約)');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "メールアドレスを確認するために、以下の内容を入力してください。メールアドレスの確認後、ユーザー登録を続行することができます。");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Mr');
define('EMEMBER_MRS','Mrs');
define('EMEMBER_MISS','Miss');
define('EMEMBER_MS','Ms');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">コメントを読むために必要な権限がありません。</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','内容を読むために必要な権限がありません。');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', '検索');
define('EMEMBER_PREV', '前へ');
define('EMEMBER_NEXT', '次へ');
define('EMEMBER_SEARCH', '検索');
define('EMEMBER_DATA_NOT_FOUND', 'データがみつかりません。');
define('EMEMBER_ALREADY_LOGGED_IN','他のブラウザから、同一ユーザー名でログインされたため、自動的にログアウトしました。');
define('EMEMBER_WELCOME_PAGE', 'フロントページ');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "削除");
define('EMEMBER_UPLOAD', 'アップロード');
define('EMEMBER_ACTION', '実行');
define('EMEMBER_DETAILS','詳細');
define('EMEMBER_DELETE_ACC','アカウントを削除する');
define('EMEMBER_MEMBER_SINCE','メンバー登録日:');
define('EMEMBER_USER','ユーザー');
define('EMEMBER_USERS','ユーザー');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','キャプチャコードを入力してください');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','以下のフィールドは空白のままにしてください');
define('EMEMBER_CAPTCHA_FAILED','キャプチャ認証に失敗しました');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','1つのみ選択してください');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','ブックマーク');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','キャプチャ認証に失敗しました。もう一度入力してください。');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','ご登録ありがとうございます。管理者がアカウントの承認を行ってからご利用いただけます。');
define("EMEMBER_ACCOUNT_PENDING","このアカウントは管理者の承認待ちです");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','この内容でよろしいですか? ');
define('EMEMBER_YES','はい');
define('EMEMBER_NO','いいえ');
define('EMEMBER_REDIRECTION_MESSAGE','ページのリダイレクト中です。しばらくお待ちください。');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','メンバーシップレベルを更新しました。');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','メンバーシップをアップグレードするには、ログインして下さい。');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','ユーザーアカウントが有効になりました。');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','ご登録いただいたユーザーアカウントが有効になりました。ログインしてサイトをお使いいただけます。');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "英数文字かアンダースコア、メールアドレスを入力することができます。 ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','再度、プロフィールを編集する。');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','セッションがタイムアウトしました。');
define('EMEMBER_LOGIN_AGAIN', '再度、ログインして下さい。');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'メンバーシップレベル');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'ご登録いただいた時点より、以前に掲載され内容のため、必要な権限が与えられていません。');
define('EMEMBER_EMAIL_MISMATCH', 'メールアドレスが一致していません');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'エラー！このUSLはすでに使用されているか、期限切れです。');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','削除します');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');

