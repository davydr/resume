<?php
define("EMEMBER_MORE_LINK","Les mer");
define("EMEMBER_LEVEL_NOT_ALLOWED","Du har ikke riktig medlemskap for å vise dette innholdet.");
define("EMEMBER_CONTENT_RESTRICTED","Du har ikke tilgang til å vise dette innholdet.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Du har ikke riktig medlemskap for å vise dette innholdet");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Dette innholdet vises kun for innloggede medlemmer");
define("EMEMBER_MEMBER_LOGIN",'Medlemssider');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Medlemskapet ditt har utløpt. ");
define("EMEMBER_LOGIN","Logg inn");
define("EMEMBER_RENEW", "Forny");
define("EMEMBER_UPGRADE", "Oppgrader");
define("EMEMBER_TO_VIEW_CONTENT", "for å vise dette innholdet. ");
define("EMEMBER_PLEASE", "Vennligst");
define("EMEMBER_JOIN","Bli medlem nå!");
define("EMEMBER_NON_MEMBER", "- Er du ikke medlem?");
define("EMEMBER_YOUR_ACCOUNT", " din konto.");
define("EMEMBER_PROFILE_MESSAGE","Logg inn for å få tilgang til kontodetaljer.");
define("EMEMBER_LOGGED_IN_AS", "Hei, ");
define("EMEMBER_LOGGED_IN_LEVEL", "Medlemskap: ");
define("EMEMBER_LOGOUT", "Logg ut");
define("EMEMBER_EDIT_PROFILE", "Din profil");
define("EMEMBER_SUPPORT_PAGE","Supportsider");
define("EMEMBER_BOOKMARK_DISABLED", "Muligheten for å legge til favorittsider er ikke aktivert.");
define("EMEMBER_NO_BOOKMARK", "Du har ikke lagt til noen favoritter ennå.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Logg inn for å se favorittene dine.");
define("EMEMBER_FORGOT_PASS","Glemt passord?");
define("EMEMBER_JOIN_US","Bli medlem");
define("EMEMBER_USER_NAME", "Brukernavn / e-post");
define("EMEMBER_PASSWORD", "Passord");
define("EMEMBER_USER_NAME_TAKEN", "Dette brukernavnet finnes allerede! <br/>Velg et annet.");
define("EMEMBER_EMAIL_TAKEN", "Det finnes allerede en konto med denne epostadressen! <br/>Velg en annen eller logg inn. ");
define("EMEMBER_REG_COMPLETE", "Registreringen er fullført! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Ny medlemsregistrering");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Du har fått en ny medlem. Følgende mail ble sendt til vedkommende:");
define("EMEMBER_USER_PASS_MSG", "Velg brukernavn og passord for å fortsette ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Dette nettstedet tilbyr ikke gratis medlemskap!");
define("EMEMBER_EMAIL_UNAVAIL","Denne epostadressen er ikke tilgjengelig!");
define("EMEMBER_PROFILE_UPDATED","Din profil er nå oppdatert!");
define("EMEMBER_EMAIL_INVALID","Epostadressen ser ikke ut til å stemme.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Kontoen er inaktiv.");
define("EMEMBER_WRONG_PASS","Feil passord.");
define("EMEMBER_WRONG_USER_PASS", "Feil brukernavn / passord.");
define("EMEMBER_LOGOUT_SUCCESS", "Du har nå logget ut. ");
define("EMEMBER_ADDED", "Lagt til");
define("EMEMBER_FAVORITE", "Favoritt");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Ditt medlemskap");
define("EMEMBER_PASS_EMAILED_MSG","Du har fått tilsendt nytt passord på epost.");
define("EMEMBER_EMAIL_NOT_EXIST","Denne epostadressen er ikke registrert hos oss.");
define("EMEMBER_ALREADY_TAKEN","Beklager. Noe tok det før deg.");
define("EMEMBER_STILL_AVAIL","Så flott! Dette er fortsatt tilgjengelig.");
define("EMEMBER_WP_TAKEN","Beklager. Brukernavnet er allerede opptatt i Wordpressregisteret.");
define('EMEMBER_TITLE','Tittel');
define("EMEMBER_FIRST_NAME","Fornavn");
define("EMEMBER_LAST_NAME","Etternavn");
define("EMEMBER_EMAIL","Epost");
define("EMEMBER_MEMBERSHIP_LEVEL","Type medlemskap");
define("EMEMBER_USERNAME","Brukernavn");
define("EMEMBER_COMPANY","Firma");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Adresse");
define("EMEMBER_ADDRESS_CITY","Poststed");
define("EMEMBER_ADDRESS_STATE","Fylke");
define("EMEMBER_ADDRESS_ZIP","Postnummer");
define("EMEMBER_ADDRESS_COUNTRY","Land");
define("EMEMBER_GENDER","Kjønn");
define("EMEMBER_GENDER_MALE","Mann");
define("EMEMBER_GENDER_FEMALE","Kvinne");
define("EMEMBER_GENDER_UNSPECIFIED","Ikke spesifisert");
define("EMEMBER_REGISTRATION","Registrer");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","La stå blank hvis du vil beholde nåværende passord.");
define("EMEMBER_UPDATE", "Oppdater");
define("EMEMBER_ADD","Legg til");
define("EMEMBER_ADD_FAV","Lagre som favoritt");
define("EMEMBER_BOOKMARK","Bokmerke");
define("EMEMBER_LOGIN_TO_BOOKMARK","Logg inn for å legge til som bokmerke.");
define("EMEMBER_PASS_RESET","Tilbakestill glemt passord");
define("EMEMBER_PASS_RESET_MSG","Skriv inn epostadressen dersom du vil ha tilsendt nytt passord");
define("EMEMBER_RESET","Send");
define("EMEMBER_CLOSE","Lukk");
define("EMEMBER_PROFILE_IMAGE", "Profilbilde");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Du er ikke logget inn.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "My Secure RSS");
define("EMEMBER_WRONG_RSS_URL","Beklager. Nettadressen ser ikke ut til og finnes.");
define("EMEMBER_NO_USER_KEY","Beklager. Det ser ikke ut til at denne var valid!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Beklager. Du har logget inn for mange ganger i dag.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Status:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Varighet:");
define("EMEMBER_EMAIL_BLACKLISTED","Epostadressen din er svartelistet. <br/>
        		        <br/>Ta kontakt hvis du har spørmål.");
define("EMEMBER_IP_BLACKLISTED","Din IP-adresse er svartelistet. <br/>
		        <br/>Ta kontakt hvis du har spørsmål.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Husk meg");
define("EMEMBER_NEVER", "inntil utmelding");
define('EMEMBER_ACTIVE','aktiv');
define('EMEMBER_INACTIVE','inaktiv');
define('EMEMBER_EXPIRED','utløpt');
define('EMEMBER_PENDING','avventende');
define('EMEMBER_UNSUBSCRIBED','melde deg ut');
define('EMEMBER_VISIT_PAYMENT_PAGE' , 'Gå til betalingssidene for å betale');
define('EMEMBER_CLICK','Trykk');
define('EMEMBER_HERE','her');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Hei, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " for tilgang. <br/>Er du ikke medlem? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Gå til eposten din for å fullføre registreringen.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Du må oppgi en epostadresse!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Du må fylle ut alle feltene!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Gjenta");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'du må oppgi et brukernavn.');
define('EMEMBER_USERNAME_4_CHARS', 'brukernavnet må være over 4 bokstaver');
define('EMEMBER_EMAIL_NOT_EMPTY','du må oppgi en epostadresse');
define('EMEMBER_INVALID_EMAIL','epostadressen er ikke valid');
define('EMEMBER_PASSWORD_EMPTY','Du må oppgi et passord');
define('EMEMBER_USERNAME_TAKEN','Brukernavnet finnes fra før');
define('EMEMBER_USERNAME_AVAIL','Brukernavnet er ledig');
define('EMEMBERR_WAIT','Validerer. Vennligst vent');
define('EMEMBER_REQUIRED','Obligatorisk');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'må innholde tegn');
define('EMEMBER_FIELD_MISMATCH','Feltene samsvarer ikke med hverandre');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Kun bokstaver, tall og understrek er tillatt.');
define('EMEMBER_PASSWORD_MISMATCH','Passordene samsvarer ikke.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Når du endrer passord bør du logge inn på nytt før du fortsetter.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Profil');
define('EMEMBER_AUTH_REQUIRED','Autorisering kreves');
define('EMEMBER_PROTECTED_BY','Tilsyn av');
define('EMEMBER_SIGNIN','Logg inn');
define('EMEMBER_TO_COMMENT', ' for å kommentere');
define('EMEMBER_WAIT', 'vent');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Forny eller oppgrader');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Du har vært inaktiv for lenge. Logg inn igjen.');
define('EMEMBER_USER_PASS_EMPTY','Fyll inn brukernavn / passord!');
define('EMEMBER_TERMS_WARNING', 'Du må godta betingelsene for å fortsette.');
define("EMEMBER_ACCEPT", "Jeg aksepterer ");
define('EMEMBER_TERMS_CONDITIONS', 'betingelsene.');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Fyll inn epostadressen din. Etter at du har bekreftet denne kan du opprette konto.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Herr');
define('EMEMBER_MRS','Fru');
define('EMEMBER_MISS','Frøken');
define('EMEMBER_MS','Fru');
define('EMEMBER_DR','Dr.');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Du har ikke rettighet til å vise kommentaren</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Ditt medlemsnivå har ikke tilgang til dette innholdet.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Søk');
define('EMEMBER_PREV', 'Forrige');
define('EMEMBER_NEXT', 'Neste');
define('EMEMBER_SEARCH', 'Søk');
define('EMEMBER_DATA_NOT_FOUND', 'Vi fant ikke det du søkte etter.');
define('EMEMBER_ALREADY_LOGGED_IN','Du ble logget ut fordi noen andre har prøvd å logge inn fra en annen plass.');
define('EMEMBER_WELCOME_PAGE', 'Velkommen');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Slett");
define('EMEMBER_UPLOAD', 'Last opp');
define('EMEMBER_ACTION', 'Handling');
define('EMEMBER_DETAILS','Detaljer');
define('EMEMBER_DELETE_ACC','Slett konoten for godt');
define('EMEMBER_MEMBER_SINCE','Medlem siden');
define('EMEMBER_USER','Bruker');
define('EMEMBER_USERS','brukere');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Skriv inn bildekoden');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','La dette feltet stå tomt');
define('EMEMBER_CAPTCHA_FAILED','Bildekoden samsvarte ikke med bildet');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Velg...');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Bokmerke');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Bildekoden samsvarte ikke med bildet. Prøv igjen');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Takk for at du registrerte deg. Du kan logge inn så snart vi har godkjent medlemskapet ditt.');
define("EMEMBER_ACCOUNT_PENDING","Medlemskapet venter på godkjenning.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Er du sikker? ');
define('EMEMBER_YES','Ja');
define('EMEMBER_NO','Ner');
define('EMEMBER_REDIRECTION_MESSAGE','Du blir videresendt. ...vennligst vent.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Medlemskapet ditt er oppdatert.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Du må være innlogget for å endre medlemskapet ditt.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Kontoen din har nå blitt aktivert.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Hei. Kontoen din er aktivert. Du kan nå logge inn for full tilgang.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Kun bokstaver, tall og understrek er tillatt. ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Gå tilbake til profilen din');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Du har vært inaktiv for lenge.');
define('EMEMBER_LOGIN_AGAIN', 'Vennligst logg inn på nytt');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Dette innholdet ble publisert før du ble medlem, og du har derfor ikke tilgang på det.');
define('EMEMBER_RETYPE_EMAIL', 'Retype Email');
define('EMEMBER_EMAIL_MISMATCH', 'Email field mismatch');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Error! The unique registration code you used in the URL has already been used or it is invalid!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Remove');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');

