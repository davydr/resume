<?php
define("EMEMBER_MORE_LINK","Lue lisää");
define("EMEMBER_LEVEL_NOT_ALLOWED","Jäsenyytesi ei salli pääsyä tähän sisältöön.");
define("EMEMBER_CONTENT_RESTRICTED","Sinulla ei ole oikeutta katsella tätä sisältöä.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Jäsenyytesi ei salli pääsyä tähän sisältöön. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Tämä sisältö on tarkoitettu vain jäsenille.");
define("EMEMBER_MEMBER_LOGIN",'Jäsenen sisäänkirjautuminen');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Jäsenyytesi on päättynyt. ");
define("EMEMBER_LOGIN","Kirjaudu sisään");
define("EMEMBER_RENEW", "Uudista jäsenyytesi");
define("EMEMBER_UPGRADE", "Siirrä uudelle jäsenyystasolle");
define("EMEMBER_TO_VIEW_CONTENT", "katsellaksesi tätä sisältöä. ");
define("EMEMBER_PLEASE", "Ole hyvä ja");
define("EMEMBER_JOIN","Rekisteröidy nyt!");
define("EMEMBER_NON_MEMBER", "Etkö ole jäsen?");
define("EMEMBER_YOUR_ACCOUNT", " tilisi.");
define("EMEMBER_PROFILE_MESSAGE","Kirjaudu sisään muokataksesi tietojasi.");
define("EMEMBER_LOGGED_IN_AS", "Olet kirjautuneena nimellä: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Jäsenyystasosi on: ");
define("EMEMBER_LOGOUT", "Kirjaudu ulos");
define("EMEMBER_EDIT_PROFILE", "Muokkaa tietojasi");
define("EMEMBER_SUPPORT_PAGE","Tukisivusto");
define("EMEMBER_BOOKMARK_DISABLED", "Kirjanmerkkiominaisuus on poissa käytöstä.");
define("EMEMBER_NO_BOOKMARK", "Suosikkilistallasi ei ole vielä kohteita.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Kirjaudu sisään nähdäksesi kirjanmerkkilistasi.");
define("EMEMBER_FORGOT_PASS","Unohditko salasanasi?");
define("EMEMBER_JOIN_US","Rekisteröidy");
define("EMEMBER_USER_NAME", "Käyttäjätunnus");
define("EMEMBER_PASSWORD", "Salasana");
define("EMEMBER_USER_NAME_TAKEN", "Antamasi käyttäjätunnus on varattu! <br/>Anna uusi käyttäjätunnus.");
define("EMEMBER_EMAIL_TAKEN", "Antamasi sähköpostiosoite on jo käytössä!  <br/>Anna toinen sähköpostiosoite. ");
define("EMEMBER_REG_COMPLETE", "Rekisteröityminen on valmis! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Uuden jäsenen rekisteröityminen");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Uusi jäsen on rekisteröitynyt ja hänelle on lähetetty alla oleva viesti.");
define("EMEMBER_USER_PASS_MSG", "Viimeistele rekisteröitymisesi luomalla itsellesi käyttäjätunnus ja salasana. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Ilmainen jäsenyys ei ole käytössä tällä sivustolla!");
define("EMEMBER_EMAIL_UNAVAIL","Tämä sähköpostitunnus ei ole käytettävissä!");
define("EMEMBER_PROFILE_UPDATED","Tietosi on päivitetty!");
define("EMEMBER_EMAIL_INVALID","Virheellinen sähköpostiosoite.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Tämä tili on poissa käytöstä.");
define("EMEMBER_WRONG_PASS","Virheellinen salasana.");
define("EMEMBER_WRONG_USER_PASS", "Virheellinen käyttäjätunnus tai salasana.");
define("EMEMBER_LOGOUT_SUCCESS", "Uloskirjautuminen onnistui. ");
define("EMEMBER_ADDED", "Lisätty");
define("EMEMBER_FAVORITE", "Suosikki");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Jäsentietosi");
define("EMEMBER_PASS_EMAILED_MSG","Uusi salasanasi on lähetetty sinulle sähköpostitse.");
define("EMEMBER_EMAIL_NOT_EXIST","Tällä sähköpostiosoitteella ei löydy käyttäjää.");
define("EMEMBER_ALREADY_TAKEN","Pahoittelut! Tämä tunnus on varattu.");
define("EMEMBER_STILL_AVAIL","Tämä on vielä vapaana.");
define("EMEMBER_WP_TAKEN","Pahoittelut! Tämä on jo Wordpressin käytössä.");
define('EMEMBER_TITLE','Otsikko');
define("EMEMBER_FIRST_NAME","Etunimi");
define("EMEMBER_LAST_NAME","Sukunimi");
define("EMEMBER_EMAIL","Sähköpostiosoite");
define("EMEMBER_MEMBERSHIP_LEVEL","Jäsenyystaso");
define("EMEMBER_USERNAME","Käyttäjätunnus");
define("EMEMBER_COMPANY","Yritys");
define("EMEMBER_PHONE","Puhelin");
define("EMEMBER_ADDRESS_STREET","Katuosoite");
define("EMEMBER_ADDRESS_CITY","Kaupunki");
define("EMEMBER_ADDRESS_STATE","Osavaltio/maakunta");
define("EMEMBER_ADDRESS_ZIP","Postinumero");
define("EMEMBER_ADDRESS_COUNTRY","Maa");
define("EMEMBER_GENDER","Sukupuoli");
define("EMEMBER_GENDER_MALE","Mies");
define("EMEMBER_GENDER_FEMALE","Nainen");
define("EMEMBER_GENDER_UNSPECIFIED","Ei määritelty");
define("EMEMBER_REGISTRATION","Rekisteröidy");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Jätä tyhjäksi jos haluat säilyttää nykyisen salasanasi.");
define("EMEMBER_UPDATE", "Päivitä");
define("EMEMBER_ADD","Lisää");
define("EMEMBER_ADD_FAV","Lisää suosikiksi");
define("EMEMBER_BOOKMARK","Kirjanmerkki");
define("EMEMBER_LOGIN_TO_BOOKMARK","Kirjaudu sisään tallentaaksesi kirjanmerkkejä.");
define("EMEMBER_PASS_RESET","Salasanan palautus");
define("EMEMBER_PASS_RESET_MSG","Anna sähköpostiosoitteesi. Uusi salasana lähetetään tähän sähköpostiosoitteeseen.");
define("EMEMBER_RESET","Palauta");
define("EMEMBER_CLOSE","Sulje");
define("EMEMBER_PROFILE_IMAGE", "Profiilikuva");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Ei kirjautuneena.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Suojattu RSS");
define("EMEMBER_WRONG_RSS_URL","Pahoittelut! Tämän URL-osoitteen muoto on virheellinen.");
define("EMEMBER_NO_USER_KEY","Pahoittelut! Avain ei vaikuta oikealta.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Päivittäisten kirjautumistesi yläraja on täyttynyt.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Tilisi tila:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Tilisi käyttöoikeus umpeutuu:");
define("EMEMBER_EMAIL_BLACKLISTED","Sähköpostiosoitteesi on estetty. <br/>
        		       Et voi rekisteröityä tällä sähköpostiosoitteella.  <br/>Ota yhteys sivuston ylläpitäjään.");
define("EMEMBER_IP_BLACKLISTED","IP-osoitteesi on estetty. <br/>
		       Et voi rekisteröityä tälle sivustolle.  <br/>Ota yhteys sivuston ylläpitäjään.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Muista minut");
define("EMEMBER_NEVER", "Kunnes peruutetaan");
define('EMEMBER_ACTIVE','aktiivinen');
define('EMEMBER_INACTIVE','poissa käytöstä');
define('EMEMBER_EXPIRED','umpeutunut');
define('EMEMBER_PENDING','odottaa hyväksymistä');
define('EMEMBER_UNSUBSCRIBED','peruuttanut tilauksensa');
define('EMEMBER_VISIT_PAYMENT_PAGE','Käy maksusivulla maksamassa jäsenyytesi');
define('EMEMBER_CLICK','Klikkaa');
define('EMEMBER_HERE','tästä');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Hei, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", ". Etkö ole jäsen? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Viimeistele rekisteröitymisesi klikkaamalla sähköpostiisi lähetettyä linkkiä.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Sinun on annettava sähköpostiosoite!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Sinun on täytettävä kaikki kentät!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Salasana uudelleen");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'käyttäätunnus ei voi olla tyhjä.');
define('EMEMBER_USERNAME_4_CHARS', 'käyttäjätunnuksen tulisi olla pitempi kuin 4 merkkiä');
define('EMEMBER_EMAIL_NOT_EMPTY','sähköpostiosoite ei voi olla tyhjä');
define('EMEMBER_INVALID_EMAIL','sähköpostiosoite ei ole kelvollinen');
define('EMEMBER_PASSWORD_EMPTY','Salasana-kenttä ei voi olla tyhjä');
define('EMEMBER_USERNAME_TAKEN','Tämä käyttäjätunnus on varattu');
define('EMEMBER_USERNAME_AVAIL','Tämä nimi on vapaana');
define('EMEMBERR_WAIT','Odota hetki, kun tarkistamme käyttöoikeutesi');
define('EMEMBER_REQUIRED','Tämä tieto on pakollinen');
define('EMEMBER_MIN','Vähintään');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'merkkiä vaaditaan');
define('EMEMBER_FIELD_MISMATCH','Tiedot eivät täsmää');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Sallittuja merkkejä ovat kirjaimet, numerot ja alaviiva.');
define('EMEMBER_PASSWORD_MISMATCH','Salasana ei täsmää.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Vaihdoit salasanasi. Suosittelemme että kirjaudut ulos ja uudelleen sisään käyttäen uutta salasanaasi.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Käyttäjäprofiili');
define('EMEMBER_AUTH_REQUIRED','Tunnistautuminen vaaditaan');
define('EMEMBER_PROTECTED_BY','Suojattu');
define('EMEMBER_SIGNIN','Kirjaudu sisään');
define('EMEMBER_TO_COMMENT', ' jättääksesi kommentin');
define('EMEMBER_WAIT', 'odota');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Uudista tai päivitä');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Kirjautumisesi on vanhentunut. Kirjaudu uudelleen.');
define('EMEMBER_USER_PASS_EMPTY','Käyttäjätunnus/Salasana -kentät eivät voi olla tyhjiä!');
define('EMEMBER_TERMS_WARNING', 'Hyväksy sivuston käyttöehdot voidaksesi rekisteröityä.');
define("EMEMBER_ACCEPT", "Hyväksyn ");
define('EMEMBER_TERMS_CONDITIONS', 'sivuston käyttöehdot');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Täytä alla olevat tiedot. Vahvistuslinkki lähetetään antamaasi sähköpostiosoitteeseen.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Herra');
define('EMEMBER_MRS','Rouva');
define('EMEMBER_MISS','Neiti');
define('EMEMBER_MS','Ms');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Sinulla ei ole riittäviä oikeuksia nähdäksesi kommentteja.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Tililläsi ei ole pääsyoikeutta tähän sisältöön.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Hakusana');
define('EMEMBER_PREV', 'Edellinen');
define('EMEMBER_NEXT', 'Seuraava');
define('EMEMBER_SEARCH', 'Haku');
define('EMEMBER_DATA_NOT_FOUND', 'Tietoa ei löytynyt.');
define('EMEMBER_ALREADY_LOGGED_IN','Sinut on uloskirjattu koska toinen käyttäjä on kirjautuneena tälle tilille toisella selaimella.');
define('EMEMBER_WELCOME_PAGE', 'Tervetuloa-sivu');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Poista");
define('EMEMBER_UPLOAD', 'Lataa');
define('EMEMBER_ACTION', 'Toiminta');
define('EMEMBER_DETAILS','Tiedot');
define('EMEMBER_DELETE_ACC','Poista tili');
define('EMEMBER_MEMBER_SINCE','Jäsenyys alkoi');
define('EMEMBER_USER','Käyttäjä');
define('EMEMBER_USERS','Käyttäjät');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Anna captcha-koodi');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Pidä seuraava kenttä tyhjänä');
define('EMEMBER_CAPTCHA_FAILED','Captchan tunnistus epäonnistui');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Valitse yksi');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Kirjanmerkit');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Captchan tunnistus epäonnistui. Yritä uudelleen.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Kiitos rekisteröitymisestäsi! Tilisi odottaa hyväksymistä.');
define("EMEMBER_ACCOUNT_PENDING","Tämä tili odottaa hyväksymistä.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Oletko varma? ');
define('EMEMBER_YES','Kyllä');
define('EMEMBER_NO','Ei');
define('EMEMBER_REDIRECTION_MESSAGE','Odota hetki... uudelleenohjaus on meneillään.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Jäsenyystaso on päivitetty.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Sinun on oltava kirjautuneena voidaksesi muokata jäsenyyttäsi.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Käyttäjätilisi on aktivoitu.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Hei, Tilisi on aktivoitu. Voit nyt kirjautua sivustolle.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', 'Kirjaimet, numerot, alaviiva ja sähköpostiosoite on sallittu');
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Muokkaa profiiliasi uudelleen');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Istuntosi on vanhentunut');
define('EMEMBER_LOGIN_AGAIN', 'Kirjaudu uudelleen');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Jäsenyystaso');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Tämä sisältö on julkaistu ennen liittymistäsi tälle sivustolle. Sinulla ei ole oikeutta katsella tätä sisältöä.');
define('EMEMBER_RETYPE_EMAIL', 'Sähköpostiosoite uudelleen');
define('EMEMBER_EMAIL_MISMATCH', 'Sähköpostikentät eivät täsmää');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Virhe! URL-osoitteen yksilöllinen rekisteröintitunnus on jo käytetty tai virheellinen!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Poista');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');

