<?php
define("EMEMBER_MORE_LINK","Pokračovať v čítaní");
define("EMEMBER_LEVEL_NOT_ALLOWED","Váš typ členstva vám neumožňuje zobraziť zvyšok obsahu.");
define("EMEMBER_CONTENT_RESTRICTED","Nemáte oprávnenie na zobrazenie tohto obsahu.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Váš typ členstva nemá prístup k tomuto obsahu. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Tento obsah je určený iba pre registrovaných používateľov.");
define("EMEMBER_MEMBER_LOGIN",'Prihlásenie užívateľa');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Platnosť vašeho predplatného vypršala. ");
define("EMEMBER_LOGIN","Prihlásiť sa");
define("EMEMBER_RENEW", "Obnoviť");
define("EMEMBER_UPGRADE", "Prejsť na vyššiu úroveň");
define("EMEMBER_TO_VIEW_CONTENT", "zobraziť tento obsah.");
define("EMEMBER_PLEASE", "Prosím");
define("EMEMBER_JOIN","Pripojte sa k nám ešte dnes!");
define("EMEMBER_NON_MEMBER", "Nie ste členom?");
define("EMEMBER_YOUR_ACCOUNT", " váš účet.");
define("EMEMBER_PROFILE_MESSAGE","Ak chcete upraviť svoj profil, prosím, prihláste sa.");
define("EMEMBER_LOGGED_IN_AS", "Ste prihlásení ako: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Úroveň vášho členstva je:");
define("EMEMBER_LOGOUT", "Odhlásiť sa");
define("EMEMBER_EDIT_PROFILE", "Upraviť Profil");
define("EMEMBER_SUPPORT_PAGE","Support Page");
define("EMEMBER_BOOKMARK_DISABLED", "Funkcia Záložky je deaktivovaná.");
define("EMEMBER_NO_BOOKMARK", "Do zoznamu obľúbených položiek ste zatiaľ nič nepridali.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Ak chcete zobraziť zoznam záložiek, musíte sa prihlásiť.");
define("EMEMBER_FORGOT_PASS","Zabudli ste heslo?");
define("EMEMBER_JOIN_US","Pridajte sa k nám");
define("EMEMBER_USER_NAME", "Užívateľské meno");
define("EMEMBER_PASSWORD", "Heslo");
define("EMEMBER_USER_NAME_TAKEN", "Používateľské meno, ktoré používate, je už obsadené! <br/> Prosím vyberte iné meno.");
define("EMEMBER_EMAIL_TAKEN", "E-mailová adresa, ktorú používate, je už obsadená! <br/> Prosím vyberte si inú e-mailovú adresu. ");
define("EMEMBER_REG_COMPLETE", "Registrácia prebehla úspešne! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Oznámenie o registrácii nového člena");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Zaregistroval sa nový člen. Členovi bol zaslaný nasledujúci e-mail.");
define("EMEMBER_USER_PASS_MSG", "Prosím, nižšie vyberte svoje užívateľské meno a heslo na dokončenie registrácie.");
define("EMEMBER_FREE_MEMBER_DISABLED", "Na tejto stránke je bezplatné členstvo vypnuté!");
define("EMEMBER_EMAIL_UNAVAIL","Toto e-mailové ID nie je k dispozícii!");
define("EMEMBER_PROFILE_UPDATED","Váš profil bol aktualizovaný!");
define("EMEMBER_EMAIL_INVALID","Neplatný email.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Tento účet je neaktívny.");
define("EMEMBER_WRONG_PASS","Nesrpávne Heslo.");
define("EMEMBER_WRONG_USER_PASS", "Nesprávne používateľské meno alebo heslo.");
define("EMEMBER_LOGOUT_SUCCESS", "Ste úspešne odhlásený. ");
define("EMEMBER_ADDED", "Pridané");
define("EMEMBER_FAVORITE", "Obľúbené");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Podrobnosti o vašom členstve");
define("EMEMBER_PASS_EMAILED_MSG","Vaše nové heslo vám bolo zaslané prostredníctvom e-mailu.");
define("EMEMBER_EMAIL_NOT_EXIST","Používateľ s touto e-mailovou adresou neexistuje.");
define("EMEMBER_ALREADY_TAKEN","Prepáčte! Používateľské meno je už obsadené.");
define("EMEMBER_STILL_AVAIL","Toto je stále k dispozícii.");
define("EMEMBER_WP_TAKEN","Prepáčte! Toto sa už používa vo Wordpresse.");
define('EMEMBER_TITLE','Oslovenie');
define("EMEMBER_FIRST_NAME","Meno");
define("EMEMBER_LAST_NAME","Priezvisko");
define("EMEMBER_EMAIL","Email");
define("EMEMBER_MEMBERSHIP_LEVEL","Členstvo");
define("EMEMBER_USERNAME","Používateľské meno");
define("EMEMBER_COMPANY","Názov firmy");
define("EMEMBER_PHONE","Telefónne číslo");
define("EMEMBER_ADDRESS_STREET","Ulica");
define("EMEMBER_ADDRESS_CITY","Mesto");
define("EMEMBER_ADDRESS_STATE","Štát");
define("EMEMBER_ADDRESS_ZIP","Poštové smerovacie čislo");
define("EMEMBER_ADDRESS_COUNTRY","Krajina");
define("EMEMBER_GENDER","Pohlavie");
define("EMEMBER_GENDER_MALE","Muž");
define("EMEMBER_GENDER_FEMALE","Žena");
define("EMEMBER_GENDER_UNSPECIFIED","Nechcem uviesť");
define("EMEMBER_REGISTRATION","Zaregistrovať sa");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Ak chcete ponechať aktuálne heslo, nechajte toto pole prázdne.");
define("EMEMBER_UPDATE", "Aktualizovať");
define("EMEMBER_ADD","Pridať");
define("EMEMBER_ADD_FAV","Pridať k obľúbeným");
define("EMEMBER_BOOKMARK","Záložka");
define("EMEMBER_LOGIN_TO_BOOKMARK","Prihláste sa do záložky.");
define("EMEMBER_PASS_RESET","Password Reset");
define("EMEMBER_PASS_RESET_MSG","Prosím, zadajte vašu e-mailovú adresu. Nové heslo vám bude zaslané prostredníctvom e-mailu.");
define("EMEMBER_RESET","Reset");
define("EMEMBER_CLOSE","Zatvoriť");
define("EMEMBER_PROFILE_IMAGE", "Obrázok profilu");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Nie ste prihlásený.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "My Secure RSS");
define("EMEMBER_WRONG_RSS_URL","Prepáčte! Adresa URL nie je správne naformátovaná.");
define("EMEMBER_NO_USER_KEY","Sorry! Feed Key Doesn't Look Valid!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Dosiahli ste váš limit prihlásení za deň.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Stav vášho účtu:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Platnosť vášho účtu vyprší:");
define("EMEMBER_EMAIL_BLACKLISTED","Vaša e-mailová adresa je na čiernej listine. <br/>Na túto e-mailovú adresu sa nebudete môcť zaregistrovať. <br/> Prosím, kontaktujte administrátora stránky.");
define("EMEMBER_IP_BLACKLISTED","Vaša IP adresa je na čiernej listine. <br/>
      nebudete sa môcť zaregistrovať. <br/>prosím kontaktujte administrátora.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Zapamätať si ma");
define("EMEMBER_NEVER", "Until Cancelled");
define('EMEMBER_ACTIVE','aktívny');
define('EMEMBER_INACTIVE','neaktívny');
define('EMEMBER_EXPIRED','vypršala platnosť');
define('EMEMBER_PENDING','pending');
define('EMEMBER_UNSUBSCRIBED','odhlásený');
define('EMEMBER_VISIT_PAYMENT_PAGE','Ak chcete zaplatiť za členstvo,prosím, navštívte stránku Platba');
define('EMEMBER_CLICK','Kliknite');
define('EMEMBER_HERE','Tu');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Dobrý deň, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " to start. Not a member? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Skontrolujte svoju e-mailovú adresu a kliknutím na odkaz dokončite registráciu.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Musíte zadať e-mailovú adresu!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Musíte vyplniť všetky polia!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Znovu zadajte heslo");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'meno používateľa nemôže byť prázdne.');
define('EMEMBER_USERNAME_4_CHARS', 'používateľské meno by nemalo mať menej ako 4 znaky');
define('EMEMBER_EMAIL_NOT_EMPTY','e-mail nemôže byť prázdny');
define('EMEMBER_INVALID_EMAIL','e-mailová adresa nie je platná');
define('EMEMBER_PASSWORD_EMPTY','Pole Heslo nemôže byť prázdne');
define('EMEMBER_USERNAME_TAKEN','Tento používateľ je už prijatý');
define('EMEMBER_USERNAME_AVAIL','Tento meno je k dispozícii');
define('EMEMBERR_WAIT','Schvaľúje sa, prosím počkajte');
define('EMEMBER_REQUIRED','Toto pole je povinné');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'požadované znaky');
define('EMEMBER_FIELD_MISMATCH','Polia sa nezhodujú');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Povolené sú iba písmená, čísla a podčiarknutia');
define('EMEMBER_PASSWORD_MISMATCH','Heslá sa nezhodujú');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Zmenili ste vaše heslo. Odporúčame vám odhlásiť sa a potom sa znovu prihlásiť pomocou nového hesla.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Užívateľský profil');
define('EMEMBER_AUTH_REQUIRED','Vyžaduje sa overenie');
define('EMEMBER_PROTECTED_BY','Protected by');
define('EMEMBER_SIGNIN','Prihlásiť sa');
define('EMEMBER_TO_COMMENT', ' uverejniť komentár');
define('EMEMBER_WAIT', 'čakajte');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Renew or Upgrade');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Vaša relácia vypršala. Prosím, prihláste sa znova.');
define('EMEMBER_USER_PASS_EMPTY','Pole pre meno a heslo nemôže byť prázdne!');
define('EMEMBER_TERMS_WARNING', 'Pre registráciu musíte prijať podmienky použivania.');
define("EMEMBER_ACCEPT", "Súhlasím");
define('EMEMBER_TERMS_CONDITIONS', 'Podmienky použivania');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Toto je predregistračný formulár. Najprv vyplňte nasledujúce údaje a overte svoju e-mailovú adresu. Po overení budete mať prístup k úplnému registračnému formuláru a zaregistrovaniu sa na účet.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Pán');
define('EMEMBER_MRS','Pani');
define('EMEMBER_MISS','Slečna');
define('EMEMBER_MS','Pani/Slečna');
define('EMEMBER_DR','Doktor');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Na zobrazenie komentárov nemáte povolenie.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Váš profil nemá prístup k tomuto obsahu.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Hľadaný výraz');
define('EMEMBER_PREV', 'Predchádzajúce');
define('EMEMBER_NEXT', 'Nasledujúci');
define('EMEMBER_SEARCH', 'Hľadať');
define('EMEMBER_DATA_NOT_FOUND', 'Neboli nájdené žiadne dáta.');
define('EMEMBER_ALREADY_LOGGED_IN','Boli ste odhlásený, pretože iný používateľ sa do tohto účtu prihlásil z iného prehliadača.');
define('EMEMBER_WELCOME_PAGE', 'Uvítacia stránka');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Odstrániť");
define('EMEMBER_UPLOAD', 'Nahrať');
define('EMEMBER_ACTION', 'Action');
define('EMEMBER_DETAILS','Podrobnosti');
define('EMEMBER_DELETE_ACC','Zrušiť úcet');
define('EMEMBER_MEMBER_SINCE','Používateľom od');
define('EMEMBER_USER','Používateľ');
define('EMEMBER_USERS','Používatelia');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Zadajte kód captcha');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Nasledujúce pole nechajte prázdne');
define('EMEMBER_CAPTCHA_FAILED','Overenie kódu Captcha zlyhalo');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Vyber jeden');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Záložky');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Overenie kódu Captcha zlyhalo. Prosím skúste znova.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Ďakujeme vám za registráciu. Váš účet čaká na schválenie administrátorom.');
define("EMEMBER_ACCOUNT_PENDING","This account is pending approval.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Ste si istý? ');
define('EMEMBER_YES','Áno');
define('EMEMBER_NO','Nie');
define('EMEMBER_REDIRECTION_MESSAGE','Čakajte prosím ... budete presmerovaný.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Membership level has been updated.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','You must be logged in to upgrade a membership.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Váš používateľský účet bol aktivovaný.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Dobrý deň, Váš účet bol aktivovaný. Teraz sa môžete prihlásiť na stránku.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', 'Povolené je písmeno, číslo, podčiarknutie alebo e-mail');
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Upraviť profil znova');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Platnosť relácie vypršala');
define('EMEMBER_LOGIN_AGAIN', 'Prosím, prihláste sa znova');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Úroveň členstva');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Tento obsah bol uverejnený predtým, ako ste sa k nám pridali. Na zobrazenie tohto obsahu nemáte povolenie.');
define('EMEMBER_RETYPE_EMAIL', 'Znovu zadajte Email');
define('EMEMBER_EMAIL_MISMATCH', 'Emaily sa nezhodujú');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Chyba! Jedinečný registračný kód, ktorý ste použili v adrese URL, už bol použitý alebo je neplatný!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Odstrániť');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Znak apostrofu nie je povolený.');
define('EMEMBER_SEND_VERIFICATION', 'Poslať verifikačný e-mail');

