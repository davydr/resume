<?php
define("EMEMBER_MORE_LINK","Nastavi");
define("EMEMBER_LEVEL_NOT_ALLOWED","Vaša članska razina ne omogućava da vidite ostatak sadržaja.");
define("EMEMBER_CONTENT_RESTRICTED","Nemate odobrenje da vidite ovaj sadržaj.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Vaša članska razina nema pristup ovom sadržaju. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Ovaj sadržaj je samo za članove.");
define("EMEMBER_MEMBER_LOGIN",'Prijava članova');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Vaša pretplata je istekla. ");
define("EMEMBER_LOGIN","Prijava");
define("EMEMBER_RENEW", "Obnovi");
define("EMEMBER_UPGRADE", "Nadogradi");
define("EMEMBER_TO_VIEW_CONTENT", "za pristup ovom sadržaju. ");
define("EMEMBER_PLEASE", "Molimo");
define("EMEMBER_JOIN","Registrirajte se!");
define("EMEMBER_NON_MEMBER", "Niste član?");
define("EMEMBER_YOUR_ACCOUNT", " vaš račun.");
define("EMEMBER_PROFILE_MESSAGE","Molimo prijavite se kako biste uredili vaš profil.");
define("EMEMBER_LOGGED_IN_AS", "Prijavljeni ste kao: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Vaša članska razina je: ");
define("EMEMBER_LOGOUT", "Odjava");
define("EMEMBER_EDIT_PROFILE", "Uredi profil");
define("EMEMBER_SUPPORT_PAGE","Stranica za pomoć");
define("EMEMBER_BOOKMARK_DISABLED", "Označavanje je onemogućeno.");
define("EMEMBER_NO_BOOKMARK", "Vi još niste ništa dodali u favorite.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Trebate se prijaviti da biste videli listu favorita.");
define("EMEMBER_FORGOT_PASS","Zaboravili ste lozinku?");
define("EMEMBER_JOIN_US","Pridružite nam se");
define("EMEMBER_USER_NAME", "Korisničko ime");
define("EMEMBER_PASSWORD", "Lozinka");
define("EMEMBER_USER_NAME_TAKEN", "Korisničko ime se već koristi! <br/>Molimo odaberite neko drugo.");
define("EMEMBER_EMAIL_TAKEN", "Email adresa se već koristi! <br/>Molimo odaberite neku drugu. ");
define("EMEMBER_REG_COMPLETE", "Registracija je dovršena! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Obavijest o registraciji novog člana");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Novi član je registriran. Članu je poslana slijedeća poruka.");
define("EMEMBER_USER_PASS_MSG", "Molimo odaberite korisničko ime i lozinku kako biste dovršili registraciju. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Besplatno članstvo na ovoj stranici je onemogućeno!");
define("EMEMBER_EMAIL_UNAVAIL","Ovaj email ID nije dostupan!");
define("EMEMBER_PROFILE_UPDATED","Vaš profil je ažuriran!");
define("EMEMBER_EMAIL_INVALID","Neispravna email adresa.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Ovaj račun je neaktivan.");
define("EMEMBER_WRONG_PASS","Pogrešna lozinka.");
define("EMEMBER_WRONG_USER_PASS", "Pogrešno korisničko ime ili lozinka.");
define("EMEMBER_LOGOUT_SUCCESS", "Odjava uspješna. ");
define("EMEMBER_ADDED", "Dodano");
define("EMEMBER_FAVORITE", "Favoriti");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Vaši članski podaci");
define("EMEMBER_PASS_EMAILED_MSG","Nova lozinka vam je poslana na email.");
define("EMEMBER_EMAIL_NOT_EXIST","Korisnik s ovom email adresom ne postoji.");
define("EMEMBER_ALREADY_TAKEN","Žao nam je! Korisničko ime se već koristi.");
define("EMEMBER_STILL_AVAIL","Ovo je dostupno.");
define("EMEMBER_WP_TAKEN","Žao nam je! Ovo se već koristi u WordPressu.");
define('EMEMBER_TITLE','Titula');
define("EMEMBER_FIRST_NAME","Ime");
define("EMEMBER_LAST_NAME","Prezime");
define("EMEMBER_EMAIL","Email");
define("EMEMBER_MEMBERSHIP_LEVEL","Članstvo");
define("EMEMBER_USERNAME","Korisničko ime");
define("EMEMBER_COMPANY","Tvrtka");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Ulica i broj");
define("EMEMBER_ADDRESS_CITY","Grad");
define("EMEMBER_ADDRESS_STATE","Županija ili pokrajina");
define("EMEMBER_ADDRESS_ZIP","Poštanski broj");
define("EMEMBER_ADDRESS_COUNTRY","Država");
define("EMEMBER_GENDER","Spol");
define("EMEMBER_GENDER_MALE","Muško");
define("EMEMBER_GENDER_FEMALE","Žensko");
define("EMEMBER_GENDER_UNSPECIFIED","Nije određeno");
define("EMEMBER_REGISTRATION","Registracija");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Ostavite prazno ako želite sačuvati postojeću lozinku.");
define("EMEMBER_UPDATE", "Ažuriraj");
define("EMEMBER_ADD","Dodaj");
define("EMEMBER_ADD_FAV","Dodaj u Favorite");
define("EMEMBER_BOOKMARK","Označi");
define("EMEMBER_LOGIN_TO_BOOKMARK","Prijavi se u oznake.");
define("EMEMBER_PASS_RESET","Resetiraj lozinku");
define("EMEMBER_PASS_RESET_MSG","Unesite email adresu. Vi ćete primiti novu lozinku na email.");
define("EMEMBER_RESET","Resetiraj");
define("EMEMBER_CLOSE","Zatvori");
define("EMEMBER_PROFILE_IMAGE", "Slika profila");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Niste prijavljeni.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Moj sigurni RSS");
define("EMEMBER_WRONG_RSS_URL","Žao nam je! URL nije pravilno formatiran.");
define("EMEMBER_NO_USER_KEY","Žao nam je! Feed ključ nije važeći!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Prešli ste dnevni limit prijava.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Status vašeg računa:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Vaš račun ističe:");
define("EMEMBER_EMAIL_BLACKLISTED","Vaša email adresa je na crnoj listi. <br/>Vi se ne možete registrirati s ovom email adresom. <br/>Please contact site admin.");
define("EMEMBER_IP_BLACKLISTED","Vaša IP adresa je na crnoj listi, <br/>vi se ne možete registrirati. <br/>Molimo kontaktirajte administratora.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Zapamti me");
define("EMEMBER_NEVER", "Do otkazivanja");
define('EMEMBER_ACTIVE','aktivno');
define('EMEMBER_INACTIVE','neaktivno');
define('EMEMBER_EXPIRED','isteklo');
define('EMEMBER_PENDING','čeka odobrenje');
define('EMEMBER_UNSUBSCRIBED','odjavljeno');
define('EMEMBER_VISIT_PAYMENT_PAGE','Molimo posjetite Stranicu za plaćanje kako biste platili za članstvo');
define('EMEMBER_CLICK','Kliknite');
define('EMEMBER_HERE','ovdje');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Pozdrav, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " za početak. Niste član? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Provjerite svoj dolazni email i slijedite link kako biste dovršili registraciju.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Morate unijeti email adresu!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Morate popuniti sva polja!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Ponovo upišite lozinku");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'korisničko ime ne može biti prazno.');
define('EMEMBER_USERNAME_4_CHARS', 'korisničko ime ne može biti manje od 4 znaka');
define('EMEMBER_EMAIL_NOT_EMPTY','email adresa ne može biti prazna');
define('EMEMBER_INVALID_EMAIL','email adresa nije valjana');
define('EMEMBER_PASSWORD_EMPTY','Polje za lozinku ne može biti prazno');
define('EMEMBER_USERNAME_TAKEN','Ovo korisničko ime je zauzeto');
define('EMEMBER_USERNAME_AVAIL','Ovo ime je dostupno');
define('EMEMBERR_WAIT','Provjera valjanosti, molimo sačekajte.');
define('EMEMBER_REQUIRED','Ovo polje je obavezno');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'znakova');
define('EMEMBER_FIELD_MISMATCH','Polja nisu identična');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Dozvoljeni su samo slova, brojevi i donja crta');
define('EMEMBER_PASSWORD_MISMATCH','Lozinke se ne poklapaju.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Promijenili ste lozinku. Molimo da se odjavite a zatim se ponovo prijavite s novom lozinkom.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Korisnički profil');
define('EMEMBER_AUTH_REQUIRED','Potrebna je autentikacija');
define('EMEMBER_PROTECTED_BY','Zaštićeno');
define('EMEMBER_SIGNIN','Prijavite se');
define('EMEMBER_TO_COMMENT', ' da unesete komentar');
define('EMEMBER_WAIT', 'sačekajte');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Obnovite ili Nadogradite članstvo');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Vaša sesija je istekla. Molimo prijavite se ponovo.');
define('EMEMBER_USER_PASS_EMPTY','Polja Korisničko ime/Lozinka ne mogu biti prazna!');
define('EMEMBER_TERMS_WARNING', 'Trebate prihvatiti uvjete i odredbe za registraciju.');
define("EMEMBER_ACCEPT", "Prihvaćam ");
define('EMEMBER_TERMS_CONDITIONS', 'Uvjete i Odredbe');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Ispunite slijedeće podatke za verifikaciju vaše email adrese. Vi ćete se moći registrirati nakon verifikacije.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Gdin');
define('EMEMBER_MRS','Gđa');
define('EMEMBER_MISS','Gđica');
define('EMEMBER_MS','Mg');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Nemate dopuštenje da vidite komentare.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Vaš profil nema pristup ovom sadržaju.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Pojam za pretraživanje');
define('EMEMBER_PREV', 'Prethodno');
define('EMEMBER_NEXT', 'Slijedeće');
define('EMEMBER_SEARCH', 'Traži');
define('EMEMBER_DATA_NOT_FOUND', 'Ništa nije pronađeno.');
define('EMEMBER_ALREADY_LOGGED_IN','Vi ste odjavljeni jer se drugi korisnik prijavio u ovaj račun s drugog preglednika.');
define('EMEMBER_WELCOME_PAGE', 'Dobrodošli');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Ukloni");
define('EMEMBER_UPLOAD', 'Učitaj');
define('EMEMBER_ACTION', 'Radnja');
define('EMEMBER_DETAILS','Detalji');
define('EMEMBER_DELETE_ACC','Obriši Račun');
define('EMEMBER_MEMBER_SINCE','Član od');
define('EMEMBER_USER','Korisnik');
define('EMEMBER_USERS','Korisnici');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Unesite captcha kod');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Ostavite slijedeće polje prazno');
define('EMEMBER_CAPTCHA_FAILED','Captcha verifikacija nije uspjela');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Odaberite jedno');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Oznake');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Captcha verifikacija nije uspjela. Molimo pokušajte ponovo.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Zahvaljujemo na registraciji. Vaš račun čeka na odobrenje od strane administratora.');
define("EMEMBER_ACCOUNT_PENDING","Ovaj račun čeka na odobrenje.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Jeste li sigurni? ');
define('EMEMBER_YES','Da');
define('EMEMBER_NO','Ne');
define('EMEMBER_REDIRECTION_MESSAGE','Molimo sačekajte... biti ćete preusmjereni.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Članska razina je ažurirana.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Morate biti prijavljeni kako biste nadogradili članstvo.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Vaš korisnički račun je aktiviran.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Pozdrav, vaš račun je aktiviran. Sada se možete prijaviti na stranicu.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Dozvoljena su slova, brojevi i donja crta");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Uredite profil ponovo');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Sesija je istekla');
define('EMEMBER_LOGIN_AGAIN', 'Molimo prijavite se ponovo');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Članska razina');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Ovaj sadržaj je objavljen prije nego što ste nam se pridružili. Vi nemate dopuštenje da vidite ovaj sadržaj.');
define('EMEMBER_RETYPE_EMAIL', 'Ponovo upišite email');
define('EMEMBER_EMAIL_MISMATCH', 'Email polja se ne podudaraju');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Greška! Jedinstveni registracijski kod kojeg ste pokušali koristiti u URL se već koristi ili nije valjan!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Ukloni');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');

