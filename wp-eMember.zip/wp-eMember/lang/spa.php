<?php
define("EMEMBER_MORE_LINK","Seguir leyendo");
define("EMEMBER_LEVEL_NOT_ALLOWED","Tu nivel de membresía no te permite ver el resto del contenido.");
define("EMEMBER_CONTENT_RESTRICTED","Contenido restringido.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Este contenido esta oculto para tu nivel de membresía. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Contenido sólo para miembros.");
define("EMEMBER_MEMBER_LOGIN",'Acceso de miembro');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Tu suscripción ha caducado. ");
define("EMEMBER_LOGIN","Acceso");
define("EMEMBER_RENEW", "Renovar");
define("EMEMBER_UPGRADE", "Actualizar");
define("EMEMBER_TO_VIEW_CONTENT", "para ver el contenido.<br/>");
define("EMEMBER_PLEASE", "Por favor");
define("EMEMBER_JOIN","¡Únete hoy!");
define("EMEMBER_NON_MEMBER", "¿No eres miembro? ");
define("EMEMBER_YOUR_ACCOUNT", " Tu cuenta.");
define("EMEMBER_PROFILE_MESSAGE","Por favor, entra a tu cuenta para editar tu perfil.");
define("EMEMBER_LOGGED_IN_AS", "Usuario: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Tu nivel de cuenta es: ");
define("EMEMBER_LOGOUT", "Salir");
define("EMEMBER_EDIT_PROFILE", "Editar cuenta");
define("EMEMBER_SUPPORT_PAGE","Página de soporte");
define("EMEMBER_BOOKMARK_DISABLED", "Opción de favoritos desactivada.");
define("EMEMBER_NO_BOOKMARK", "Aún no has añadido nada a la lista de favoritos.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Debes entrar en tu cuenta para ver tus favoritos.");
define("EMEMBER_FORGOT_PASS","¿Olvidaste la contraseña?");
define("EMEMBER_JOIN_US","Únete a nosotros");
define("EMEMBER_USER_NAME", "Nombre de usuario");
define("EMEMBER_PASSWORD", "Contraseña");
define("EMEMBER_USER_NAME_TAKEN", "El nombre de usuario ya existe! <br/>Por favor, utiliza uno diferente.");
define("EMEMBER_EMAIL_TAKEN", "Email ya en uso ! <br/>Por favor, utiliza otro email. ");
define("EMEMBER_REG_COMPLETE", "¡Registro completo!");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Registro de un nuevo miembro");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Hay un nuevo registro. Este es el correo electrónico que se ha enviado al nuevo miembro.");
define("EMEMBER_USER_PASS_MSG", "Por favor, crea tu nombre de usuario y contraseña para completar tu registro. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "¡No hay cuentas gratis disponibles!");
define("EMEMBER_EMAIL_UNAVAIL","¡Este correo electrónico no está disponible!");
define("EMEMBER_PROFILE_UPDATED","¡Perfil actualizado!");
define("EMEMBER_EMAIL_INVALID","Correo electrónico incorrecto.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Cuenta sin activar.");
define("EMEMBER_WRONG_PASS","Contraseña incorrecta.");
define("EMEMBER_WRONG_USER_PASS", "Usuario o contraseña incorrecta.");
define("EMEMBER_LOGOUT_SUCCESS", "Sesión cerrada. ");
define("EMEMBER_ADDED", "Añadido");  
define("EMEMBER_FAVORITE", "Favorito");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Los detalles de tu cuenta");
define("EMEMBER_PASS_EMAILED_MSG","La nueva contraseña ha sido enviada a tu correo electrónico.");
define("EMEMBER_EMAIL_NOT_EXIST","Este usuario con este correo electrónico NO EXISTE.");
define("EMEMBER_ALREADY_TAKEN","¡Lo siento! El nombre de usuario ya está en uso.
");
define("EMEMBER_STILL_AVAIL","Este todavía está disponible.");
define("EMEMBER_WP_TAKEN","¡Lo siento! Este ya se utiliza en Wordpress.");
define('EMEMBER_TITLE','Título');
define("EMEMBER_FIRST_NAME","Nombre");
define("EMEMBER_LAST_NAME","Apellidos");
define("EMEMBER_EMAIL","Correo electrónico");
define("EMEMBER_MEMBERSHIP_LEVEL","Nivel de cuenta");
define("EMEMBER_USERNAME","Usuario");
define("EMEMBER_COMPANY","Empresa");
define("EMEMBER_PHONE","Teléfono");
define("EMEMBER_ADDRESS_STREET","Dirección");
define("EMEMBER_ADDRESS_CITY","Ciudad");
define("EMEMBER_ADDRESS_STATE","Provincia");
define("EMEMBER_ADDRESS_ZIP","Código postal");
define("EMEMBER_ADDRESS_COUNTRY","País");
define("EMEMBER_GENDER","Sexo");
define("EMEMBER_GENDER_MALE","Hombre");
define("EMEMBER_GENDER_FEMALE","Mujer");
define("EMEMBER_GENDER_UNSPECIFIED","Sin especificar");
define("EMEMBER_REGISTRATION","Matricularse");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Dejar vacío si deseas mantener la contraseña actual.");
define("EMEMBER_UPDATE", "Actualizar");
define("EMEMBER_ADD","Añadir");
define("EMEMBER_ADD_FAV","Añadir a Favoritos");
define("EMEMBER_BOOKMARK","Favoritos");
//define("EMEMBER_FAV","Favoritos");
define("EMEMBER_LOGIN_TO_BOOKMARK","Acceder a tus Favoritos.");
define("EMEMBER_PASS_RESET","Contraseña restablecida");
define("EMEMBER_PASS_RESET_MSG","Por favor, introduce tu dirección de correo electrónico. Recibirás una nueva contraseña por correo electrónico.");
define("EMEMBER_RESET","Restabler");
define("EMEMBER_CLOSE","Cerrar");
define("EMEMBER_PROFILE_IMAGE", "Imágen de perfil");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","No has entrado a tu cuenta.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Mi RSS seguro");
define("EMEMBER_WRONG_RSS_URL","¡Lo siento! La URL no tiene el formato correcto.");
define("EMEMBER_NO_USER_KEY","¡Lo siento! ¡La clave de alimentación no parece ser válida!");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Has alcanzado tu cuota diaria de entrada.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Estado de tu cuenta:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Tu cuenta caduca el:");
define("EMEMBER_EMAIL_BLACKLISTED","Tu dirección de correo electrónico está en la lista negra. <br/> No podrás registrarte con esta dirección de correo electrónico. <br/> Por favor, pónte en contacto con el administrador del sitio.");
define("EMEMBER_IP_BLACKLISTED","Tu dirección de IP está en la lista negra. <br/>
		       no podrás registrarte. <br/> Por favor, pónte en contacto con el administrador.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Acuérdate de mí");
define("EMEMBER_NEVER", "Nunca");
define('EMEMBER_ACTIVE','activa');
define('EMEMBER_INACTIVE','desactivada');
define('EMEMBER_EXPIRED','caducado');
define('EMEMBER_PENDING','pendiente');
define('EMEMBER_UNSUBSCRIBED','sin suscripción');
define('EMEMBER_VISIT_PAYMENT_PAGE','Por favor, visita la página de pago para pagar por una membresía');
define('EMEMBER_CLICK','Haz clic');
define('EMEMBER_HERE','Aquí');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Hola, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " para empezar. ¿No eres miembro? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Por favor revisa tu correo electrónico y haz clic en el enlace para completar tu registro.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "¡Tienes que introudcir un correo electrónico!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "¡Tienes que rellenar todos los campos!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Vuelve a escribir la contraseña");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'El campo del nombre de usuario no puede estar vacío.');
define('EMEMBER_USERNAME_4_CHARS', 'Se requiere mas de 4 caracteres para el nombre de usuario');
define('EMEMBER_EMAIL_NOT_EMPTY','El correo electrónico no puede estar vacío');
define('EMEMBER_INVALID_EMAIL','Correo electrónico incorrecto');
define('EMEMBER_PASSWORD_EMPTY','El campo de la contraseña no puede estar vacío');
define('EMEMBER_USERNAME_TAKEN','Nombre de usuario en uso');
define('EMEMBER_USERNAME_AVAIL','Nombre de usuario disponible');
define('EMEMBERR_WAIT','Validando, por favor espera');
define('EMEMBER_REQUIRED','Este campo es obligatorio');
define('EMEMBER_MIN','Mínimo');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'caracteres obligatorios');
define('EMEMBER_FIELD_MISMATCH','Los campos no coinciden');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Solamente letras, números y guión bajo permitidos');
define('EMEMBER_PASSWORD_MISMATCH','Las contraseñas no coinciden.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Has cambiado tu contraseña. Se recomienda que salgas y luego vuelve a entrar de nuevo usando la nueva contraseña.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Perfil de usuario');
define('EMEMBER_AUTH_REQUIRED','Identificación obligatoria');
define('EMEMBER_PROTECTED_BY','Protegido por');
define ('EMEMBER_SIGNIN','Entrar');
define('EMEMBER_TO_COMMENT', ' para escribir un comentario');
define('EMEMBER_WAIT', 'Espera');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Renovar o actualizar');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Tu sesión ha finalizado. Por favor, entra de nuevo.');
define('EMEMBER_USER_PASS_EMPTY','¡El campo de Nombre de usuario / Contraseña no pueden estar vacío!');
define('EMEMBER_TERMS_WARNING', 'Tienes que aceptar los términos y condiciones para registrarte.');
define("EMEMBER_ACCEPT", "Estoy de acuerdo con ");
define('EMEMBER_TERMS_CONDITIONS', 'las condiciones de uso');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Este es un formulario de preinscripción. Completa la siguiente información para verificar primero tu dirección de correo electrónico. Podrás acceder al formulario de registro completo y registrarte para obtener una cuenta después de la verificación.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Señor');
define('EMEMBER_MRS','Señora');
define('EMEMBER_MISS','Señorita');
define('EMEMBER_MS','Sra');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">No tienes permiso para ver los comentarios.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Tu perfil no tiene acceso a este contenido.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Buscar término');
define('EMEMBER_PREV', 'Atrás');
define('EMEMBER_NEXT', 'Siguiente');
define('EMEMBER_SEARCH', 'Buscar');
define('EMEMBER_DATA_NOT_FOUND', 'No se han encontrado los datos.');
define('EMEMBER_ALREADY_LOGGED_IN','Has sido desconectado porque otra persona ha ingresado a tu cuenta desde otro navegador.');
define('EMEMBER_WELCOME_PAGE', 'Página de bienvenida');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Remover");
define('EMEMBER_UPLOAD', 'Subir');
define('EMEMBER_ACTION', 'Acción');
define('EMEMBER_DETAILS','Detalles');
define('EMEMBER_MEMBER_SINCE','Miembro desde');
define('EMEMBER_DELETE_ACC','Borrar cuenta');
define('EMEMBER_USER','Usuario');
define('EMEMBER_USERS','Usuarios');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Introduce el código de captcha');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Manten el siguiente campo vacío');
define('EMEMBER_CAPTCHA_FAILED','Fallo la verificación de Captcha');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Selecciona una');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Favoritos');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Fallo la verificación de Captcha. Por favor, intenta de nuevo');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Gracias por registrarte. Tu cuenta está pendiente de aprobación por parte del administrador.');
define("EMEMBER_ACCOUNT_PENDING","Esta cuenta está pendiente de aprobación.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Estás seguro?');
define('EMEMBER_YES','Sí');
define('EMEMBER_NO','No');
define('EMEMBER_REDIRECTION_MESSAGE','Por favor, espera... estas siendo redireccionado.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Tu nivel de membresía ha sido actualizada.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Debes estar conectado para actualizar tu nivel de membresía.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Tu cuenta de usuario ha sido activada.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Hola, tu cuenta ha sido activada. Ya puedes entrar al sitio.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Solamente letras, números, guión bajo o correo electrónico permitidos. ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Editar tu perfil de nuevo');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','La sesión ha caducado.');
define('EMEMBER_LOGIN_AGAIN', 'Por favor entra de nuevo');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Nivel de membresía');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Este contenido fue publicado antes de que te unieras. No tienes permiso de ver este contenido.');
define('EMEMBER_RETYPE_EMAIL', 'Vuelve a escribir el correo electrónico');
define('EMEMBER_EMAIL_MISMATCH', 'Desajuste de campo de correo electrónico');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', '¡Error! ¡El código de registro único que usaste en la URL ya se ha usado o no es válido!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Eliminar');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','No se permite el carácter apóstrofe.');
define('EMEMBER_SEND_VERIFICATION', 'Envia un correo electronico de verificación');

