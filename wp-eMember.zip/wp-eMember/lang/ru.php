<?php
define("EMEMBER_MORE_LINK","Читать дальше");
define("EMEMBER_LEVEL_NOT_ALLOWED","Уровень вашего членства недостаточен для доступа к оставшейся части контента.");
define("EMEMBER_CONTENT_RESTRICTED","У вас нет доступа к этому контенту.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Уровень вашего членства недостаточен для доступа к этому контенту. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Этот контент доступен только членам.");
define("EMEMBER_MEMBER_LOGIN",'Вход для членов');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Срок членства истек. ");
define("EMEMBER_LOGIN","Войти");
define("EMEMBER_RENEW", "Продлить");
define("EMEMBER_UPGRADE", "Повысить уровень членства");
define("EMEMBER_TO_VIEW_CONTENT", "чтобы получить доступ к контенту. ");
define("EMEMBER_PLEASE", "Вам надо");
define("EMEMBER_JOIN","Регистрируйтесь прямо сейчас!");
define("EMEMBER_NON_MEMBER", "Не являетесь членом?");
define("EMEMBER_YOUR_ACCOUNT", " ваша учетная запись.");
define("EMEMBER_PROFILE_MESSAGE","Чтобы редактировать анкету, надо войти в систему.");
define("EMEMBER_LOGGED_IN_AS", "Вы вошли как: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Уровень вашего членства: ");
define("EMEMBER_LOGOUT", "Выйти");
define("EMEMBER_EDIT_PROFILE", "Редактировать анкету");
define("EMEMBER_SUPPORT_PAGE","Страница помощи");
define("EMEMBER_BOOKMARK_DISABLED", "Список избранного отключен.");
define("EMEMBER_NO_BOOKMARK", "Ваш список избранного пуст.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Чтобы получить список избранного, надо войти в систему.");
define("EMEMBER_FORGOT_PASS","Забыли пароль?");
define("EMEMBER_JOIN_US","Зарегистрироваться");
define("EMEMBER_USER_NAME", "Имя пользователя");
define("EMEMBER_PASSWORD", "Пароль");
define("EMEMBER_USER_NAME_TAKEN", "Это имя пользователя занято! <br/>Пожалуйста выберите другое.");
define("EMEMBER_EMAIL_TAKEN", "занят, пожалуйста выберите другой");
define("EMEMBER_REG_COMPLETE", "Регистрация успешно завершена! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Уведомление о регистрации нового члена");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Зарегистрирован новый член, ему отправлено следующее письмо.");
define("EMEMBER_USER_PASS_MSG", "Для завершения регистрации пожалуйста заполните поля внизу. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Бесплатное членоство недоступно!");
define("EMEMBER_EMAIL_UNAVAIL","Этот email недоступен!");
define("EMEMBER_PROFILE_UPDATED","Анкета обновлена");
define("EMEMBER_EMAIL_INVALID","Некорректный email.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Учетная запись неактивна.");
define("EMEMBER_WRONG_PASS","Неверный пароль.");
define("EMEMBER_WRONG_USER_PASS", "Неверное имя пользователя или пароль.");
define("EMEMBER_LOGOUT_SUCCESS", "Вы вышли из системы. ");
define("EMEMBER_ADDED", "Добавлено");
define("EMEMBER_FAVORITE", "Избранное");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","О вашем членстве");
define("EMEMBER_PASS_EMAILED_MSG","Новый пароль отправлен на ваш email.");
define("EMEMBER_EMAIL_NOT_EXIST","Пользователь с таким email не зарегистрирован.");
define("EMEMBER_ALREADY_TAKEN","Извините, занято.");
define("EMEMBER_STILL_AVAIL","Свободен.");
define("EMEMBER_WP_TAKEN","Извините, занято Вордпрессом.");
define('EMEMBER_TITLE','Обращение');
define("EMEMBER_FIRST_NAME","Имя");
define("EMEMBER_LAST_NAME","Фамилия");
define("EMEMBER_EMAIL","Email");
define("EMEMBER_MEMBERSHIP_LEVEL","Уровень членства");
define("EMEMBER_USERNAME","Имя пользователя");
define("EMEMBER_COMPANY","Компания");
define("EMEMBER_PHONE","Телефон");
define("EMEMBER_ADDRESS_STREET","Улица, дом");
define("EMEMBER_ADDRESS_CITY","Город");
define("EMEMBER_ADDRESS_STATE","Регион");
define("EMEMBER_ADDRESS_ZIP","Индекс");
define("EMEMBER_ADDRESS_COUNTRY","Страна");
define("EMEMBER_GENDER","Пол");
define("EMEMBER_GENDER_MALE","М");
define("EMEMBER_GENDER_FEMALE","Ж");
define("EMEMBER_GENDER_UNSPECIFIED","Не указан");
define("EMEMBER_REGISTRATION","Зарегистрироваться");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Оставьте пустым, если хотите сохранить текущий пароль.");
define("EMEMBER_UPDATE", "Сохранить");
define("EMEMBER_ADD","Добавить");
define("EMEMBER_ADD_FAV","Добавить в любимые");
define("EMEMBER_BOOKMARK","Избранное");
define("EMEMBER_LOGIN_TO_BOOKMARK","Чтобы добавить в избранное, надо войти в систему.");
define("EMEMBER_PASS_RESET","Сменить пароль");
define("EMEMBER_PASS_RESET_MSG","Пожалуйста введите ваш email и мы отправим на него новый пароль.");
define("EMEMBER_RESET","Сменить");
define("EMEMBER_CLOSE","Закрыть");
define("EMEMBER_PROFILE_IMAGE", "Аватар");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Вы не вошли в систему.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Мой RSS");
define("EMEMBER_WRONG_RSS_URL","Извините, некорректный URL.");
define("EMEMBER_NO_USER_KEY","Извините, некорректный ключ ленты.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Вы превысили дневную квоту.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Статус вашей учетной записи:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Действует до:");
define("EMEMBER_EMAIL_BLACKLISTED","Ваш email в черном списке. <br/>
        		       регистрация невозможна. <br/>Свяжитесь с администратором.");
define("EMEMBER_IP_BLACKLISTED","Ваш IP в черном списке. <br/>
		       регистрация невозможна. <br/>Свяжитесь с администратором.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Запомнить меня");
define("EMEMBER_NEVER", "бессрочно");
define('EMEMBER_ACTIVE','активен');
define('EMEMBER_INACTIVE','не активен');
define('EMEMBER_EXPIRED','срок истек');
define('EMEMBER_PENDING','ожидает утверждения');
define('EMEMBER_UNSUBSCRIBED','не подписан');
define('EMEMBER_VISIT_PAYMENT_PAGE','Пожалуйста оплатите членство');
define('EMEMBER_CLICK','Кликните мышкой');
define('EMEMBER_HERE','Здесь');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Здравствуйте, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " чтобы начать. Не являетесь членом? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Пожалуйста проверьте свой почтовый ящик, чтобы завершить регистрацию.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Пожалуйста укажите свой email!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Пожалуйста заполните все поля!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Введите пароль еще раз");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'Имя пользователя не может быть пустым');
define('EMEMBER_USERNAME_4_CHARS', 'Имя пользователя должно включать не меньше четырех символов');
define('EMEMBER_EMAIL_NOT_EMPTY','Email не может быть пустым');
define('EMEMBER_INVALID_EMAIL','Некорректный email');
define('EMEMBER_PASSWORD_EMPTY','Пароль не может быть пустым');
define('EMEMBER_USERNAME_TAKEN','Имя пользователя уже занято');
define('EMEMBER_USERNAME_AVAIL','Имя пользователя свободно');
define('EMEMBERR_WAIT','Проверяем, минуточку...');
define('EMEMBER_REQUIRED','Это поле обязательно для ввода');
define('EMEMBER_MIN','Введите минимум');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'символов');
define('EMEMBER_FIELD_MISMATCH','Поля не совпадают');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Допускаются только латинские буквы, цифры и подчеркивание');
define('EMEMBER_PASSWORD_MISMATCH','Неверный пароль.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Вы изменили свой пароль. Рекомендуем выйти из системы и снова войти, чтобы проверить новый пароль.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Моя анкета');
define('EMEMBER_AUTH_REQUIRED','Необходимо войти');
define('EMEMBER_PROTECTED_BY','Защищен с помощью');
define('EMEMBER_SIGNIN','Войдите в систему');
define('EMEMBER_TO_COMMENT', ', чтобы иметь возможность комментировать');
define('EMEMBER_WAIT', 'Минуточку...');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Продлить или повысить уровень членства');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Срок вашей сессии истек, пожалуйста войдите в систему снова.');
define('EMEMBER_USER_PASS_EMPTY','Введите имя пользователя и пароль!');
define('EMEMBER_TERMS_WARNING', 'Для регистрации вы должны принять условия предоставления сервиса.');
define("EMEMBER_ACCEPT", "Я согласен ");
define('EMEMBER_TERMS_CONDITIONS', 'с условиями предоставления сервиса');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Пожалуйста укажите свое имя и email, на который мы вышлем ссылку для завершения регистрации.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Г-н');
define('EMEMBER_MRS','Г-жа');
define('EMEMBER_MISS','Тов.');
define('EMEMBER_MS','Ув.');
define('EMEMBER_DR','Проф.');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">У вас нет доступа к комментариям.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','У вас нет доступа к этому контенту.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Поисковый запрос');
define('EMEMBER_PREV', 'Назад');
define('EMEMBER_NEXT', 'Вперед');
define('EMEMBER_SEARCH', 'Искать');
define('EMEMBER_DATA_NOT_FOUND', 'Ничего не найдено.');
define('EMEMBER_ALREADY_LOGGED_IN','Ваша сессия завершена, так как был осуществлен вход в систему с другого устройства.');
define('EMEMBER_WELCOME_PAGE', 'Страница приветствия');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Удалить");
define('EMEMBER_UPLOAD', 'Загрузить');
define('EMEMBER_ACTION', 'Действия');
define('EMEMBER_DETAILS','Подробнее');
define('EMEMBER_DELETE_ACC','Удалить учетную запись');
define('EMEMBER_MEMBER_SINCE','Членство с');
define('EMEMBER_USER','Пользователь');
define('EMEMBER_USERS','Пользователи');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Введите символы, чтобы доказать, что вы не робот');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Оставьте следующее поле пустым');
define('EMEMBER_CAPTCHA_FAILED','Вы не прошли проверку');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Выберите');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Избранное');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Вы не прошли проверку, попробуйте снова.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Спасибо за регистрацию. Ваша учетная запись ожидает активации администратором.');
define("EMEMBER_ACCOUNT_PENDING","Учетная запись ожидает активации администратором.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Вы уверены? ');
define('EMEMBER_YES','Да');
define('EMEMBER_NO','Нет');
define('EMEMBER_REDIRECTION_MESSAGE','Минуточку, перенаправляем...');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Уровень членства изменен.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Войдите в систему, чтобы повысить уровень членства.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Ваша учетная запись активирована.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Здравствуйте! Ваша учетная запись активирована, теперь вы можете войти на сайт.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Латинские буквы, цифры, подчеркивание или email. ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Отредактируйте анкету повторно');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Срок сессии истек.');
define('EMEMBER_LOGIN_AGAIN', 'Пожалуйста войдите в систему повторно');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Уровень членства');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'У вас нет доступа к этому контенту, так как он был опубликован до того, как вы стали нашим членом.');
define('EMEMBER_RETYPE_EMAIL', 'Retype Email');
define('EMEMBER_EMAIL_MISMATCH', 'Email field mismatch');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Error! The unique registration code you used in the URL has already been used or it is invalid!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Remove');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');

