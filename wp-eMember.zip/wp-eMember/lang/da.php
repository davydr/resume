<?php
define("EMEMBER_MORE_LINK","Fortsæt med at læse");
define("EMEMBER_LEVEL_NOT_ALLOWED","Dit medlemsniveau tillader dig ikke at se resten af ​​indholdet.");
define("EMEMBER_CONTENT_RESTRICTED","Du har ikke tilladelse til at se dette indhold.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Dit medlemsniveau har ikke adgang til dette indhold. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Dette indhold er kun for medlemmer.");
define("EMEMBER_MEMBER_LOGIN",'Medlems login');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Din abonnementsperiode er udløbet. ");
define("EMEMBER_LOGIN","Login");
define("EMEMBER_RENEW", "Forny");
define("EMEMBER_UPGRADE", "Opgrader");
define("EMEMBER_TO_VIEW_CONTENT", "for at se dette indhold. ");
define("EMEMBER_PLEASE", "Venligst");
define("EMEMBER_JOIN","Tilmeld dig i dag!");
define("EMEMBER_NON_MEMBER", "Ikke medlem?");
define("EMEMBER_YOUR_ACCOUNT", " din konto.");
define("EMEMBER_PROFILE_MESSAGE","Venligst login for at opdatere din profil.");
define("EMEMBER_LOGGED_IN_AS", "Du er logget ind som: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Dit medlemsniveau er: ");
define("EMEMBER_LOGOUT", "Log ud");
define("EMEMBER_EDIT_PROFILE", "Ret profile");
define("EMEMBER_SUPPORT_PAGE","Support side");
define("EMEMBER_BOOKMARK_DISABLED", "Bogmærkefunktionen er deaktiveret.");
define("EMEMBER_NO_BOOKMARK", "Du har ikke tilføjet noget til favoritlisten endnu.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Du skal logge ind for at se din bogmærkeliste.");
define("EMEMBER_FORGOT_PASS","Glemt adgangskode?");
define("EMEMBER_JOIN_US","Slut dig til os");
define("EMEMBER_USER_NAME", "Brugernavn");
define("EMEMBER_PASSWORD", "Adgangskode");
define("EMEMBER_USER_NAME_TAKEN", "Brugernavnet du bruger er allerede taget! <br/>Vælg venligst et andet navn.");
define("EMEMBER_EMAIL_TAKEN", "Den e-mailadresse, du bruger, er allerede taget! <br/>Vælg venligst en anden e-mailadresse. ");
define("EMEMBER_REG_COMPLETE", "Tilmelding gennemført! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Meddelelse om ny medlemsregistrering");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Et nyt medlem er tilmeldt. Følgende mail blev sendt til medlemmet.");
define("EMEMBER_USER_PASS_MSG", "Vælg venligst dit brugernavn og adgangskode nedenfor for at fuldføre registreringen. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Gratis medlemskab er deaktiveret på denne side!");
define("EMEMBER_EMAIL_UNAVAIL","Dette e-mail-id er ikke tilgængeligt!");
define("EMEMBER_PROFILE_UPDATED","Din profil er blevet opdateret!");
define("EMEMBER_EMAIL_INVALID","Ugyldig e-mail.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Denne konto er inaktiv.");
define("EMEMBER_WRONG_PASS","Forkert adgangskode.");
define("EMEMBER_WRONG_USER_PASS", "Forkert brugernavn eller adgangskode.");
define("EMEMBER_LOGOUT_SUCCESS", "Logget ud. ");
define("EMEMBER_ADDED", "Tilføjet");
define("EMEMBER_FAVORITE", "Favorit");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Dine medlemsoplysninger");
define("EMEMBER_PASS_EMAILED_MSG","Din nye adgangskode er blevet sendt til dig.");
define("EMEMBER_EMAIL_NOT_EXIST","Bruger med denne e-mailadresse eksisterer ikke.");
define("EMEMBER_ALREADY_TAKEN","Beklager! Brugernavnet er allerede taget.");
define("EMEMBER_STILL_AVAIL","Denne er stadig tilgængelig.");
define("EMEMBER_WP_TAKEN","Beklager! Denne bruges allerede i Wordpress.");
define('EMEMBER_TITLE','Titel');
define("EMEMBER_FIRST_NAME","Fornavn");
define("EMEMBER_LAST_NAME","Efternavn");
define("EMEMBER_EMAIL","E-mail");
define("EMEMBER_MEMBERSHIP_LEVEL","Medlemskab");
define("EMEMBER_USERNAME","brugernavn");
define("EMEMBER_COMPANY","Virksomhed");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Gade");
define("EMEMBER_ADDRESS_CITY","By");
define("EMEMBER_ADDRESS_STATE","Region");
define("EMEMBER_ADDRESS_ZIP","Postnummer");
define("EMEMBER_ADDRESS_COUNTRY","Land");
define("EMEMBER_GENDER","Køn");
define("EMEMBER_GENDER_MALE","Mand");
define("EMEMBER_GENDER_FEMALE","Kvinde");
define("EMEMBER_GENDER_UNSPECIFIED","Ikke specificeret");
define("EMEMBER_REGISTRATION","Registrer");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Lad være tom, hvis du vil beholde den nuværende adgangskode.");
define("EMEMBER_UPDATE", "Opdatering");
define("EMEMBER_ADD","Tilføj");
define("EMEMBER_ADD_FAV","Tilføj til favorit");
define("EMEMBER_BOOKMARK","Bogmærke");
define("EMEMBER_LOGIN_TO_BOOKMARK","Log for at bogmærke.");
define("EMEMBER_PASS_RESET","Nulstil adgangskode");
define("EMEMBER_PASS_RESET_MSG","Indtast venligst din e-mailadresse. Du vil modtage en ny adgangskode via e-mail.");
define("EMEMBER_RESET","Nulstil");
define("EMEMBER_CLOSE","Luk");
define("EMEMBER_PROFILE_IMAGE", "Profilbillede");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Ikke logget ind.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Min sikre RSS");
define("EMEMBER_WRONG_RSS_URL","Beklager! URL'en er ikke korrekt formateret.");
define("EMEMBER_NO_USER_KEY","Beklager! Feednøgle ser ikke gyldig ud!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Du har nået din daglige loginkvote.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Din kontostatus:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Din konto udløber:");
define("EMEMBER_EMAIL_BLACKLISTED","Din e-mailadresse er sortlistet. <br/>Du vil ikke være i stand til at registrere dig med denne e-mailadresse. <br/>Kontakt venligst webstedsadministratoren.");
define("EMEMBER_IP_BLACKLISTED","Din IP-adresse er sortlistet. <br/>
  Du vil ikke kunne tilmelde dig. <br/>Kontakt venligst Admin.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Husk mig");
define("EMEMBER_NEVER", "Indtil afmeldt");
define('EMEMBER_ACTIVE','aktiv');
define('EMEMBER_INACTIVE','inaktiv');
define('EMEMBER_EXPIRED','udløbet');
define('EMEMBER_PENDING','afventer');
define('EMEMBER_UNSUBSCRIBED','afmeldt');
define('EMEMBER_VISIT_PAYMENT_PAGE','Besøg venligst betalingssiden for at betale for et medlemskab');
define('EMEMBER_CLICK','Klik');
define('EMEMBER_HERE','Her');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Hej, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " at starte. Ikke medlem? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Tjek venligst din e-mail og følg linket for at fuldføre tilmelding.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Du skal indtaste en e-mailadresse!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Du skal udfylde alle felterne!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Indtast adgangskoden igen");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'brugernavn må ikke være tomt.');
define('EMEMBER_USERNAME_4_CHARS', 'brugernavn bør ikke være mindre end 4 tegn');
define('EMEMBER_EMAIL_NOT_EMPTY','e-mail må ikke være tom');
define('EMEMBER_INVALID_EMAIL','e-mailadressen er ikke gyldig');
define('EMEMBER_PASSWORD_EMPTY','Adgangskodefelt må ikke være tomt');
define('EMEMBER_USERNAME_TAKEN','Denne bruger er allerede taget');
define('EMEMBER_USERNAME_AVAIL','Dette navn er tilgængeligt');
define('EMEMBERR_WAIT','Validerer, vent venligst');
define('EMEMBER_REQUIRED','Dette felt er påkrævet');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'tegn påkrævet');
define('EMEMBER_FIELD_MISMATCH','Felter stemmer ikke overens');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Kun bogstaver, tal og understregninger tilladt');
define('EMEMBER_PASSWORD_MISMATCH','Adgangskoden matcher ikke.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Du har ændret din adgangskode. Det anbefales, at du logger ud og derefter logger ind igen med den nye adgangskode.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Brugerprofil');
define('EMEMBER_AUTH_REQUIRED','Godkendelse påkrævet');
define('EMEMBER_PROTECTED_BY','Beskyttet af');
define('EMEMBER_SIGNIN','Log ind');
define('EMEMBER_TO_COMMENT', ' at skrive en kommentar');
define('EMEMBER_WAIT', 'vent');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Forny eller opgrader');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Din session er udløbet. Log venligst på igen.');
define('EMEMBER_USER_PASS_EMPTY','Brugernavn/adgangskode-feltet må ikke være tomt!');
define('EMEMBER_TERMS_WARNING', 'Du skal acceptere vilkår og betingelser for at registrere dig.');
define("EMEMBER_ACCEPT", "Jeg er enig i ");
define('EMEMBER_TERMS_CONDITIONS', 'Vilkår &amp; Betingelser');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Udfyld følgende detaljer for at bekræfte din e-mailadresse. Du vil være i stand til at oprette en konto efter bekræftelsen.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Hr.');
define('EMEMBER_MRS','Fru');
define('EMEMBER_MISS','Frk.');
define('EMEMBER_MS','Ms');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Du har ikke tilladelse til at se kommentarerne.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Din profil har ikke adgang til dette indhold.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Søgeord');
define('EMEMBER_PREV', 'Tidligere');
define('EMEMBER_NEXT', 'Næste');
define('EMEMBER_SEARCH', 'Søg');
define('EMEMBER_DATA_NOT_FOUND', 'Ingen data fundet.');
define('EMEMBER_ALREADY_LOGGED_IN','Du er blevet logget ud, fordi en anden bruger har logget ind på denne konto fra en anden browser.');
define('EMEMBER_WELCOME_PAGE', 'Velkomstside');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Fjern");
define('EMEMBER_UPLOAD', 'Upload');
define('EMEMBER_ACTION', 'Handling');
define('EMEMBER_DETAILS','Detaljer');
define('EMEMBER_DELETE_ACC','Slet konto');
define('EMEMBER_MEMBER_SINCE','Medlem siden');
define('EMEMBER_USER','Bruger');
define('EMEMBER_USERS','Brugere');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Indtast captcha-koden');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Hold følgende felt tomt');
define('EMEMBER_CAPTCHA_FAILED','Captcha-bekræftelse mislykkedes');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Vælg en');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Bogmærker');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Captcha-bekræftelse mislykkedes. Prøv venligst igen.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Tak for din tilmelding. Din konto afventer godkendelse af en administrator.');
define("EMEMBER_ACCOUNT_PENDING","Denne konto afventer godkendelse.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Er du sikker? ');
define('EMEMBER_YES','Ja');
define('EMEMBER_NO','Nej');
define('EMEMBER_REDIRECTION_MESSAGE','Vent venligst... du bliver omdirigeret.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Medlemsniveau er blevet opdateret.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Du skal være logget ind for at opgradere et medlemskab.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Din brugerkonto er blevet aktiveret.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Hej. Din konto er blevet aktiveret. Du kan nu logge ind på siden.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', 'Bogstaver, tal, understregning eller e-mail tilladt');
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Rediger profil igen');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Session udløbet');
define('EMEMBER_LOGIN_AGAIN', 'Log venligst på igen');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Medlemsniveau');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Dette indhold blev offentliggjort, før du sluttede dig til os. Du har ikke tilladelse til at se dette indhold.');
define('EMEMBER_RETYPE_EMAIL', 'Indtast e-mail igen');
define('EMEMBER_EMAIL_MISMATCH', 'E-mail-felt stemmer ikke overens');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', "Fejl! Den unikke registreringskode, du brugte i URL'en, er allerede blevet brugt eller den er ugyldig!");
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Fjern');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrof karakter er ikke tilladt.');
