<?php
define("EMEMBER_MORE_LINK","Lire la suite");
define("EMEMBER_LEVEL_NOT_ALLOWED","Votre niveau d&rsquo;adh&eacute;sion ne vous permet pas de voir le reste de ce contenu.");
define("EMEMBER_CONTENT_RESTRICTED","Contenu r&eacute;serv&eacute; aux membres.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Ce contenu est accessible aux membres inscrits et &agrave; une certaine &eacute;tape de leur parcours.");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Contenu r&eacute;serv&eacute; aux membres et &agrave; une certaine &eacute;tape de leur parcours.");
define("EMEMBER_MEMBER_LOGIN",'Acc&egrave;s des membres - Login');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Votre abonnement a expir&eacute;. ");
define("EMEMBER_LOGIN","Connexion - Login");
define("EMEMBER_RENEW", "Renouveler");
define("EMEMBER_UPGRADE", "Mettre &agrave; jour");
define("EMEMBER_TO_VIEW_CONTENT", "Pour voir ce contenu. ");
define("EMEMBER_PLEASE", "S&rsquo;il vous plait");
define("EMEMBER_JOIN","Adh&eacute;rez maintenant !");
define("EMEMBER_NON_MEMBER", "Pas encore membre ?");
define("EMEMBER_YOUR_ACCOUNT", " votre compte.");
define("EMEMBER_PROFILE_MESSAGE","Veuillez vous connecter pour changer votre profil.");
define("EMEMBER_LOGGED_IN_AS", "Vous &ecirc;tes connect&eacute;(e) en tant que : ");
define("EMEMBER_LOGGED_IN_LEVEL", "Votre niveau dadh&eacute;sion est : ");
define("EMEMBER_LOGOUT", "D&eacute;connexion");
define("EMEMBER_EDIT_PROFILE", "Editer votre Profil");
define("EMEMBER_SUPPORT_PAGE","Page Support");
define("EMEMBER_BOOKMARK_DISABLED", "La fonction Bookmark est d&eacute;sactiv&eacute;e.");
define("EMEMBER_NO_BOOKMARK", "Vous n&rsquo;avez encore rien ajout&eacute; dans la liste des favoris.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Vous devez vous connecter pour voir votre liste de bookmarks.");
define("EMEMBER_FORGOT_PASS","Oubli&eacute; votre mot de passe ?");
define("EMEMBER_JOIN_US","Rejoignez-nous");
define("EMEMBER_USER_NAME", "Nom d&rsquo;utilisateur");
define("EMEMBER_USER_NAME_TAKEN", "Ce nom dutilisateur est d&eacute;j&agrave; pris ! <br/>Veuillez en choisir un autre.");
define("EMEMBER_EMAIL_TAKEN", "Cet email est d&eacute;j&agrave; pris ! <br/>Veuillez en utiliser un autre. ");
define("EMEMBER_REG_COMPLETE", "Enregistrement termin&eacute; !");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Notification de l&rsquo;enregistrement d&rsquo;un nouveau membre");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Un nouveau membre s&rsquo;est enregistr&eacute;. L&rsquo;email suivant lui a &eacute;t&eacute; envoy&eacute;.");
define("EMEMBER_USER_PASS_MSG", "Veuillez choisir un nom d&rsquo;utilisateur et un mot de passe pour compl&eacute;ter votre enregistrement. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "La fonction adh&eacute;sion gratuite est d&eacute;sactiv&eacute;e sur ce site !");
define("EMEMBER_EMAIL_UNAVAIL","Cet email nest pas disponible !");
define("EMEMBER_PROFILE_UPDATED","Votre profil a bien &eacute;t&eacute; mis &agrave; jour !");
define("EMEMBER_EMAIL_INVALID","Email invalide.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Ce compte est inactif.");
define("EMEMBER_WRONG_PASS","Mot de passe erron&eacute;\A0.");
define("EMEMBER_WRONG_USER_PASS", "Erreur d&rsquo;utilisateur ou de Mot de passe.");
define("EMEMBER_LOGOUT_SUCCESS", "Vous &ecirc;tes bien d&eacute;connect&eacute;(e). ");
define("EMEMBER_FAVORITE", "Favoris");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","D&eacute;tails de votre adh&eacute;sion");
define("EMEMBER_PASS_EMAILED_MSG","Votre mot de passe vous a &eacute;t&eacute; envoy&eacute; par email.");
define("EMEMBER_EMAIL_NOT_EXIST","Il ny a pas d&rsquo;utilisateur avec cet email.");
define("EMEMBER_ALREADY_TAKEN","D&eacute;sol&eacute; ! Celui-ci est d&eacute;j&agrave; pris.");
define("EMEMBER_STILL_AVAIL","Celui-ci est disponible.");
define("EMEMBER_WP_TAKEN","D&eacute;sol&eacute; ! Celui-ci est d&eacute;j&agrave; utilis&eacute; dans Wordpress.");
define("EMEMBER_TITLE","Titre");
define("EMEMBER_FIRST_NAME","Pr&eacute;nom");
define("EMEMBER_LAST_NAME","Nom");
define("EMEMBER_EMAIL","Email");
define("EMEMBER_MEMBERSHIP_LEVEL","Adh&eacute;sion");
define("EMEMBER_USERNAME","Nom d&rsquo;utilisateur");
define("EMEMBER_PASSWORD","Mot de passe");
define("EMEMBER_COMPANY","Soci&eacute;t&eacute;");
define("EMEMBER_PHONE","T&eacute;l&eacute;phone");
define("EMEMBER_ADDRESS_STREET","Rue");
define("EMEMBER_ADDRESS_CITY","Ville");
define("EMEMBER_ADDRESS_STATE","Etat-Province");
define("EMEMBER_ADDRESS_ZIP","Code postal");
define("EMEMBER_ADDRESS_COUNTRY","Pays");
define("EMEMBER_GENDER","Genre");
define("EMEMBER_GENDER_MALE","Homme");
define("EMEMBER_GENDER_FEMALE","Femme");
define("EMEMBER_GENDER_UNSPECIFIED","Ne pas indiquer");
define("EMEMBER_REGISTRATION","Enregistrer");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Ne rien mettre si vous voulez garder votre mot de passe actuel.");
define("EMEMBER_UPDATE", "Mettre &agrave; jour");
define("EMEMBER_ADDED","Ajout&eacute;");
define("EMEMBER_ADD","Ajouter");
define("EMEMBER_ADD_FAV","Ajouter aux favoris");
define("EMEMBER_BOOKMARK","Bookmark");
//define("EMEMBER_FAV","Favoris");
define("EMEMBER_LOGIN_TO_BOOKMARK","Se connecter aux favoris.");
define("EMEMBER_PASS_RESET","R&eacute;initialiser le mot de passe");
define("EMEMBER_PASS_RESET_MSG","Veuillez entrer votre email. Vous allez recevoir votre nouveau mot de passe par email.");
define("EMEMBER_RESET","R&eacute;initialiser");
define("EMEMBER_CLOSE","Fermer");
define("EMEMBER_PROFILE_IMAGE", "Photo du profil");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Vous n&rsquo;&ecirc;tes pas connect&eacute;(e).");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Mes flux RSS");
define("EMEMBER_WRONG_RSS_URL","Oops ! L&rsquo;url n&rsquo;est pas correctement &eacute;crite.");
define("EMEMBER_NO_USER_KEY","Oops ! Nous n&rsquo;avons aucun utilisateur avec les infos fournies.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define("EMEMBER_LOGIN_LIMIT_ERROR", "Vous avez atteint votre quota de connexions diff&eacute;rentes aujourd&rsquo;hui.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define("EMEMBER_ACCOUNT_STATUS", "&Eacute;tat de votre compte :");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Votre compte expirera le :");
define("EMEMBER_EMAIL_BLACKLISTED","L&rsquo;adresse email indiqu&eacute;e est dans la liste noire. <br/> Vous ne pouvez vous enregistrer avec cet email. <br/>Veuillez contacter l&rsquo;administrateur.");
define("EMEMBER_IP_BLACKLISTED","L&rsquo;adresse IP indiqu&eacute;e est dans la liste noire. <br/> Vous ne pourrez pas vous enregistrer. <br/>Merci de Contacter l&rsquo;administrateur.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Garder en m&eacute;moire");
define("EMEMBER_NEVER", "Jamais");
define("EMEMBER_ACTIVE","Actif");
define("EMEMBER_INACTIVE","Inacitf");
define("EMEMBER_EXPIRED","expir&eacute;");
define("EMEMBER_PENDING","En attente");
define("EMEMBER_UNSUBSCRIBED","d&eacute;sinscrit(e)");
define("EMEMBER_VISIT_PAYMENT_PAGE","Veuillez visiter la page de paiement pour payer votre inscription");
define("EMEMBER_CLICK","Cliquez");
define("EMEMBER_HERE","Ici");
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Bonjour ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " pour commencer. Pas encore Membre ? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Merci de relever vos emails et de suivre le lien pour terminer votre inscription.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Merci de mentionner une adresse email !");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Merci de remplir tous les champs !");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Entrez &agrave; nouveau le mot de passe");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define("EMEMBER_USERNAME_NOT_EMPTY", "Le nom utilisateur est n&eacute;cessaire.");
define("EMEMBER_USERNAME_4_CHARS", "Le nom utilisateur doit avoir au moins 4 caract&egrave;res.");
define("EMEMBER_EMAIL_NOT_EMPTY","Votre email est n&eacute;cessaire");
define("EMEMBER_INVALID_EMAIL","Cette adresse email ne peut pas fonctionner");
define("EMEMBER_PASSWORD_EMPTY","Le mot de passe est necessaire");
define("EMEMBER_USERNAME_TAKEN","Ce nom utilisateur existe d&eacute;j&agrave;");
define("EMEMBER_USERNAME_AVAIL","Ce nom est disponible");
define("EMEMBERR_WAIT","En cours de validation, merci de patienter !");
define("EMEMBER_REQUIRED","Ce champ est n&eacute;cessaire");
define("EMEMBER_MIN","Minimum");
define("EMEMBER_ALLOWED_CHAR_TEXT", "caract&egrave;res autorises");
define("EMEMBER_FIELD_MISMATCH","Le champ ne correspond pas");
define("EMEMBER_ALPHA_NUMERIC_UNDERSCORE","Seulement des lettres, nombres et tirets bas");
define("EMEMBER_PASSWORD_MISMATCH","Le mot de passe ne correspond pas.");
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define("EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED","Vous avez chang&eacute; votre mot de passe. Nous vous recommandons de vous deconnecter puis de vous connecter &agrave; nouveau avec le nouveau mot de passe.");
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define("EMEMBER_USER_PROFILE","Profil utilisateur");
define("EMEMBER_AUTH_REQUIRED","Merci de vous authentifier");
define("EMEMBER_PROTECTED_BY","Prot&eacute;g&eacute; par");
define ("EMEMBER_SIGNIN","Entrer");
define("EMEMBER_TO_COMMENT", " pour poster un commentaire");
define("EMEMBER_WAIT", "attendre");
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define("EMEMBER_RENEW_OR_UPGRADE","Renouveler, passer &agrave; un niveau sup&eacute;rieur ou attendre la prochaine &eacute;tape ! :-)");
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define("EMEMBER_AUTOLOGOUT_MSG","La session a expir&eacute;. Merci de vous identifier &agrave; nouveau.");
define("EMEMBER_USER_PASS_EMPTY","Utilisateur et mot de passe sont n&eacute;cessaires.");
define("EMEMBER_TERMS_WARNING", "Vous avez besoin d&rsquo;accepter les termes et conditions pour vous enregistrer.");
define("EMEMBER_ACCEPT", "Je comprends et accepte les ");
define("EMEMBER_TERMS_CONDITIONS", "termes et conditions");
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Compl&eacute;tez les d&eacute;tails suivants pour v&eacute;rifier votre email afin d\'&ecirc;tre autoris&eacute;(e) &agrave; vous enregistrer sur un compte gratuit.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define("EMEMBER_MR","M.");
define("EMEMBER_MRS","Mme");
define("EMEMBER_MISS","Mlle");
define("EMEMBER_MS","Ms");
define("EMEMBER_DR","Dr");
define("EMEMBER_COMMENT_PROTECTED","<div class='eMember_comment_section_protected_msg'>La partie commentaires est prot&eacute;g&eacute;e</div>");
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define("EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED","Votre profil actuel n&rsquo;a pas acces &agrave; cette section.");
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define("EMEMBER_SEARCH_TERM", "Termes de recherche");
define("EMEMBER_PREV", "Suivant");
define("EMEMBER_NEXT", "Pr&eacute;c&eacute;dent");
define("EMEMBER_SEARCH", "Rechercher");
define("EMEMBER_DATA_NOT_FOUND", "El&eacute;ments non trouv&eacute;s.");
define("EMEMBER_ALREADY_LOGGED_IN","Vous avez &eacute;t&eacute; deconnect&eacute;(e) parce qu&rsquo;un autre utilisateur s&rsquo;est connect&eacute; &agrave; ce compte avec un autre navigateur.");
define("EMEMBER_WELCOME_PAGE", "Page d&rsquo;accueil");
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define("EMEMBER_REMOVE", "Effacer");
define("EMEMBER_UPLOAD", "T&eacute;l&eacute;charger");
define("EMEMBER_ACTION", "Action");
define("EMEMBER_DETAILS","Details");
define("EMEMBER_MEMBER_SINCE","Membre depuis ");
define("EMEMBER_DELETE_ACC","Effacer le compte");
define("EMEMBER_USER","Utilisateur");
define("EMEMBER_USERS","Utilisateurs");
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define("EMEMBER_INPUT_THIS_CODE","Entrez le code captcha");
define("EMEMBER_HONEYPOT_CAPTCHA_MSG","Garder le champ suivant vide");
define("EMEMBER_CAPTCHA_FAILED","Erreur de Captcha");
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define("EMEMBER_SELECT_ONE","S&eacute;lectionnez un");
/***added v8.1.6 #end**/
define("EMEMBER_BOOKMARK_PAGE","Favoris");
/***added v8.5.1 #end**/
define("EMEMBER_CAPTCHA_VERIFICATION_FAILED","Erreur de Captcha. Merci de r&eacute;essayer.");
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Merci de vous înscrire. Votre compte est en attente de validation par un administrateur.');
define("EMEMBER_ACCOUNT_PENDING","Ce compte est en attente de validation.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','&Ecirc;tes-vous s&ucirc;r ?');
define('EMEMBER_YES','Oui');
define('EMEMBER_NO','Non');
define('EMEMBER_REDIRECTION_MESSAGE','Patientez... Vous allez &ecirc;tre redirig&eacute;.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Votre niveau d&rsquo;ahdésion a &eacute;t&eacute; mis &agrave; jour.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Vous devez &ecirc;tre connect&eacute; pour mettre &agrave; jour votre niveau d&rsquo;adhésion.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Votre compte utilisateur a &eacute;t&eacute; activ&eacute;.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Bonjour, votre compte a &eacute;t&eacute; activ&eacute;. Vous pouvez d&egrave;s maintenant vous connecter au site.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Les lettres, nombres, soulign&eacute;ment et les arobases sont authoris&eacute;. ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','&Eacute;diter encore le profile');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Session Expir&eacute;e.');
define('EMEMBER_LOGIN_AGAIN', 'Merci de vous reconnecter');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Niveau d&lsquo;adhésion');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Ce contenu a &eacute;t&eacute; publi&eacute; avant que vous nous rejoigne. Vous n&rsquo;avez pas la permission de voir ce contenu.');
define('EMEMBER_RETYPE_EMAIL', 'Re-saisie votre email');
define('EMEMBER_EMAIL_MISMATCH', 'Le champs email ne correspond pas');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Erreur ! Le code undique d&rsquo;enregistrement que vous avez utilisé dans l&rsquo;URL a d&eacute;j&agrave; &eacute;t&eacute; utilis&eacute; ou il est invalid !');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Retirer');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','L&rsquo;apostrophe n&rsquo;est pas authoris&eacute;.');
define('EMEMBER_SEND_VERIFICATION', 'Envoyer un email de v&eacute;rification');
