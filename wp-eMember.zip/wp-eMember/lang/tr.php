<?php
define("EMEMBER_MORE_LINK","Devamı");
define("EMEMBER_LEVEL_NOT_ALLOWED","Üyelik seviyeniz içeriğin geri kalanını görüntülemek için yeterli değil.");
define("EMEMBER_CONTENT_RESTRICTED","Bu içeriği görüntülemek için yetkiniz bulunmamaktadır.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Üyelik seviyenizin bu içeriği görüntüleme yetkisi bulunmamaktadır.");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Bu içerik üyelere özeldir.");
define("EMEMBER_MEMBER_LOGIN",'Üye Girişi');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Üyelik süreniz dolmuştur. ");
define("EMEMBER_LOGIN","Giriş");
define("EMEMBER_RENEW", "Yenile");
define("EMEMBER_UPGRADE", "Yükselt");
define("EMEMBER_TO_VIEW_CONTENT", "yapınız.");
define("EMEMBER_PLEASE", "Lütfen");
define("EMEMBER_JOIN","Şimdi katılın.");
define("EMEMBER_NON_MEMBER", "Üye değil misiniz?");
define("EMEMBER_YOUR_ACCOUNT", " hesabınız.");
define("EMEMBER_PROFILE_MESSAGE","Profilinizi düzenlemek için lütfen giriş yapın.");
define("EMEMBER_LOGGED_IN_AS", "Kullanıcı: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Üyelik seviyeniz: ");
define("EMEMBER_LOGOUT", "Çıkış");
define("EMEMBER_EDIT_PROFILE", "Profil düzenle");
define("EMEMBER_SUPPORT_PAGE","Destek");
define("EMEMBER_BOOKMARK_DISABLED", "İşaretleme özelliği aktif değil.");
define("EMEMBER_NO_BOOKMARK", "Favoriler listenize henüz birşey eklemediniz.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","İşaretleme listenizi görebilmek için lütfen giriş yapın.");
define("EMEMBER_FORGOT_PASS","Şifrenizi mi unuttunuz?");
define("EMEMBER_JOIN_US","Bize Katılın");
define("EMEMBER_USER_NAME", "Kullanıcı Adı");
define("EMEMBER_PASSWORD", "Şifre");
define("EMEMBER_USER_NAME_TAKEN", "Bu kullanıcı adı alınmış! <br/>Lütfen başka bir kullanıcı adı seçin.");
define("EMEMBER_EMAIL_TAKEN", "Girmiş olduğunuz e-posta adresi sistemde kayıtlı. <br/>Lütfen başka bir e-posta adresi seçin. ");
define("EMEMBER_REG_COMPLETE", "Kaydınız başarıyla tamamlandı!");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Yeni kullanıcı kaydı bildirimi");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Yeni kullanıcı kaydı yapıldı. Aşağıdaki e-posta kullanıcıya gönderildi.");
define("EMEMBER_USER_PASS_MSG", "Kaydınızı tamamlamak için lütfen bir kullanıcı adı ve şifre belirleyiniz.");
define("EMEMBER_FREE_MEMBER_DISABLED", "Bu sitede ücretsiz üyelik sistemi bulunmamaktadır!");
define("EMEMBER_EMAIL_UNAVAIL","Geçersiz E-Posta ID'si!");
define("EMEMBER_PROFILE_UPDATED","Profiliniz güncellendi!");
define("EMEMBER_EMAIL_INVALID","Geçersiz E-posta adresi.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Bu hesap aktif değildir.");
define("EMEMBER_WRONG_PASS","Hatalı Şifre.");
define("EMEMBER_WRONG_USER_PASS", "Hatalı Şifre veya Kullanıcı Adı.");
define("EMEMBER_LOGOUT_SUCCESS", "Başarıyla çıkış yaptınız. ");
define("EMEMBER_ADDED", "Eklendi.");
define("EMEMBER_FAVORITE", "Favorilere ekle");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Üyelik Detaylarınız");
define("EMEMBER_PASS_EMAILED_MSG","Yeni şifreniz e-posta adresinize gönderildi.");
define("EMEMBER_EMAIL_NOT_EXIST","Bu e-posta adresiyle kayıtlı bir kullanıcı bulunamadı.");
define("EMEMBER_ALREADY_TAKEN","Üzgünüz! Bu kullanıcı adı alınmış.");
define("EMEMBER_STILL_AVAIL","Kullanıcı adı uygun.");
define("EMEMBER_WP_TAKEN","Üzgünüz! Bu kullanıcı adı Wordpress'de mevcut.");
define('EMEMBER_TITLE','Başlık');
define("EMEMBER_FIRST_NAME","Adınız");
define("EMEMBER_LAST_NAME","Soyadınız");
define("EMEMBER_EMAIL","E-Posta Adresiniz");
define("EMEMBER_MEMBERSHIP_LEVEL","Üyeliğiniz");
define("EMEMBER_USERNAME","Kullanıcı Adı");
define("EMEMBER_COMPANY","Şirketiniz");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Sokak");
define("EMEMBER_ADDRESS_CITY","Şehir");
define("EMEMBER_ADDRESS_STATE","Eyalet");
define("EMEMBER_ADDRESS_ZIP","Posta Kodu");
define("EMEMBER_ADDRESS_COUNTRY","Ülke");
define("EMEMBER_GENDER","Cinsiyetiniz");
define("EMEMBER_GENDER_MALE","Erkek");
define("EMEMBER_GENDER_FEMALE","Kadın");
define("EMEMBER_GENDER_UNSPECIFIED","Belirtilmemiş");
define("EMEMBER_REGISTRATION","Kayıt Ol");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Varolan şifrenizi kullanma istiyorsanız bu alanı boş bırakınız.");
define("EMEMBER_UPDATE", "Güncelle");
define("EMEMBER_ADD","Ekle");
define("EMEMBER_ADD_FAV","Favorilerime ekle");
define("EMEMBER_BOOKMARK","İşaretle");
define("EMEMBER_LOGIN_TO_BOOKMARK","İşaretlemek için giriş yapınız.");
define("EMEMBER_PASS_RESET","Şifre Sıfırlama");
define("EMEMBER_PASS_RESET_MSG","Lütfen E-Posta adresinizi giriniz. Şifreniz E-Posta adresinize gönderilecektir.");
define("EMEMBER_RESET","Sıfırla");
define("EMEMBER_CLOSE","Kapat");
define("EMEMBER_PROFILE_IMAGE", "Profil resmi");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Giriş yapılmamış.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Güvenli RSS");
define("EMEMBER_WRONG_RSS_URL","Üzgünüz! URL uygun değil.");
define("EMEMBER_NO_USER_KEY","Üzgünüz! Geçersiz besleme anahtarı.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', " Günlük giriş kotanız dolmuştur.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Hesap durumunuz:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Hesap son kullanım tarihiniz:");
define("EMEMBER_EMAIL_BLACKLISTED","E-posta adresiniz karalistededir. <br/>
        		       bu e-posta adresi ile kayıt olamazsınız. <br/> lütfen yönetici ile iletişime geçin.");
define("EMEMBER_IP_BLACKLISTED","IP adresiniz karalistededir. <br/>
		       bu IP adresinden kayıt olamazsınız.<br/>lütfen yönetici ile iletişime geçin.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Beni Hatırla");
define("EMEMBER_NEVER", "iptal edilene kadar");
define('EMEMBER_ACTIVE','aktif');
define('EMEMBER_INACTIVE','aktif değil');
define('EMEMBER_EXPIRED','kullanım süresi dolmuş');
define('EMEMBER_PENDING','beklemede');
define('EMEMBER_UNSUBSCRIBED','abonelik yok');
define('EMEMBER_VISIT_PAYMENT_PAGE','Üyelik ödemesi için lütfen ödemeler sayfasını ziyaret edin.');
define('EMEMBER_CLICK','Tıkla');
define('EMEMBER_HERE','Buraya');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Merhaba, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " başlamak için. Üye değil misiniz? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", " Kaydınızı tamamlamak için lütfen e-posta hesabınıza gönderilen linke tıklayın.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Lütfen bir e-posta adresi girin!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Lütfen tüm alanları doldurun!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Şifre (tekrar)");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'kullanıcı adı bölümü boş bırakılamaz.');
define('EMEMBER_USERNAME_4_CHARS', 'kullanıcı adı en az 4 karakterli olmalıdır.');
define('EMEMBER_EMAIL_NOT_EMPTY','e-posta bölümü boş bırakılamaz. ');
define('EMEMBER_INVALID_EMAIL','geçersiz e-posta adresi');
define('EMEMBER_PASSWORD_EMPTY','Şifre bölümü boş bırakılamaz.');
define('EMEMBER_USERNAME_TAKEN','Bu kullanıcı adı alınmış.');
define('EMEMBER_USERNAME_AVAIL','Bu kullanıcı adı uygun');
define('EMEMBERR_WAIT','Doğrulanıyor, lütfen bekleyiniz.');
define('EMEMBER_REQUIRED','Bu alan zorunludur.');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'karakter');
define('EMEMBER_FIELD_MISMATCH','Eşleşme sağlanamadı.');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Sadece harf kullanınız, rakam ve altçizgiye izin verilmemektedir.');
define('EMEMBER_PASSWORD_MISMATCH','Şifre eşleşmesinde hata oluştu.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','Şifrenizi değiştirdiiniz. Çıkış yapıp yeni şifrenizle yeniden giriş yapmanızı öneririz.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Profil');
define('EMEMBER_AUTH_REQUIRED','İzin gerekmektedir.');
define('EMEMBER_PROTECTED_BY','tarafından korunmaktadır');
define('EMEMBER_SIGNIN','Giriş');
define('EMEMBER_TO_COMMENT', ' mesaj yazabilmek için');
define('EMEMBER_WAIT', 'bekleyin.');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Yenile veya Yükselt');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Oturumunuzun süresi dolmuştur. Lütfen yeniden giriş yapın.');
define('EMEMBER_USER_PASS_EMPTY','Kullanıcı adı/şifre alanları boş bırakılamaz!');
define('EMEMBER_TERMS_WARNING', 'Lütfen Kullanıcı şartlarını kabul edin.');
define("EMEMBER_ACCEPT", "Kabul ediyorum. ");
define('EMEMBER_TERMS_CONDITIONS', 'Kullanıcı şartları');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", " E-posta adresinizi doğrulamak için lütfen aşağıdaki detayları doldurunuz. Doğrulamadan sonra kaydınızı tamamlayabilirsiniz.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Bay');
define('EMEMBER_MRS','Bayan');
define('EMEMBER_MISS','Bayan');
define('EMEMBER_MS','Bayan');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Mesajları görebilme yetkiniz bulunmamaktadır.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Bu içeriğe erişim hakkınız bulunmamaktadır.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Kelime Ara');
define('EMEMBER_PREV', 'Önceki');
define('EMEMBER_NEXT', 'Sonraki');
define('EMEMBER_SEARCH', 'Ara');
define('EMEMBER_DATA_NOT_FOUND', 'Herhangi bir bilgi bulunamadı.');
define('EMEMBER_ALREADY_LOGGED_IN','Aynı kullanıcı adıyla başka bir bilgisayardan giriş yapıldığı için oturumunuz sonlandırıldı.');
define('EMEMBER_WELCOME_PAGE', 'Hoşgeldiniz');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Kaldır");
define('EMEMBER_UPLOAD', 'Yükle');
define('EMEMBER_ACTION', 'Action');
define('EMEMBER_DETAILS','Detaylar');
define('EMEMBER_DELETE_ACC','Hesabı sil');
define('EMEMBER_MEMBER_SINCE','Üyelik başlangıcı');
define('EMEMBER_USER','Kullanıcı');
define('EMEMBER_USERS','Kullanıcılar');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Lütfen Captcha giriniz.');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Bu alanı boş bırakınız.');
define('EMEMBER_CAPTCHA_FAILED','Geçersiz Captcha');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Seçiniz');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Bookmarks');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Captcha doğrulaması yapılamadı. Lütfen tekrar deneyin.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Kayıt olduğunuz için teşekkür ederiz. Kaydınız yönetici onayı bekliyor.');
define("EMEMBER_ACCOUNT_PENDING","Bu hesap yönetici onayı beklemektedir.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Emin misiniz? ');
define('EMEMBER_YES','Evet');
define('EMEMBER_NO','Hayır');
define('EMEMBER_REDIRECTION_MESSAGE','Lütfen bekleyin...');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Üyeliğiniz güncellendi.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Üyeliğinizi yükseltebilmek giriş yapmanız gerekmektedir.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Hesabınız aktifleştirildi.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Merhaba, hesabınız aktifleştirildi. Giriş yapabilirsiniz.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Harf, rakam ve alt çizgi kullanabilirsiniz.");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Profilinizi tekrar düzenleyiniz.');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Oturum süreniz doldu.');
define('EMEMBER_LOGIN_AGAIN', 'Lütfen tekrar giriş yapınız.');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Membership Level');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'This content was published before you joined us. You do not have permission to view this content.');
define('EMEMBER_RETYPE_EMAIL', 'Retype Email');
define('EMEMBER_EMAIL_MISMATCH', 'Email field mismatch');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Error! The unique registration code you used in the URL has already been used or it is invalid!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Remove');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');

