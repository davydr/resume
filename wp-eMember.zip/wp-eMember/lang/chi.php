﻿<?php

// WP eMember plugin Traditional Chinese Language File
// 譯者: Po-Jung Chang

define("EMEMBER_MORE_LINK","繼續閱讀");
define("EMEMBER_LEVEL_NOT_ALLOWED","您的會員級別不允許您查看其他內容。");
define("EMEMBER_CONTENT_RESTRICTED","您沒有權限查看此內容。");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","您的會員級別無權訪問該內容。");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","此內容僅供會員。");
define("EMEMBER_MEMBER_LOGIN",'會員登錄');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "您的訂閱已到期");
define("EMEMBER_LOGIN","登錄");
define("EMEMBER_RENEW", "更新");
define("EMBMBER_UPGRADE", "升級");
define("EMEMBER_TO_VIEW_CONTENT", "查看此內容。");
define("EMEMBER_PLEASE", "請");
define("EMEMBER_JOIN","立即加入！");
define("EMEMBER_NON_MEMBER", "還不是會員？");
define("EMEMBER_YOUR_ACCOUNT", "您的帳號。");
define("EMEMBER_PROFILE_MESSAGE","請先登錄後編輯您的資料。");
define("EMEMBER_LOGGED_IN_AS", "您的登錄帳號：");
define("EMEMBER_LOGGED_IN_LEVEL", "您的會員級別：");
define("EMEMBER_LOGOUT", "登出");
define("EMEMBER_EDIT_PROFILE", "編輯個人資料");
define("EMEMBER_SUPPORT_PAGE","說明與支援");
define("EMEMBER_BOOKMARK_DISABLED", "書籤功能將被禁用。");
define("EMEMBER_NO_BOOKMARK", "您還沒有添加任何收藏列表唷！");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","您需要登錄才到看到書籤列表。");
define("EMEMBER_FORGOT_PASS","忘記密碼？");
define("EMEMBER_JOIN_US","加入我們");
define("EMEMBER_USER_NAME", "用戶名稱");
define("EMEMBER_PASSWORD", "用戶密碼");
define("EMEMBER_USER_NAME_TAKEN", "這個帳號已被使用<br/>請選擇一個不同的名稱！");
define("EMEMBER_EMAIL_TAKEN", "您的電子郵件已被註冊<br/>請選擇一個不同的電子郵件地址！");
define("EMEMBER_REG_COMPLETE", "註冊完成！");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "新會員註冊通知書");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "會員註冊成功，將透過電子郵件發送以下內容給會員。");
define("EMEMBER_USER_PASS_MSG", "請選擇您的用戶名和密碼，才能完成註冊。");
define("EMEMBER_FREE_MEMBER_DISABLED", "免費會員被禁用！");
define("EMEMBER_EMAIL_UNAVAIL","此電子郵件ID是不可用！");
define("EMEMBER_PROFILE_UPDATED","您的個人資料已更新！");
define("EMEMBER_EMAIL_INVALID","無效的電子郵件。");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","這個帳號是無效的。");
define("EMEMBER_WRONG_PASS","密碼錯誤");
define("EMEMBER_WRONG_USER_PASS", "錯誤的用戶名或密碼。");
define("EMEMBER_LOGOUT_SUCCESS", "成功退出。");
define("EMEMBER_ADDED", "新增");
define("EMEMBER_FAVORITE", "收藏");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","您的會員詳細資料");
define("EMEMBER_PASS_EMAILED_MSG","您的新密碼已經通過電子郵件發送給你。");
define("EMEMBER_EMAIL_NOT_EXIST","用戶使用此電子郵件地址不存在。");
define("EMEMBER_ALREADY_TAKEN","對不起！這一項目已被使用。");
define("EMEMBER_STILL_AVAIL","這一次仍然是可用的");
define("EMEMBER_WP_TAKEN","對不起！這一項目已在 Wordpress 被使用。");
define('EMEMBER_TITLE','標題');
define("EMEMBER_FIRST_NAME","名字");
define("EMEMBER_LAST_NAME","姓氏");
define("EMEMBER_EMAIL","電子郵件");
define("EMEMBER_RETYPE_EMAIL","電子郵件確認");
define("EMEMBER_MEMBERSHIP_LEVEL","會籍");
define("EMEMBER_USERNAME","用戶名稱");
define("EMEMBER_COMPANY","公司名稱");
define("EMEMBER_PHONE","連絡電話");
define("EMEMBER_ADDRESS_STREET","街道路名");
define("EMEMBER_ADDRESS_CITY","城市");
define("EMEMBER_ADDRESS_STATE","省/洲");
define("EMEMBER_ADDRESS_ZIP","郵遞區號");
define("EMEMBER_ADDRESS_COUNTRY","國家");
define("EMEMBER_GENDER","姓別");
define("EMEMBER_GENDER_MALE","男");
define("EMEMBER_GENDER_FEMALE","女");
define("EMEMBER_GENDER_UNSPECIFIED","未指定");
define("EMEMBER_REGISTRATION","註冊");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","如果您想要保留目前密碼請留空。");
define("EMEMBER_UPDATE", "更新");
define("EMEMBER_ADD","增加");
define("EMEMBER_ADD_FAV","加入到收藏");
define("EMEMBER_BOOKMARK","書籤");
define("EMEMBER_LOGIN_TO_BOOKMARK","登錄到書籤。");
define("EMEMBER_PASS_RESET","重設密碼");
define("EMEMBER_PASS_RESET_MSG","請輸入您的電子郵件地址，將傳送新密碼到電子郵件。");
define("EMEMBER_RESET","重設");
define("EMEMBER_CLOSE","關閉");
define("EMEMBER_PROFILE_IMAGE", "個人圖像");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","尚未登錄。");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "我的安全訂閱RSS");
define("EMEMBER_WRONG_RSS_URL","對不起！這個連結(URL)格式不正確！");
define("EMEMBER_NO_USER_KEY","對不起！傳送鍵看起來不合法！");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "您已經超過每日登錄額度。");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "您的帳號狀態：");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "您的帳號過期：");
define("EMEMBER_EMAIL_BLACKLISTED","您的電子郵件地址被列入黑名單。<br/>
        您將無法使用此電子郵件ID註冊。 <br/>請聯繫管理員");
define("EMEMBER_IP_BLACKLISTED","您的IP地址被列入黑名單。<br/>
        您將無法進行註冊。<br/>請聯繫管理員");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "記住我");
define("EMEMBER_NEVER", "直到取消");
define('EMEMBER_ACTIVE','有效');
define('EMEMBER_INACTIVE','無效');
define('EMEMBER_EXPIRED','過期');
define('EMEMBER_PENDING','待定');
define('EMEMBER_UNSUBSCRIBED','退訂');
define('EMEMBER_VISIT_PAYMENT_PAGE','請訪問支付會員頁面');
define('EMEMBER_CLICK','點擊');
define('EMEMBER_HERE','這裡');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "您好, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", "目前還不是會員？");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "請檢查您的電子郵件並依照連結指示，即可完成註冊。");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "您必須輸入一個電子郵件地址！");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "您必須填寫所有空格！");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "重新輸入密碼");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', '用戶名稱不能為空白。');
define('EMEMBER_USERNAME_4_CHARS', '用戶名稱不得小於4個字符');
define('EMEMBER_EMAIL_NOT_EMPTY','電子郵件不能為空白');
define('EMEMBER_INVALID_EMAIL','電子郵件地址無效');
define('EMEMBER_PASSWORD_EMPTY','密碼不能為空白');
define('EMEMBER_USERNAME_TAKEN','此用戶名稱已被使用');
define('EMEMBER_USERNAME_AVAIL','此用戶名稱可以使用');
define('EMEMBERR_WAIT','驗證中，請稍候');
define('EMEMBER_REQUIRED','必須填寫');
define('EMEMBER_MIN','最小值');
define('EMEMBER_ALLOWED_CHAR_TEXT', '字元要求');
define('EMEMBER_FIELD_MISMATCH','格式不符合');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','只允許英文字母，數字和下底線');
define('EMEMBER_PASSWORD_MISMATCH','密碼不符合');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','您已變更密碼，建議您先登出，然後使用新密碼重新登錄。');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','用戶個人資料');
define('EMEMBER_AUTH_REQUIRED','需要身份驗證');
define('EMEMBER_PROTECTED_BY','受保護的由');
define('EMEMBER_SIGNIN','登錄');
define('EMEMBER_TO_COMMENT', ' 發表評論');
define('EMEMBER_WAIT', '等待');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','續訂或升級');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','您的登錄已過期，請重新登錄。');
define('EMEMBER_USER_PASS_EMPTY','用戶名稱或用戶密碼不能為空！');
define('EMEMBER_TERMS_WARNING', '您必須接受條款和條件進行註冊。');
define("EMEMBER_ACCEPT", "我同意");
define('EMEMBER_TERMS_CONDITIONS', '條款及細則');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "請於下面填寫詳細訊息，以驗證您的電郵地址；驗證後，您就可以註冊驗證後的帳號。");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','先生');
define('EMEMBER_MRS','太太');
define('EMEMBER_MISS','小姐');
define('EMEMBER_MS','女士');
define('EMEMBER_DR','博士');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">您沒有權限查看評論</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','您的個人設定檔不能存取該內容。');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', '搜尋關鍵字');
define('EMEMBER_PREV', '上一筆');
define('EMEMBER_NEXT', '下一筆');
define('EMEMBER_SEARCH', '搜尋');
define('EMEMBER_DATA_NOT_FOUND', '沒有找到任何資料。');
define('EMEMBER_ALREADY_LOGGED_IN','您已被退出，因為其他用戶已經從其他瀏覽器登錄到這個帳號。');
define('EMEMBER_WELCOME_PAGE', '歡迎頁面');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "刪除");
define('EMEMBER_UPLOAD', '上傳');
define('EMEMBER_ACTION', '執行');
define('EMEMBER_DETAILS','詳細資料');
define('EMEMBER_DELETE_ACC','刪除帳號');
define('EMEMBER_MEMBER_SINCE','註冊時間');
define('EMEMBER_USER','使用者');
define('EMEMBER_USERS','使用者');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','輸入圖形驗證碼');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','請注意驗證碼為空白');
define('EMEMBER_CAPTCHA_FAILED','驗證碼驗證失敗');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','選擇一個');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','書籤');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','驗證碼驗證失敗，請再試一次。');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','謝謝您的註冊，帳號正在等待管理員批准。');
define("EMEMBER_ACCOUNT_PENDING","此帳號正在等待批准。");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','你確定嗎？');
define('EMEMBER_YES','是');
define('EMEMBER_NO','否');
define('EMEMBER_REDIRECTION_MESSAGE','請稍候......網頁將重新導向。');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','會員級別已被更新。');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','您必須先登錄才能升級會員級別。');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','您的帳號已被啟用。');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','您的帳號已被啟用，您現在可以登錄網站。');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "允許使用字母，數字，下底線或電子郵件。");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','再次編輯個人資料');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','登錄已過期');
define('EMEMBER_LOGIN_AGAIN', '請重新登錄');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', '會員級別');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', '在登錄帳號之前，此您沒有權限查看此內容。');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Error! The unique registration code you used in the URL has already been used or it is invalid!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Remove');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');
