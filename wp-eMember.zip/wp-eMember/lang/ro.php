<?php
define("EMEMBER_MORE_LINK","Continua sa citesti");
define("EMEMBER_LEVEL_NOT_ALLOWED","Nivelul tau de membru nu permite vizualizarea restului de continut.");
define("EMEMBER_CONTENT_RESTRICTED","Nu ai permisiunea de a vedea acest continut.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Nivelul tau de membru nu permite accesul la acest continut. ");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Acest continut este doar pentru membri.");
define("EMEMBER_MEMBER_LOGIN",'Member Login');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Perioada de abonament a expirat. ");
define("EMEMBER_LOGIN","Autentificare");
define("EMEMBER_RENEW", "Reinnoire");
define("EMEMBER_UPGRADE", "Actualizare");
define("EMEMBER_TO_VIEW_CONTENT", "pentru a vedea acest continut. ");
define("EMEMBER_PLEASE", "Te rog");
define("EMEMBER_JOIN","Inscrie-te astazi!");
define("EMEMBER_NON_MEMBER", "Nu esti membru?");
define("EMEMBER_YOUR_ACCOUNT", " contul tau.");
define("EMEMBER_PROFILE_MESSAGE","Te rog autentifica-te pentru a-ti edita profilul.");
define("EMEMBER_LOGGED_IN_AS", "Esti autentificat ca: ");
define("EMEMBER_LOGGED_IN_LEVEL", "Nivelul tau de membru este: ");
define("EMEMBER_LOGOUT", "Deconectare");
define("EMEMBER_EDIT_PROFILE", "Editeaza Profilul");
define("EMEMBER_SUPPORT_PAGE","Pagina de Sprijin");
define("EMEMBER_BOOKMARK_DISABLED", "Functia de Memorare este dezactivata.");
define("EMEMBER_NO_BOOKMARK", "Nu ai adaugat nimic inca la lista de favorite.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Trebuie sa te autentifici pentru a vedea lista de favorite.");
define("EMEMBER_FORGOT_PASS","Ti-ai uitat parola?");
define("EMEMBER_JOIN_US","Creaza-ti cont aici");
define("EMEMBER_USER_NAME", "Nume utilizator");
define("EMEMBER_PASSWORD", "Parola");
define("EMEMBER_USER_NAME_TAKEN", "Numele de utilizator pe care il folosesti este deja luat! <br/>Te rog alege un alt nume.");
define("EMEMBER_EMAIL_TAKEN", "Adresa de e-mail pe care o folosesti este deja luata! <br/>Te rog alege o alta adresa de email. ");
define("EMEMBER_REG_COMPLETE", "Inregistrare Finalizata! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Notificare Inregistrare Membru Nou");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Un nou membru s-a inregistrat. Urmatorul email a fost trimis la membru.");
define("EMEMBER_USER_PASS_MSG", "Te rog sa alegi numele de utilizator si parola de mai jos pentru a finaliza inregistrarea. ");
define("EMEMBER_FREE_MEMBER_DISABLED", "Apartenenta gratuita ca membru este dezactivata pe acest site!");
define("EMEMBER_EMAIL_UNAVAIL","Acest ID de email nu este disponibil!");
define("EMEMBER_PROFILE_UPDATED","Profilul tau a fost actualizat!");
define("EMEMBER_EMAIL_INVALID","Email invalid.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Acest cont este inactiv.");
define("EMEMBER_WRONG_PASS","Parola Gresita.");
define("EMEMBER_WRONG_USER_PASS", "Nume utilizator sau parola gresita.");
define("EMEMBER_LOGOUT_SUCCESS", "Deconectare cu succes. ");
define("EMEMBER_ADDED", "Adaugat");
define("EMEMBER_FAVORITE", "Favorite");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Datele Tale de Membru");
define("EMEMBER_PASS_EMAILED_MSG","Noua parola a fost trimisa prin email.");
define("EMEMBER_EMAIL_NOT_EXIST","Nu exista utilizator cu aceasta adresa de email.");
define("EMEMBER_ALREADY_TAKEN","Ne pare rau! Aceasta este deja luata.");
define("EMEMBER_STILL_AVAIL","Aceasta este disponibila inca.");
define("EMEMBER_WP_TAKEN","Ne pare rau! Aceasta este deja folosita in Wordpress.");
define('EMEMBER_TITLE','Title');
define("EMEMBER_FIRST_NAME","Prenume");
define("EMEMBER_LAST_NAME","Nume");
define("EMEMBER_EMAIL","Email");
define("EMEMBER_MEMBERSHIP_LEVEL","Apartenenta");
define("EMEMBER_USERNAME","Nume utilizator");
define("EMEMBER_COMPANY","Companie");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Strada");
define("EMEMBER_ADDRESS_CITY","Oras");
define("EMEMBER_ADDRESS_STATE","Stat");
define("EMEMBER_ADDRESS_ZIP","Cod postal");
define("EMEMBER_ADDRESS_COUNTRY","Tara");
define("EMEMBER_GENDER","Gen");
define("EMEMBER_GENDER_MALE","Masculin");
define("EMEMBER_GENDER_FEMALE","Feminin");
define("EMEMBER_GENDER_UNSPECIFIED","Nespecificat");
define("EMEMBER_REGISTRATION","Inregistrare");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Lasa liber daca doresti sa pastrezi parola curenta.");
define("EMEMBER_UPDATE", "Actualizare");
define("EMEMBER_ADD","Adauga");
define("EMEMBER_ADD_FAV","Adauga la Favorite");
define("EMEMBER_BOOKMARK","Memorare");
define("EMEMBER_LOGIN_TO_BOOKMARK","Conectare la lista de memorare.");
define("EMEMBER_PASS_RESET","Resetare Parola");
define("EMEMBER_PASS_RESET_MSG","Te rog introdu adresa de e-mail. Vei primi o noua parola prin e-mail.");
define("EMEMBER_RESET","Reseteaza");
define("EMEMBER_CLOSE","Inchide");
define("EMEMBER_PROFILE_IMAGE", "Imagine Profil");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Nelogat.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "Secure RSS");
define("EMEMBER_WRONG_RSS_URL","Ne pare rau! URL-ul Nu Este Formatat Corect.");
define("EMEMBER_NO_USER_KEY","Ne pare rau! Cheia de Alimentare Nu Este Valida!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Ati Atins Cota Zilnica De Autentificare.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Statusul Contului Tau:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Contul Tau Expira:");
define("EMEMBER_EMAIL_BLACKLISTED","Adresa ta de email este pe lista neagra. <br/>
        		       nu vei putea sa te inregistrezi cu acest ID de email. <br/>te rog Contacteaza Administratorul.");
define("EMEMBER_IP_BLACKLISTED","IP-ul adresei tale este pe lista neagra. <br/>
		       nu vei putea sa te inregistrezi. <br/>te rog Contacteaza Administratorul.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "Retine parola");
define("EMEMBER_NEVER", "Pana la Anulare");
define('EMEMBER_ACTIVE','active');
define('EMEMBER_INACTIVE','inactive');
define('EMEMBER_EXPIRED','expired');
define('EMEMBER_PENDING','pending');
define('EMEMBER_UNSUBSCRIBED','unsubscribed');
define('EMEMBER_VISIT_PAYMENT_PAGE','Please visit the Payment Page to pay for a membership');
define('EMEMBER_CLICK','Click');
define('EMEMBER_HERE','Here');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Salut, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " pentru a incepe. Esti membru? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Te rog sa-ti verifici adresa de email si urmeaza linkul pentru a finaliza inregistrarea.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Trebuie sa introduci o adresa de email!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Trebuie sa completezi toate campurile!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Rescrie parola");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'username cannot be empty.');
define('EMEMBER_USERNAME_4_CHARS', 'username should not be less than 4 characters');
define('EMEMBER_EMAIL_NOT_EMPTY','email cannot be empty');
define('EMEMBER_INVALID_EMAIL','email address is not valid');
define('EMEMBER_PASSWORD_EMPTY','Password Field Cannot be empty');
define('EMEMBER_USERNAME_TAKEN','This user is already taken');
define('EMEMBER_USERNAME_AVAIL','This name is available');
define('EMEMBERR_WAIT','Validating, please wait');
define('EMEMBER_REQUIRED','This field is required');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'characters required');
define('EMEMBER_FIELD_MISMATCH','Fields do not match');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Only Letter, Number and Underscore allowed');
define('EMEMBER_PASSWORD_MISMATCH','Password doesn\'t match.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','You changed your password. It is recommended that you log out and then log back in using the new password.');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','User Profile');
define('EMEMBER_AUTH_REQUIRED','Authentication Required');
define('EMEMBER_PROTECTED_BY','Protected by');
define('EMEMBER_SIGNIN','Sign in');
define('EMEMBER_TO_COMMENT', ' to post a comment');
define('EMEMBER_WAIT', 'wait');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Renew or Upgrade');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Your session has expired. Please login again.');
define('EMEMBER_USER_PASS_EMPTY','Username/Password field cannot be empty!');
define('EMEMBER_TERMS_WARNING', 'You have to accept terms & conditions to register.');
define("EMEMBER_ACCEPT", "Sunt de acord cu ");
define('EMEMBER_TERMS_CONDITIONS', 'Terms &amp; Conditions');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Completeaza urmatoarele detalii pentru a verifica adresa de email. Vei putea sa te inregistrezi pentru un cont dupa verificare.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Mr');
define('EMEMBER_MRS','Mrs');
define('EMEMBER_MISS','Miss');
define('EMEMBER_MS','Ms');
define('EMEMBER_DR','Dr');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comentariu_sectiune_protejat_msg">You do not have permission to view the comments.</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Your profile does not have access to this content.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Search term');
define('EMEMBER_PREV', 'Prev');
define('EMEMBER_NEXT', 'Next');
define('EMEMBER_SEARCH', 'Search');
define('EMEMBER_DATA_NOT_FOUND', 'No data found.');
define('EMEMBER_ALREADY_LOGGED_IN','You have been logged out because another user has logged into this account from another browser.');
define('EMEMBER_WELCOME_PAGE', 'Welcome Page');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Elimina");
define('EMEMBER_UPLOAD', 'Upload');
define('EMEMBER_ACTION', 'Action');
define('EMEMBER_DETAILS','Details');
define('EMEMBER_DELETE_ACC','Delete Account');
define('EMEMBER_MEMBER_SINCE','Member Since');
define('EMEMBER_USER','User');
define('EMEMBER_USERS','Users');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Enter the captcha code');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Keep the following field empty');
define('EMEMBER_CAPTCHA_FAILED','Captcha verification failed');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Select One');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Bookmarks');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','Captcha verification failed. Please try again.');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Thank you for registering. Your account is pending approval by an administrator.');
define("EMEMBER_ACCOUNT_PENDING","Acest cont este in curs de aprobare.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Are You Sure? ');
define('EMEMBER_YES','Yes');
define('EMEMBER_NO','No');
define('EMEMBER_REDIRECTION_MESSAGE','Please wait... you are being redirected.');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Membership level has been updated.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','You must be logged in to upgrade a membership.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Your user account has been activated.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Hi, Your account has been activated. You can now log into the site.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Scrisoare, numar, subliniere sau email permis. ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Edit profile again');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Session Expired.');
define('EMEMBER_LOGIN_AGAIN', 'Please login again');
define('EMEMBER_MEMBERSHIP_LEVEL_NAME', 'Membership Level');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'This content was published before you joined us. You do not have permission to view this content.');
define('EMEMBER_RETYPE_EMAIL', 'Retype Email');
define('EMEMBER_EMAIL_MISMATCH', 'Email field mismatch');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Error! The unique registration code you used in the URL has already been used or it is invalid!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Remove');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostrophe character is not allowed.');
define('EMEMBER_SEND_VERIFICATION', 'Send Verification Email');


