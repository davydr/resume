<?php
define("EMEMBER_MORE_LINK","Läs mer");
define("EMEMBER_LEVEL_NOT_ALLOWED","Ditt medlemskap tillåter inte att du får se innehållet.");
define("EMEMBER_CONTENT_RESTRICTED","Du har inte tillgång till att visa innehållet.");
define("EMEMBER_HIDDEN_CONTENT_MESSAGE","Du har inte rätt medlemskap för att visa innehållet");
define("EMEMBER_MEMBERS_ONLY_MESSAGE","Endast inloggade medlemmar kan se det här");
define("EMEMBER_MEMBER_LOGIN",'Medlemssidor');
define("EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE", "Medlemskapet har löpt ut. ");
define("EMEMBER_LOGIN","Logga in");
define("EMEMBER_RENEW", "Förnya");
define("EMEMBER_UPGRADE", "Uppgradera");
define("EMEMBER_TO_VIEW_CONTENT", "För att visa innehållet. ");
define("EMEMBER_PLEASE", "Vänligen");
define("EMEMBER_JOIN","Bli medlem!");
define("EMEMBER_NON_MEMBER", "- Är du inte medlem?");
define("EMEMBER_YOUR_ACCOUNT", " ditt konto.");
define("EMEMBER_PROFILE_MESSAGE","Logga in för att få tillgång till dina kontodetaljer.");
define("EMEMBER_LOGGED_IN_AS", "Hej, ");
define("EMEMBER_LOGGED_IN_LEVEL", "Medlemskap: ");
define("EMEMBER_LOGOUT", "Loogga ut");
define("EMEMBER_EDIT_PROFILE", "Din profil");
define("EMEMBER_SUPPORT_PAGE","Supportsidor");
define("EMEMBER_BOOKMARK_DISABLED", "Möjligheten att lägga till favoritsidor är inte aktiverat.");
define("EMEMBER_NO_BOOKMARK", "Du har inte lagt till några favoritsidor ännu.");
define("EMEMBER_BOOKMARK_NOT_LOGGED_IN","Logga in för att se dina favoritsidor.");
define("EMEMBER_FORGOT_PASS","Glömt lösenordet?");
define("EMEMBER_JOIN_US","Bli medlem");
define("EMEMBER_USER_NAME", "Användarnamn");
define("EMEMBER_PASSWORD", "Lösenord");
define("EMEMBER_USER_NAME_TAKEN", "Det här användarnamnet är upptaget! <br/>Välj ett annat.");
define("EMEMBER_EMAIL_TAKEN", "Det finns redan ett konto med den här e-post adressen! <br/>Välj en annan eller logga in. ");
define("EMEMBER_REG_COMPLETE", "Registreringen är komplett! ");
define("EMEMBER_NEW_ACCOUNT_MAIL_HEAD", "Ny medlemsregistrering");
define("EMEMBER_NEW_ACCOUNT_MAIL_BODY", "Du har fått en ny medlem. Följande mail blev sänt till sökande:");
define("EMEMBER_USER_PASS_MSG", "Välj användarnamn och lösenrod för att fortsätta");
define("EMEMBER_FREE_MEMBER_DISABLED", "Den här siten kan du inte bli gratis medlem på!");
define("EMEMBER_EMAIL_UNAVAIL","Den här eposten är inte tillgänglig!");
define("EMEMBER_PROFILE_UPDATED","Din profil er nu uppdaterad!");
define("EMEMBER_EMAIL_INVALID","Epostadressen ser inte ut att stämma.");
/** added v4.9.4#start**/
define("EMEMBER_ACCOUNT_INACTIVE","Kontot är inaktivt.");
define("EMEMBER_WRONG_PASS","Fel lösenord.");
define("EMEMBER_WRONG_USER_PASS", "Fel användarnamn/ lösenord.");
define("EMEMBER_LOGOUT_SUCCESS", "Du har nu loggat ut. ");
define("EMEMBER_ADDED", "Tillagd");
define("EMEMBER_FAVORITE", "Favorit");
define("EMEMBER_MEMBERSHIP_DETAILS_MAIL","Ditt medlemskap");
define("EMEMBER_PASS_EMAILED_MSG","Du har fått ett nytt lösenord skickat till din Epost.");
define("EMEMBER_EMAIL_NOT_EXIST","Denna epostadressen existerar inte.");
define("EMEMBER_ALREADY_TAKEN","Beklagar, någon han före dig.");
define("EMEMBER_STILL_AVAIL","Användarnamnet är ledigt.");
define("EMEMBER_WP_TAKEN","Beklagar. Användarnamnet är redan taget.");
define('EMEMBER_TITLE','Titel');
define("EMEMBER_FIRST_NAME","Förnamn");
define("EMEMBER_LAST_NAME","Efternamn");
define("EMEMBER_EMAIL","Epost");
define("EMEMBER_MEMBERSHIP_LEVEL","Typ av medlemskap");
define("EMEMBER_USERNAME","Användarnamn");
define("EMEMBER_COMPANY","Firma");
define("EMEMBER_PHONE","Telefon");
define("EMEMBER_ADDRESS_STREET","Adress");
define("EMEMBER_ADDRESS_CITY","Ort");
define("EMEMBER_ADDRESS_STATE","Län");
define("EMEMBER_ADDRESS_ZIP","Postnummer");
define("EMEMBER_ADDRESS_COUNTRY","Land");
define("EMEMBER_GENDER","Kön");
define("EMEMBER_GENDER_MALE","Man");
define("EMEMBER_GENDER_FEMALE","Kvinna");
define("EMEMBER_GENDER_UNSPECIFIED","Inte specifierat");
define("EMEMBER_REGISTRATION","Registrera");
define("EMEMBER_KEEP_CURRENT_PASS_MSG","Lämna blankt om du vill behålla ditt lösenord.");
define("EMEMBER_UPDATE", "Uppdatera");
define("EMEMBER_ADD","Lägg til");
define("EMEMBER_ADD_FAV","Lägg till som favorit");
define("EMEMBER_BOOKMARK","Bokmärke");
define("EMEMBER_LOGIN_TO_BOOKMARK","Logga in för att lägga till bokmärke.");
define("EMEMBER_PASS_RESET","Lösenordet återställt");
define("EMEMBER_PASS_RESET_MSG","Skriv in din e-postadress om du vill ha ett nytt lösenord");
define("EMEMBER_RESET","Sänd");
define("EMEMBER_CLOSE","Stäng");
define("EMEMBER_PROFILE_IMAGE", "Profilbild");
/** added v4.9.4#end**/
/** added v5.0#start**/
define("EMEMBER_NOT_LOGGED_IN","Du är inte inloggad.");
/** added v5.0#end**/
/**added v5.0.2#start***/
define("EMEMBER_MY_FEED", "My Secure RSS");
define("EMEMBER_WRONG_RSS_URL","Beklager. Nättadressen ser ikke ut att finnas.");
define("EMEMBER_NO_USER_KEY","Beklagar. det stämmer inte!.");
/**added v5.0.2#end***/
/**added v5.0.6#start***/
define('EMEMBER_LOGIN_LIMIT_ERROR', "Beklagar. Du har loggat in för många gånger idag.");
/**added v5.0.6#end***/
/***added v5.0.7#start**/
define('EMEMBER_ACCOUNT_STATUS', "Status:");
define("EMEMBER_ACCOUNT_EXPIRES_ON", "Kontot upphör att gälla:");
define("EMEMBER_EMAIL_BLACKLISTED","Epostadressen din er svartelistet. <br/>
        		        <br/>Ta kontakt om du undrar över något.");
define("EMEMBER_IP_BLACKLISTED","Din IP-adresse är svartelistad. <br/>
		        <br/>Ta kontakt om du undrar något.");
/***added v5.0.7#end**/
/***added v5.3.4#start**/
define("EMEMBER_REMEMBER_ME", "fråga mig");
define("EMEMBER_NEVER", "tills avanmälan");
define('EMEMBER_ACTIVE','aktiv');
define('EMEMBER_INACTIVE','inaktiv');
define('EMEMBER_EXPIRED','gått ut');
define('EMEMBER_PENDING','Väntande');
define('EMEMBER_UNSUBSCRIBED','Avanmäl dig');
define('EMEMBER_VISIT_PAYMENT_PAGE' , 'Gå till betalningssidan');
define('EMEMBER_CLICK','Tryck');
define('EMEMBER_HERE','här');
/***added v5.3.4#end**/
/***added v5.4.3#start**/
define("EMEMBER_HELLO", "Hej, ");
define("EMEMBER_NOT_A_MEMBER_TEXT", " för tillgång. <br/>Är du medlem? ");
/***added v5.4.3#end**/
/***added v5.7.2#start**/
define("EMEMBER_PLEASE_CHECK_YOUR_INBOX", "Gå till din eposte för att slutföra registreringen.");
define("EMEMBER_YOU_MUST_ENTER_AN_EMAIL_ADDRESS", "Du måste uppge en epostadress!");
/***added v5.7.2#end**/
/***added v5.8.8#start**/
define("EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS", "Du måste fylla i alla fälten!");
/***added v5.8.8#end**/
/***added v6.4.2#start**/
define("EMEMBER_PASSWORD_REPEAT", "Upprepa");
/***added v6.4.2#end**/
/***added v6.8.4#start**/
define('EMEMBER_USERNAME_NOT_EMPTY', 'Du måste fylla i användarnamn.');
define('EMEMBER_USERNAME_4_CHARS', 'Användarnamnet måste vara minst 4 bokstäver');
define('EMEMBER_EMAIL_NOT_EMPTY','Du måste fylla i en epostadress');
define('EMEMBER_INVALID_EMAIL','epostadressen är felaktig');
define('EMEMBER_PASSWORD_EMPTY','Du måste fylla i lösenord!');
define('EMEMBER_USERNAME_TAKEN','Användarnamnet är taget, välj ett nytt');
define('EMEMBER_USERNAME_AVAIL','Användarnamnet är ledigt');
define('EMEMBERR_WAIT','Validerar. Vännligen vänta');
define('EMEMBER_REQUIRED','Obligatorisk');
define('EMEMBER_MIN','Minimum');
define('EMEMBER_ALLOWED_CHAR_TEXT', 'Måste innehålla text');
define('EMEMBER_FIELD_MISMATCH','Fälten stämmer inte överrens');
define('EMEMBER_ALPHA_NUMERIC_UNDERSCORE','Endast bokstäver, stora bokstäver och understreck är tillåtet.');
define('EMEMBER_PASSWORD_MISMATCH','Lösenorden stämmer inte överrens.');
/***added v6.8.4#end**/
/***added v6.8.9#start**/
define('EMEMBER_PASSWORD_CHANGED_RELOG_RECOMMENDED','När du ändrar lösenordet måste du logga in på nytt innan du fortsätter!');
/***added v6.8.9#end**/
/***added v6.9.3#start**/
define('EMEMBER_USER_PROFILE','Användare');
define('EMEMBER_AUTH_REQUIRED','Auktorisering krävs');
define('EMEMBER_PROTECTED_BY','Skyddad av');
define('EMEMBER_SIGNIN','Logga in');
define('EMEMBER_TO_COMMENT', ' Kommentera');
define('EMEMBER_WAIT', 'vänta');
/***added v6.9.3#end**/
/***added v7.2.0#start**/
define('EMEMBER_RENEW_OR_UPGRADE','Förnya eller uppgradera');
/***added v7.2.0#end**/
/***added v7.4.1#start**/
define('EMEMBER_AUTOLOGOUT_MSG','Du har varit inaktiv för länge. Logga in igen.');
define('EMEMBER_USER_PASS_EMPTY','Fyll i användarnamnet / Lösenordet!');
define('EMEMBER_TERMS_WARNING', 'Du må godta betingelsene for å fortsette.');
define("EMEMBER_ACCEPT", "Jag accepterar ");
define('EMEMBER_TERMS_CONDITIONS', 'Terms.');
/***added v7.4.1#end**/
/***added v7.5.4#start**/
define("EMEMBER_VERIFY_EMAIL_ADDRESS_MESSAGE", "Fyll i din Epostadress, efter att du har bekräftat eEpostadressen kan du upprätta ett konot.");
/***added v7.5.4#end**/
/***added v7.6.2#start**/
define('EMEMBER_MR','Herr');
define('EMEMBER_MRS','Fru');
define('EMEMBER_MISS','Fröken');
define('EMEMBER_MS','Fru');
define('EMEMBER_DR','Dr.');
define('EMEMBER_COMMENT_PROTECTED','<div class="eMember_comment_section_protected_msg">Du har inte rättigheter att visa kommentaren</div>');
/***added v7.6.2#end**/
/***added v7.8.4#start**/
define('EMEMBER_ACCOUNT_PROFILE_NOT_ALLOWED','Din medlemsnivå har inte tillgång till detta innehållet.');
/***added v7.8.4#end**/
/***added v7.9.8.4#start**/
define('EMEMBER_SEARCH_TERM', 'Sök');
define('EMEMBER_PREV', 'Tidigare');
define('EMEMBER_NEXT', 'Nästa');
define('EMEMBER_SEARCH', 'Sök');
define('EMEMBER_DATA_NOT_FOUND', 'Vi hittade inte det du söker efter.');
define('EMEMBER_ALREADY_LOGGED_IN','Du blev utloggad för att någon annan har försökt att logga in från en annan plats.');
define('EMEMBER_WELCOME_PAGE', 'Välkommen');
/***added v7.9.8.4#end**/
/***added v7.9.8.9 #start**/
define('EMEMBER_REMOVE', "Radera");
define('EMEMBER_UPLOAD', 'Ladda upp');
define('EMEMBER_ACTION', 'Handling');
define('EMEMBER_DETAILS','Detaljer');
define('EMEMBER_DELETE_ACC','Radera kontot');
define('EMEMBER_MEMBER_SINCE','Medlem sedann');
define('EMEMBER_USER','Användare');
define('EMEMBER_USERS','Användare');
/***added v7.9.8.9 #end**/
/***added v8.1.4 #start**/
define('EMEMBER_INPUT_THIS_CODE','Skriv in rätt kod');
define('EMEMBER_HONEYPOT_CAPTCHA_MSG','Låt detta fältet vara tomt');
define('EMEMBER_CAPTCHA_FAILED','CAPTCHA stämmer inte');
/***added v8.1.4 #end**/
/***added v8.1.6 #start**/
define('EMEMBER_SELECT_ONE','Välj...');
/***added v8.1.6 #end**/
define('EMEMBER_BOOKMARK_PAGE','Bokmärke');
/***added v8.5.1 #end**/
define('EMEMBER_CAPTCHA_VERIFICATION_FAILED','CAPTCHA koden stämmer inte överrens, Pröva igen!');
define('EMEMBER_REG_COMPLETE_PENDING_APPROVAL','Tack för att dur registrerade dig, Du kan nu logga så fort vi godkänt din medlemsansökan.');
define("EMEMBER_ACCOUNT_PENDING","Medlemskapet väntar på godkännande.");
/***added v8.6.0 #start**/
define('EMEMBER_CONFIRM','Är du säker? ');
define('EMEMBER_YES','Ja');
define('EMEMBER_NO','Nej');
define('EMEMBER_REDIRECTION_MESSAGE','Du blir nu vidarebefordrat, var vänlig vänta!');
/***added v8.6.0 #end**/
/***added v8.6.6 #start**/
define('EMEMBER_LEVEL_UPDATED','Ditt Medlemskap har blivit uppdaterat.');
define('EMEMBER_MUST_BE_LOGGED_IN_TO_UPDATE_LEVEL','Du måste vara inloggad för att kunna ändra ditt medlemskap.');
/***added v8.6.6 #end**/
/***added v8.7.5 #start**/
define('EMEMBER_BULK_ACTIVATION_EMAIL_SUBJECT','Ditt konto har nu blivit aktiverat.');
define('EMEMBER_BULK_ACTIVATION_EMAIL_BODY','Hej. Ditt konto är aktiverat, du kan nu logga in.');
define('EMEMBER_USER_NAME_VALIDATION_MESSAGE', "Endast bokstäver, Stora bokstäver och understreck är tillåtet. ");
/***added v8.7.5 #end**/
/***added v8.8.4 #start**/
define('EMEMBER_EDIT_YOUR_PROFILE_AGAIN','Gåt illbaka till din profil');
/***added v8.8.4 #end**/
define('EMEMBER_SESSION_EXPIRED','Du har varit inaktiv för länge.');
define('EMEMBER_LOGIN_AGAIN', 'Var vänlig logga in på nytt!');
/***added v8.9.4 #end**/
define('EMEMBER_OLD_POST_PROTECTED_MSG', 'Det här innehållet publiceras inte förän du blir medlem, och därför har du inte tillgång till det.');
define('EMEMBER_RETYPE_EMAIL', 'Skriv om Email');
define('EMEMBER_EMAIL_MISMATCH', 'Email fältet stämmer inte');
/***added v9.0.1 ***/
define('EMEMBER_ALREADY_USED_REGISTRATION_CODE', 'Fel, Den unika registreringskoden som du använde från URL:en har redan använts och är ogiltig!');
/***added v9.0.4 ***/
define('EMEMBER_BOOKMARK_REMOVE','Ta bort bokmärke');
define('EMEMBER_APOSTROPHE_NOT_ALLOWED','Apostroftecken är inte tillåtet.');
define('EMEMBER_SEND_VERIFICATION', 'Sänd verifikationsmejl');

