<?php

//TODO - move the menu include files into a separate folder.
include_once(WP_EMEMBER_PATH . 'admin_includes.php');
include_once(WP_EMEMBER_PATH . 'emember_menu_email_settings.php');
include_once(WP_EMEMBER_PATH . 'emember_menu_recaptcha_settings.php');
include_once(WP_EMEMBER_PATH . 'emember_menu_pages_settings.php');
include_once(WP_EMEMBER_PATH . 'emember_menu_general_settings.php');
include_once(WP_EMEMBER_PATH . 'emember_menu_auto_responder_settings.php');
include_once(WP_EMEMBER_PATH . 'emember_menu_custom_field_settings.php');
include_once(WP_EMEMBER_PATH . 'emember_menu_gateway_settings.php');

function wp_eMember_settings() {
    echo '<div class="wrap"><h2>WP eMember - Settings v' . WP_EMEMBER_VERSION . '</h2>';
    echo eMember_admin_submenu_css();
    $current = (isset($_GET['tab'])) ? $_GET['tab'] : 1;
    ?>
    <h2 class="nav-tab-wrapper">
        <a class="nav-tab <?php echo ($current == 1) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=eMember_settings_menu">General Settings</a>
        <a class="nav-tab <?php echo ($current == 4) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=eMember_settings_menu&tab=4">Pages/Forms Settings</a>
        <a class="nav-tab <?php echo ($current == 2) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=eMember_settings_menu&tab=2">Email Settings</a>
        <a class="nav-tab <?php echo ($current == 7) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=eMember_settings_menu&tab=7">Gateway Settings</a>
        <a class="nav-tab <?php echo ($current == 3) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=eMember_settings_menu&tab=3">reCAPTCHA Settings</a>
        <a class="nav-tab <?php echo ($current == 5) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=eMember_settings_menu&tab=5">Autoresponder Settings</a>
        <a class="nav-tab <?php echo ($current == 6) ? 'nav-tab-active' : ''; ?>" href="admin.php?page=eMember_settings_menu&tab=6">Custom Field Settings</a>
    </h2>
    <?php
    $_GET['tab'] = isset($_GET['tab']) ? $_GET['tab'] : "";
    switch ($current) {
        case '2':
            wp_eMember_email_settings();
            break;
        case '3':
            recaptcha_settings();
            break;
        case '4':
            emember_pages_settings();
            break;
        case '5':
            emember_auto_responder_settings();
            break;
        case '6':
            emember_custom_field_settings();
            break;
        case '7':
            emember_payment_gateway_settings_menu();
            break;
        default:
            wp_eMember_general_settings();
            break;
    }
    echo '</div>';
}
