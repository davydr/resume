<?php

function emember_auto_responder_settings() {
    $emember_config = Emember_Config::getInstance();
    echo '<div class="wrap">';
    echo '<div id="poststuff"><div id="post-body">';
    if (isset($_POST['info_update'])) {
        // Verify nonce
        if (!isset($_POST['emember_autoresponder_settings_nonce']) || !wp_verify_nonce($_POST['emember_autoresponder_settings_nonce'], 'emember_autoresponder_settings_action')) {
            wp_die('Nonce security check failed');
        }	
        
        $errors = "";
        if (isset($_POST['aweber_make_connection'])) {
            if ($emember_config->getValue('eMember_aweber_authorize_status') != 'authorized') {
                $authorization_code = trim($_POST['aweber_auth_code']);
                if (!class_exists('AWeberAPI')) {
                    include_once('lib/auto-responder/aweber_api/aweber_api.php');
                }
                $auth = AWeberAPI::getDataFromAweberID($authorization_code);
                list($consumerKey, $consumerSecret, $accessKey, $accessSecret) = $auth;
                $eMember_aweber_access_keys = array(
                    'consumer_key' => $consumerKey,
                    'consumer_secret' => $consumerSecret,
                    'access_key' => $accessKey,
                    'access_secret' => $accessSecret,
                );
                $emember_config->setValue('eMember_aweber_access_keys', $eMember_aweber_access_keys);

                if ($eMember_aweber_access_keys['access_key']) {
                    try {
                        $aweber = new AWeberAPI($consumerKey, $consumerSecret);
                        $account = $aweber->getAccount($accessKey, $accessSecret);
                    } catch (AWeberException $e) {
                        $account = null;
                    }
                    if (!$account) {
                        //$this->deauthorize();//TODO - remove the keys
                        $errors = 'AWeber authentication failed! Please try connecting again.';
                    } else {
                        $emember_config->setValue('eMember_aweber_authorize_status', 'authorized');
                        $_POST['eMember_use_new_aweber_integration'] = '1'; //Set the eMember_use_new_aweber_integration flag to enabled
                        echo '<div id="message" class="updated fade"><p><strong>';
                        echo 'AWeber authorization success!';
                        echo '</strong></p></div>';
                    }
                } else {
                    $errors = 'You need to specify a valid authorization code to establish an AWeber API connection';
                }
            } else {//Remove existing connection
                $eMember_aweber_access_keys = array(
                    'consumer_key' => '',
                    'consumer_secret' => '',
                    'access_key' => '',
                    'access_secret' => '',
                );
                $emember_config->setValue('eMember_aweber_access_keys', $eMember_aweber_access_keys);
                $emember_config->setValue('eMember_aweber_authorize_status', '');
                $_POST['eMember_use_new_aweber_integration'] = ''; //Set the eMember_use_new_aweber_integration flag to disabled
                echo '<div id="message" class="updated fade"><p><strong>';
                echo 'AWeber connection removed!';
                echo '</strong></p></div>';
            }
        }

        $emember_config->setValue('eMember_enable_aweber_int', isset($_POST['eMember_enable_aweber_int']) ? '1' : '');
        $emember_config->setValue('eMember_aweber_list_name', (string) $_POST["eMember_aweber_list_name"]);
        $emember_config->setValue('eMember_use_new_aweber_integration', isset($_POST['eMember_use_new_aweber_integration']) ? '1' : '' );

        $emember_config->setValue('eMember_use_mailchimp', isset($_POST['eMember_use_mailchimp']) ? '1' : '' );
        $emember_config->setValue('eMember_chimp_list_name', trim(stripslashes($_POST["eMember_chimp_list_name"])));
        $emember_config->setValue('eMember_chimp_api_key', trim($_POST["eMember_chimp_api_key"]));
        $emember_config->setValue('eMember_mailchimp_disable_double_optin', isset($_POST['eMember_mailchimp_disable_double_optin']) ? '1' : '' );

        $emember_config->setValue('eMember_use_getresponse', isset($_POST['eMember_use_getresponse']) ? '1' : '' );
        $emember_config->setValue('eMember_getResponse_campaign_name', (string) $_POST["eMember_getResponse_campaign_name"]);
        $emember_config->setValue('eMember_getResponse_api_key', (string) $_POST["eMember_getResponse_api_key"]);

        $emember_config->setValue('eMember_use_generic_autoresponder_integration', isset($_POST['eMember_use_generic_autoresponder_integration']) ? '1' : '' );
        $emember_config->setValue('eMember_use_global_generic_autoresponder_integration', isset($_POST['eMember_use_global_generic_autoresponder_integration']) ? '1' : '' );
        $emember_config->setValue('eMember_generic_autoresponder_target_list_email', trim($_POST["eMember_generic_autoresponder_target_list_email"]));

        $emember_config->saveConfig();

        if (!empty($errors)) {
            echo '<div id="message" class="error"><p>';
            echo $errors;
            echo '</p></div>';
        } else {
            echo '<div id="message" class="updated fade"><p><strong>';
            echo 'Autoresponder Options Updated!';
            echo '</strong></p></div>';
        }
    }
    ?>

    <form method="post" action="<?php echo esc_url_raw($_SERVER["REQUEST_URI"]); ?>">
        <?php wp_nonce_field('emember_autoresponder_settings_action', 'emember_autoresponder_settings_nonce'); ?>	
        <input type="hidden" name="info_update" id="info_update" value="true" />

        <div class="postbox">
            <h3 class="hndle"><label for="title">AWeber Settings (<a href="https://www.tipsandtricks-hq.com/wordpress-membership/how-to-integrate-wp-emember-with-aweber-151" target="_blank">AWeber Integration Instructions</a>)</label></h3>
            <div class="inside">

                <table width="100%" border="0" cellspacing="0" cellpadding="6">

                    <tr valign="top"><td width="25%" align="left">
                            <strong>Enable AWeber Signup:</strong>
                        </td><td align="left">
                            <input name="eMember_enable_aweber_int" type="checkbox"<?php if ($emember_config->getValue('eMember_enable_aweber_int') != '') echo ' checked="checked"'; ?> value="1"/>
                            <br /><i>When checked the plugin will automatically signup the members at registration time to your AWeber List specified below. For membership level specific signup see the "Autoresponder List/Campaign Name" section of the membership level.</i><br /><br />
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            <strong>Global AWeber List Name:</strong>
                        </td><td align="left">
                            <input name="eMember_aweber_list_name" type="text" size="40" value="<?php echo $emember_config->getValue('eMember_aweber_list_name'); ?>"/>
                            <br /><i>The name of the AWeber list where the members will be signed up to (example: awlist1234567). If you want to signup members to different lists based on their membership level, then specify the listname in the membership level configuration.</i><br /><br />
                        </td></tr>
                </table>

                <div style="border-bottom: 1px solid #dedede; height: 10px"></div>
                <table class="form-table">

                    <tr valign="top"><td width="25%" align="left">
                            Use the New AWeber Integration Option:
                        </td><td align="left">
                            <input name="eMember_use_new_aweber_integration" type="checkbox"<?php if ($emember_config->getValue('eMember_use_new_aweber_integration') != '') echo ' checked="checked"'; ?> value="1"/>
                            <br /><i>When checked the plugin will use the new AWeber integration method which uses the AWeber API (this method is recommended over the old method that uses the email parser).</i>
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            Step 1: Get Your AWeber Authorization Code:
                        </td><td align="left">
                            <a href="https://auth.aweber.com/1.0/oauth/authorize_app/999d6172" target="_blank">Click here to get your authorization code</a>
                            <br /><i>Clicking on the above link will take you to the AWeber site where you will need to log in using your AWeber username and password. Then give access to the Tips and Tricks HQ AWeber app.</i>
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            Step 2: Paste in Your Authorization Code:
                        </td><td align="left">
                            <input name="aweber_auth_code" type="text" size="100" value=""/>
                            <br /><i>Paste the long authorization code that you got from AWeber in the above field.</i>
                        </td></tr>

                    <tr valign="top"><td colspan="2" align="left">
                            <?php
                            if ($emember_config->getValue('eMember_aweber_authorize_status') == 'authorized') {
                                echo '<input type="submit" name="aweber_make_connection" value="Remove Connection" class= "button button" />';
                            } else {
                                echo '<input type="submit" name="aweber_make_connection" value="Make Connection" class= "button-primary" />';
                            }
                            ?>
                        </td></tr>

                </table>
            </div></div>

        <div class="postbox">
            <h3 class="hndle"><label for="title">MailChimp Settings (<a href="https://www.tipsandtricks-hq.com/wordpress-membership/wp-emember-and-mailchimp-integration-236" target="_blank">MailChimp Integration Instructions</a>)</label></h3>
            <div class="inside">

                <table width="100%" border="0" cellspacing="0" cellpadding="6">

                    <tr valign="top"><td width="25%" align="left">
                            <strong>Use MailChimp AutoResponder:</strong>
                        </td><td align="left">
                            <input name="eMember_use_mailchimp" type="checkbox"<?php if ($emember_config->getValue('eMember_use_mailchimp') != '') echo ' checked="checked"'; ?> value="1"/>
                            <br /><i>Check this if you want to use MailChimp Autoresponder service. For membership level specific signup see the "Autoresponder List/Campaign Name" section of the membership level.</i><br /><br />
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            <strong>MailChimp List Name:</strong>
                        </td><td align="left">
                            <input name="eMember_chimp_list_name" type="text" size="30" value="<?php echo $emember_config->getValue('eMember_chimp_list_name'); ?>"/>
                            <br /><i>The name of the MailChimp list where the customers will be signed up to (e.g. Customer List)</i><br /><br />
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            <strong>MailChimp API Key:</strong>
                        </td><td align="left">
                            <input name="eMember_chimp_api_key" type="text" size="50" value="<?php echo $emember_config->getValue('eMember_chimp_api_key'); ?>"/>
                            <br /><i>The API Key of your MailChimp account (can be found under the "Account" tab). By default the API Key is not active so make sure you activate it in your Mailchimp account. If you do not have the API Key then you can use the username and password option below but it is better to use the API key.</i>
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            <strong>Disable Double Opt-In:</strong>
                        </td><td align="left">
                            <input name="eMember_mailchimp_disable_double_optin" type="checkbox"<?php if ($emember_config->getValue('eMember_mailchimp_disable_double_optin') != '') echo ' checked="checked"'; ?> value="1"/>
                            Do not send double opt-in confirmation email
                            <br /><i>Use this checkbox if you do not wish to use the double opt-in option.</i><br />
                        </td>
                    </tr>

                </table>
            </div></div>

        <div class="postbox">
            <h3 class="hndle"><label for="title">GetResponse Settings (<a href="https://www.tipsandtricks-hq.com/wordpress-membership/wp-emember-and-getresponse-integration-283" target="_blank">GetResponse Integration Instructions</a>)</label></h3>
            <div class="inside">

                <table width="100%" border="0" cellspacing="0" cellpadding="6">

                    <tr valign="top"><td width="25%" align="left">
                            <strong>Use GetResponse AutoResponder:</strong>
                        </td><td align="left">
                            <input name="eMember_use_getresponse" type="checkbox"<?php if ($emember_config->getValue('eMember_use_getresponse') != '') echo ' checked="checked"'; ?> value="1"/>
                            <br /><i>Check this if you want to use GetResponse Autoresponder service.</i><br /><br />
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            <strong>GetResponse Campaign ID:</strong>
                        </td><td align="left">
                            <input name="eMember_getResponse_campaign_name" type="text" size="30" value="<?php echo $emember_config->getValue('eMember_getResponse_campaign_name'); ?>"/>
                            <br /><i>The Campaign ID or Token ID of the GetResponse campaign where the customers will be signed up to (example: Thual)</i><br /><br />
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            <strong>GetResponse API Key:</strong>
                        </td><td align="left">
                            <input name="eMember_getResponse_api_key" type="text" size="50" value="<?php echo $emember_config->getValue('eMember_getResponse_api_key'); ?>"/>
                            <br /><i>The API Key of your GetResponse account (can be found inside your GetResponse Account).</i><br /><br />
                        </td></tr>

                </table>
            </div></div>

        <div class="postbox">
            <h3 class="hndle"><label for="title">Generic Autoresponder Integration Settings</label></h3>
            <div class="inside">

                <br /><strong>&nbsp; &nbsp; If your autoresponder provider allows you to signup users just by sending an email to the list email address with the user's email as the from address then you can use this method of integration</strong>

                <table class="form-table" width="100%" border="0" cellspacing="0" cellpadding="6">

                    <tr valign="top"><td width="25%" align="left">
                            Enable Generic Autoresponder Integration:
                        </td><td align="left">
                            <input name="eMember_use_generic_autoresponder_integration" type="checkbox"<?php if ($emember_config->getValue('eMember_use_generic_autoresponder_integration') != '') echo ' checked="checked"'; ?> value="1"/>
                            <br /><p class="description">Use this option if you want to use the generic auotoresponder integration option.</p>
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            Enable Global Integration:
                        </td><td align="left">
                            <input name="eMember_use_global_generic_autoresponder_integration" type="checkbox"<?php if ($emember_config->getValue('eMember_use_global_generic_autoresponder_integration') != '') echo ' checked="checked"'; ?> value="1"/>
                            <br /><p class="description">When checked the plugin will automatically sign up every member to your list/campaign specified below. If you want to selectively signup members on a per membership level basis then use the Autoresponder settings of that level.</p>
                        </td></tr>

                    <tr valign="top"><td width="25%" align="left">
                            Global List/Campaign Email Address:
                        </td><td align="left">
                            <input name="eMember_generic_autoresponder_target_list_email" type="text" size="40" value="<?php echo $emember_config->getValue('eMember_generic_autoresponder_target_list_email'); ?>"/>
                            <br /><p class="description">The email address of the list where the member will be signed up to. The plugin will send the autoresponder signup request email to this address.</p>
                        </td></tr>

                </table>
            </div></div>

        <div class="submit">
            <input type="submit" name="info_update" class="button-primary" value="<?php _e('Update options'); ?> &raquo;" />
        </div>
    </form>

    <?php
    echo '</div></div>';
    echo '</div>';
}
