<?php

function emember_payments_menu_handler() {
    echo '<div class="wrap">';

    //Navigation tabs
    $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : '';
    ?>
    <h2 class="nav-tab-wrapper">
        <a class="nav-tab <?php echo ($tab == '') ? 'nav-tab-active' : ''; ?>" href="admin.php?page=emember_payments">All Transactions</a>
        <a class="nav-tab <?php echo ($tab == 'payment_buttons') ? 'nav-tab-active' : ''; ?>" href="admin.php?page=emember_payments&tab=payment_buttons">Payment Buttons</a>
        <a class="nav-tab <?php echo ($tab == 'create_new_button') ? 'nav-tab-active' : ''; ?>" href="admin.php?page=emember_payments&tab=create_new_button">Create New Button</a>
    </h2>
    <?php
    echo '<div id="poststuff"><div id="post-body">';

    //Switch case for the various different tabs
    switch ($tab) {
        case 'payment_buttons':
            //Payment buttons listing tab
            include_once(WP_EMEMBER_PATH . '/includes/admin-side/all_payment_buttons.php');
            break;
        case 'create_new_button':
            //Create new payment button tab
            include_once(WP_EMEMBER_PATH . '/includes/admin-side/create_payment_button.php');
            break;
        case 'edit_button':
            //Edit payment buttton tab
            include_once(WP_EMEMBER_PATH . '/includes/admin-side/edit_payment_button.php');
            break;
        default:
            //All transactions tab
            include_once(WP_EMEMBER_PATH . '/includes/admin-side/all_payment_transactions.php');
            break;
    }

    echo '</div></div>'; //End of #poststuff and #post-body
    echo '</div>'; //End of .wrap
}

